<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('list_template_sizes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("list_template_id");
            $table->enum("size",[1,0])->default('0');
            $table->enum("price",[1,0])->default('0');
            $table->timestamps();
            $table->foreign("list_template_id")->references("id")->on("list_templates")->onDelete("cascade");

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('list_template_sizes');
    }
};
