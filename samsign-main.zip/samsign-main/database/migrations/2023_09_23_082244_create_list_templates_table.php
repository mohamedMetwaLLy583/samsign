<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('list_templates', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("menu_id");
            $table->enum("list_name",[1,0])->default('0');
            $table->enum("list_description",[1,0])->default('0');
            $table->enum("list_price",[1,0])->default('0');
            $table->enum("product_name",[1,0])->default('0');
            $table->enum("product_description",[1,0])->default('0');
            $table->integer("product_number")->default(0);
            $table->integer("size_number")->default(0);
            $table->timestamps();
            $table->foreign("menu_id")->references("id")->on("menus")->onDelete("cascade");

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('list_templates');
    }
};
