<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class notification extends Model
{
      protected $fillable=["notifiable_id","order_id","details","title","body","type"];
      protected $casts = [
        'notifiable_id' => 'integer',
    ];
}
