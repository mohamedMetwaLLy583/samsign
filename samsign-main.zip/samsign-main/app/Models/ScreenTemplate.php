<?php

namespace App\Models;

use App\Models\Scopes\ScreenTemplate as ScopesScreenTemplate;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ScreenTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'template_id',
        'screen_id',
        "to","from","created_at",
        "updated_at",
    ];
  
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        
    ];
      protected static function booted()
       {
          static::addGlobalScope(new ScopesScreenTemplate);
       } 

    public function Screens(){
        return $this->belongsTo(Screens::class,"screen_id","id");
    }

    public function menus(){
        return $this->belongsTo(Menu::class,"template_id");
    }
}
