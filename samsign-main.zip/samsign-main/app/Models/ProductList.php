<?php

namespace App\Models;
use App\Models\Scopes\ListProduct;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductList extends Model
{
    use HasFactory;
    protected static function booted()
     {
        static::addGlobalScope(new ListProduct);
     } 

    protected $fillable = ["list_id","product_id"];
    
    public function Products(){
        return $this->belongsTo(Product::class,"product_id","id");
     }
}
