<?php

namespace App\Models;

use App\Models\Scopes\Products;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $table = "productss";
    protected $fillable = [
      'name',
      'description',
      'category_id',
      'user_id',
      'status',
      'id'
  ];

  /**
   * The attributes that should be hidden for serialization.
   *
   * @var array<int, string>
   */
  protected $hidden = [
      "created_at",
      "updated_at",
      'category_id',
      'user_id',
      'status',
  ];
    protected static function booted()
     {
        static::addGlobalScope(new Products);
     } 

     public function sizes(){
        return $this->hasMany(Size::class,"product_id","id");
     }
}
