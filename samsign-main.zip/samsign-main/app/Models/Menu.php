<?php

namespace App\Models;

use App\Models\Scopes\Menu as ScopesMenu;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    use HasFactory;

    protected $fillable = [
      'name',
      'image',
      'view',
      "height",
      "width",
      'status',
      'video',
      'preview',
      'type',
      "user_id",
      "created_at",
      "updated_at",
      "template",
      "style",
      "num",  "history"
    
  ];

  /**
   * The attributes that should be hidden for serialization.
   *
   * @var array<int, string>
   */
  protected $hidden = [
     
  ];

    protected static function booted()
     {
        static::addGlobalScope(new ScopesMenu);
     } 
   public function Tempalet(){
         return $this->belongsTo(Menu::class,"template");
   }

     public function Lists(){
        return $this->hasMany(Lists::class,"menu_id","id");
     }
     

     public function ListsDesign(){
        return $this->hasMany(menuContent::class,"menu_id","id");
     }


     public function screens(){
        return $this->hasMany(ScreenTemplate::class,"template_id","id");
     }
     public function ListTemplate(){
      // return $this->hasMany(ListTemplate::class,"menu_id","id");
   }
   public function DesignTemplate(){
      return $this->hasMany(DesignTemplate::class,"menu_id","id");
   }
   
   public function ProductContentList(){
        return $this->hasMany(ProductContentList::class,"menu_id","id");
   }
}
