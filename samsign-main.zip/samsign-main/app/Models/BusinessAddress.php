<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BusinessAddress extends Model
{
    use HasFactory;

    protected $fillable = ["city_id","country_id","street_name","postal_no","user_id"];
    protected $hidden = ["created_at","updated_at","user_id"];

    public function country(){
        return $this->belongsTo(Country::class,"country_id");
    }

    public function city(){
        return $this->belongsTo(City::class,"city_id");
    }
}

