<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductContentList extends Model
{
    use HasFactory;
    protected $fillable = ['value','menu_id','order'];
}
