<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Models\Scopes\ActiveUserScope;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */

     protected static function booted()
     {
        static::addGlobalScope(new ActiveUserScope);
     } 
    protected $fillable = [
        'username',
        'email',
        'password',
        'phone',
        'platform',
        "fcm_token",
        "image",
        "status",
        "password_text"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        "created_at",
        "updated_at",
        "email_verified_at","fcm_token","platform"
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];
    
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }


 public function getJWTCustomClaims()
    {
        return ["token"];
    }

    public function Address(){
        return $this->hasMany(BusinessAddress::class,"user_id","id");
    }

    public function Menus(){
        return $this->hasMany(Menu::class,"user_id","id");
    }

    public function Products(){
        return $this->hasMany(Product::class,"user_id","id");
    }


    public function Business(){
        return $this->hasOne(BusinessDetails::class,"user_id","id");
    }   
    
     public function ForgetPassword(){
        return $this->hasOne(ForgetPassword::class,"user_id","id");
    }   
    
    public function ActiveUser(){
        return $this->hasOne(ActiveUser::class,"user_id","id");
    }
     public function screens(){
        return $this->hasMany(Screens::class,"user_id","id");
    }
}
