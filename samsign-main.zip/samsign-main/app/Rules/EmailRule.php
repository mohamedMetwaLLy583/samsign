<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class EmailRule implements ValidationRule
{
    
     public function passes($attribute, $value)
    {
        if($value == AuthApi()->email){
            false;
        }
    return true;
    }
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if($value == AuthApi()->email){
            $fail('The data is invalid.');
        }
    }


    public function message()
    {
        return 'The :attribute must be ';
    }
}
