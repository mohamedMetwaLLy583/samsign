<?php

use Illuminate\Support\Facades\Auth;
use App\Models\FontFamil;
if(!function_exists("AuthApi")){
    function AuthApi(){
        return Auth::guard("api")->user();
    }
}

if(!function_exists("AuthAdmin")){
    function AuthAdmin(){
        return Auth::guard("admin")->user();
    }
}

if(!function_exists("fontfamily")){
    function fontfamily(){
        $fonts = FontFamil::get();
        return $fonts; 
    }
}

if (!function_exists('send_notification')) {
    function send_notification($ids, $title, $message, $type)
    {
        
        $access_token = 'AAAAZrZM90o:APA91bFT47emzJKYgQouP0-1IGdUlb3toEd8KaxV3EOdLVrsMRFkeEFNFFxFinP9yElNbVVa5lYZacAybb6O9v5HwTnhPVktVyCS-kvX-9E1bBRscxoFHYzYr-mnh-mFaCYAI32bMfV4';
        // $access_token = '';
        $url = "https://fcm.googleapis.com/fcm/send";
        $post_data = [
            'registration_ids' => $ids,
            'data' => [
                'body' => $message,
                'title' => $title,
                'type' => $type,
            ],
            'notification' => [
                'body' => $message,
                'title'=> $title,
                'type' => $type,
                'sound' => 'default'
            ]
        ];
        $crl = curl_init();

        $headr = array();
        $headr[] = 'Content-type: application/json';
        $headr[] = 'Authorization: KEY=' . $access_token;
        curl_setopt($crl, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($crl, CURLOPT_URL, $url);
        curl_setopt($crl, CURLOPT_HTTPHEADER, $headr);

        curl_setopt($crl, CURLOPT_POST, true);
        curl_setopt($crl, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($crl, CURLOPT_RETURNTRANSFER, true);

        $rest = curl_exec($crl);
        if ($rest === false) {
            $result_noti = 0;
        } else {
            $result_noti = 1;
        }
        return $result_noti;
    }
}


if (!function_exists('store_notification')){
    function store_notification($id,$title,$body,$typee){
        \App\Models\notification::create([
            "notifiable_id"=>$id,
            "title"=>$title,
            "body"=>$body,
            "type"=>$typee,
        ]);
    }
}