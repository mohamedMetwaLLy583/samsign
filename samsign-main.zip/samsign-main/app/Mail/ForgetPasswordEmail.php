<?php
namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
class ForgetPasswordEmail extends Mailable
{
    use Queueable, SerializesModels;
    public $name;
   public $code;
    public function __construct($name,$code)
    {
        $this->name = $name;
        $this->code = $code;
    }
    public function build()
    {
        $data = [
            "name"=>$this->name,
            "code"=>$this->code,
        ];
        return $this->view('mail.forgetPassord',compact("data"));
    }
}