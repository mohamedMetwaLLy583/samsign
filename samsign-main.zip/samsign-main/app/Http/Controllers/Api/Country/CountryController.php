<?php

namespace App\Http\Controllers\Api\Country;

use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\BusinessAddress;
class CountryController extends Controller
{
    public function country(){
         $countries = Country::get();
        $data = [];
        foreach($countries as $country){
            $data [] = [
                "id"=>$country->id,
                "image"=>asset($country->image),
                "name"=>$country->name
            ];
        }
        $this->setDate("",$data);
        $this->setMessage("success");
        $this->setStatus(200);
        return $this->SendApiResponse();
    }
    
    
      public function codeNumber(){
        $countries = Country::get();
        $data = [];
        foreach($countries as $country){
            $data[] = [
                "id"=>$country->id,
                "image"=>asset($country->image),
                "code"=>$country->code,
                "name"=>$country->name
            ];
        }
        $this->setDate("",$data);
        $this->setMessage("success");
        $this->setStatus(200);
        return $this->SendApiResponse();
    }

    public function getAddress(){
        $data = [];
        $address = BusinessAddress::with(['country','city'])->get();
        foreach($address as $value){
            $data[] = [
                'id'=>$value->id,
                'name'=>$value->country->name.','.$value->postal_no.','.$value->city->name.','.$value->street_name,
                'city_id'=>$value->city_id,
                'country_id'=>$value->country_id,
                'postal_no'=>$value->postal_no,
                'street_name'=>$value->street_name,
            ];
        }
        $this->setDate("",$data);
        $this->setStatus(200);
        $this->setMessage("success");     
        return $this->SendApiResponse();
    }
}
