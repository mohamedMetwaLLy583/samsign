<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\ForgetPasswordRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Mail\ForgetPasswordEmail;
use Illuminate\Support\Facades\Mail;
// use App\Notifications\ForgetPassword;
class ForgetPasswordController extends Controller
{
    public function ForgetPassword(ForgetPasswordRequest $request){
      
        // try{
            $user = User::where("email",$request->email)->first();
            // $code  = rand(100000, 1000000);
            $code  = 123456;
            $user->ForgetPassword()->create([
                "code"=>$code
            ]);
            Mail::to($user->email)->send(new ForgetPasswordEmail($user->username,$code));
            $this->setMessage("لقد تم اارسال الكود الي حساب الايميل الخاص بك من فضلك قم بفحص البريد الالكتروني");
            $this->setStatus(200);
        // }catch(\Exception $e){
        //     $this->setStatus(422);
        //     $this->setMessage("failed");
        // }
         
        return $this->SendApiResponse();
    }

}
