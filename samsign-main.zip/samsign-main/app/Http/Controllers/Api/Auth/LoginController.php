<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\LoginRequest;
use App\Http\Resources\Api\User\ApiUserResponse;
use App\Models\QrCodeUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Nette\Utils\Random;
use Tymon\JWTAuth\Facades\JWTAuth;

class LoginController extends Controller
{

    public function authentication(LoginRequest $request){
        try{
            $BusinessDetail = BusinessDetail::where("name",$request->username)->first();
            $data = ["id"=>$BusinessDetail->user_id,"password"=>$request->password];
            $token = Auth::guard('api')->attempt($data);
            if($token){
                $user = AuthApi();
                 $user->fcm_token = $request->fcm_token;
                 $user->platform = $request->platform;
                 $user->save();
                $user->token =  JWTAuth::fromUser($user);
                $result = new ApiUserResponse($user);$this->setDate("",$result);
                $this->setStatus(200);
                $this->setMessage("success");
                
            }else{
                $this->setStatus(422);
                $this->setMessage("your username Or Password Invilad");
            }
            
        }catch(\Exception $e){
            $this->setStatus(422);
            $this->setMessage("unathintacted");     
        }
        return $this->SendApiResponse();
    }



    public function QRcode(){ 
        $qrCode = "SAMSIGN".bcrypt(Random::generate(70));
        $checkQrCode = QrCodeUser::where([["key",$qrCode],["status","<>","0"],["user_id",null]])->first();
        if($checkQrCode){
           
            $this->setDate("",["key"=>$qrCode,"status"=>"proccess"]);
        }else{
            $checkQrCodeFound = QrCodeUser::where([["key",$qrCode],["status","0"],["user_id","<>",null]])->first();
            if($checkQrCodeFound){
                $qrCode = "SAMSIGN".bcrypt(Random::generate(70));
                QrCodeUser::create([
                    "key"=>$qrCode,
                    "status"=>"1",
                ]);
                $this->setDate("",["key"=>$qrCode,"status"=>"proccess"]);
            }else{
                QrCodeUser::create([
                    "key"=>$qrCode,
                    "status"=>"1",
                ]);
                $this->setDate("",["key"=>$qrCode,"status"=>"proccess"]);
            }
        }
        $this->setStatus(401);
        $this->setMessage("success");
        return $this->SendApiResponse();
    }


    public function scanQrCode(Request $request){  
        $checkQrCode = QrCodeUser::where([["key",$request->key],["status","<>","0"],["user_id",null]])->first();
        $user = User::where([["id",$request->id],["username",$request->username]])->first();
        if($user && $checkQrCode){
            $checkQrCode->user_id = $request->id;
            $checkQrCode->status = "0";
            $checkQrCode->save();
            $user->token =  JWTAuth::fromUser($user);
            $result = new ApiUserResponse($user);
            $this->setDate("",$result);
            $this->setStatus(200);
            $this->setMessage("success");
        }else{
            $this->setStatus(422);
            $this->setMessage("your data is not right");
        }

        return $this->SendApiResponse();
    }

    public function CheckQrCode(Request $request){  
        $checkQrCode = QrCodeUser::where([["key",$request->key],["status","0"],["user_id","<>",null]])->first();
        
        if($checkQrCode){
            $this->setStatus(200);
            $this->setMessage("success");
            $user = User::find($checkQrCode->user_id);
            $user->token =  JWTAuth::fromUser($user);
            $result = new ApiUserResponse($user);
            $checkQrCode->delete();
            $this->setDate("",$result);
        }else{
            $this->setDate("",["key"=>$request->key,"status"=>"proccess"]);
            $this->setStatus(401);
            $this->setMessage("success");
        }
       
        return $this->SendApiResponse();
    }



}
