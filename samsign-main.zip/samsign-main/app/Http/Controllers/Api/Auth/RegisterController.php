<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\RegisterRequest;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Resources\Api\User\ApiUserResponse;
use App\Models\User;
use App\Mail\ActiveCodeEmail;
use Illuminate\Support\Facades\Mail;
class RegisterController extends Controller
{

    public function store(RegisterRequest $request){

        try{
            $datauser = $request->except(["business","address"]);
            $dataaddress = $request->except(["personal","business"]);
            $databussines = $request->except(["address","personal"]);
            $user = User::create($datauser["personal"]);
            $user->Address()->create($dataaddress["address"]);
            $user->Business()->create($databussines["business"]);
            $code  = 123456;
            $user->ActiveUser()->create([
                "code"=>$code,
                "status"=>"0",
            ]);
            
            if($datauser["personal"]["image"]){
                $user->image = $request->personal["image"];
                $user->save();
            }
            Mail::to($user->email)->send(new ActiveCodeEmail($user->username,$code));
            $user->password_text = $request->personal['password'];
            $user->save();
            
            $getUser = User::find($user->id);
            $getUser->load(["Address","Business","ActiveUser"=>function($query){
                $query->where("status","0");
            }]);
            $getUser->token = JWTAuth::fromUser($getUser);
            $this->setDate('',new ApiUserResponse($getUser)); 
            $this->setMessage("Your data has been successfully registered and a verification code has been sent to your email. Please check your email");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setStatus(422);
            $this->setMessage("failed");
        }
         
        return $this->SendApiResponse();
    }
}
