<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\ResetPasswordRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ResetPasswordController extends Controller
{
    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
    public function Reset(ResetPasswordRequest $request){
        try{
            
            if(Hash::check($request->password,$this->user->password)){
                $this->setMessage("The New Password is same Old Password");
            }else{
                $this->user->update([
                    "password" => Hash::make($request->password),
                    "password_text"=>$request->password,
                ]);
               
                $this->setMessage("Have Been success change");
            }
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("Faild Request");
            $this->setStatus(500);
        }

        return $this->SendApiResponse();
    }


    public function change(ResetPasswordRequest $request){
        try{
            $this->user->update([
                "password" => Hash::make($request->password),
                "password_text"=>$request->password,
            ]);
            $this->setMessage("Have Been success change");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("Faild Request");
            $this->setStatus(500);
        }

        return $this->SendApiResponse();
    }
  
    
}
