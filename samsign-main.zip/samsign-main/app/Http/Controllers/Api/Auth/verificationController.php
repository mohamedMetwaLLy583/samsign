<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Models\ForgetPassword;
use App\Models\ActiveUser;
use App\Http\Requests\Api\Auth\ForgetPasswordRequest;
use App\Http\Resources\Api\User\ApiUserResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Mail\ForgetPasswordEmail;
use Illuminate\Support\Facades\Mail;
use App\Mail\ActiveCodeEmail;
class verificationController extends Controller
{
    public function checkCodeForget(ForgetPasswordRequest $request){
        $id_user = User::where("email",$request->email)->first()->id;
        $activeuser = ForgetPassword::where([["code",$request->code],["user_id",$id_user]])->first();
        $code  = 123456;
        if($activeuser){
         if(!$activeuser->status):
                $activeuser->update([
                    "status"=>"1"
                ]);
                $user = User::find($activeuser->user_id);
                $user->token = JWTAuth::fromUser($user);
                 $result = new ApiUserResponse($user);
                $this->setDate("",$result);
                $this->setStatus(200);
                $this->setMessage("success");
                return $this->SendApiResponse();
               
        endif;
            $activeuser->update([
                "status"=>"0",
                "code"=>$code,
            ]);
            $user = User::find($activeuser->user_id);
            Mail::to($user->email)->send(new ForgetPasswordEmail($user->username,$code));
            $this->setMessage("لقد تم اارسال الكود الي حساب الايميل الخاص بك من فضلك قم بفحص البريد الالكتروني");
            $this->setStatus(200);
          
        }else{
            $this->setStatus(422);
        $this->setMessage("البريد الالكتروني ليس موجود");

           
        }
        
         return $this->SendApiResponse();

    }


    public function resend(ForgetPasswordRequest $request){
      
        try{
            $user = User::where("email",$request->email)->first();
          $code  = 123456;
            if($request->status){
                
                 $user->ActiveUser()->create([
                    "code"=>"123456",
                    "status"=>"0",
                ]);
            }else{
                $user->ForgetPassword()->create([
                    "code"=>$code
                ]);
            }
            Mail::to($user->email)->send(new ActiveCodeEmail($user->username,$code));
            $this->setMessage("لقد تم اارسال الكود الي حساب الايميل الخاص بك من فضلك قم بفحص البريد الالكتروني");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setStatus(422);
            $this->setMessage("failed");
        }
        return $this->SendApiResponse();
    }
    
    
    
    public function checkCodeUser(Request $request)
    {
        
         $validator = Validator::make($request->all(), [
             "email"=>"required|email|exists:users,email",
             "code"=>"required|string|min:6"
          ]);
          if ($validator->fails()) {
                $this->setMessage($validator->errors()->first());
                $this->setStatus(422);
                return $this->SendApiResponse();
          }
        $id_user = User::where("email",$request->email)->first()->id;
        $activeuser = ActiveUser::where([["code",$request->code],["user_id",$id_user]])->first();
        $code  = 123456;
      
        if($activeuser){
            if($activeuser->status == false):
                $activeuser->update([
                    "status"=>"1"
                ]);
                $user = User::find($activeuser->user_id);
                $user['token'] = JWTAuth::fromUser($user);
                $this->setMessage(__("api.auth.active"));
                $this->setStatus(200);
                 $result = new ApiUserResponse($user);
                $this->setDate("",$result);
                return $this->SendApiResponse();
            endif;
            $activeuser->update([
                "status"=>"0",
                "code"=>$code,
            ]);
            $user = User::find($activeuser->user_id);
            Mail::to($user->email)->send(new ActiveCodeEmail($user->username,$code));
             $this->setMessage("لقد تم اارسال الكود الي حساب الايميل الخاص بك من فضلك قم بفحص البريد الالكتروني");

            $this->setStatus(200);
            
             return $this->SendApiResponse();
        }else{
        $this->setMessage("البريد الالكتروني ليس موجود");

            $this->setStatus(422);
             return $this->SendApiResponse();

        }

    }

}
