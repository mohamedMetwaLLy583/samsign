<?php

namespace App\Http\Controllers\Api\notifications;
use App\Http\Controllers\Controller;
use App\Models\notification;
use Carbon\Carbon;
use Auth;
class notificationController extends Controller
{

    public function index()
    {
        $user = AuthApi();
        $notificatios = notification::where("notifiable_id",$user->id)->get();
        if($notificatios->count() > 0){
            $this->setDate("",$this->Filter($notificatios));
        }
         return $this->SendApiResponse();
    }


    public function Filter($request)
    {
        $notificatios = $request;
        $data = [];
        // $now = Carbon::now();
        if(count($notificatios) > 0){
          foreach ($notificatios as $notificatio):
            // $created_at = Carbon::parse($notificatio->created_at);
            // $diffHuman = $created_at->diffForHumans($now);
                  $data[] = [
                    "id"=>$notificatio->id,
                    "title"=>$notificatio->title,
                    "body"=>$notificatio->body,
            ];
          endforeach;
        }
        return $data;
    }
}
