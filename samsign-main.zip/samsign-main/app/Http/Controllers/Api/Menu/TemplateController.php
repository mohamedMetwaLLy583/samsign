<?php

namespace App\Http\Controllers\Api\Menu;

use App\Http\Controllers\Controller;
use App\Models\DesignTemplate;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage as FacadesStorage;
use Spatie\Browsershot\Browsershot;
use App\Models\menuContent;
use App\Models\ProductContentList;
class TemplateController extends Controller
{
    public function index(Request $request){
        if($request->view == "0" || $request->view == "1"){
            $menus = Menu::select()->where("view",$request->view)->where("type","0")->paginate(8);
                $this->setMessage("success");
            $this->setDate("",$menus);
            return $this->SendApiResponse();
        }
        $menus = Menu::select()->where("type","0");
        $users = $menus->paginate(8);
        return view("Dashboard.Template.index",compact('users'));
    }

    public function show($id){
        $menu = Menu::find($id);
        $menu->load('DesignTemplate');
        $layers = $menu->DesignTemplate;
        $this->setMessage("success");
        $this->setDate("",['layers'=>$layers,'menu'=>$menu]);
        return $this->SendApiResponse();
    }


    public function store(Request $request){
        $allchildern = [];
        $images=[];
        $videos=[];
        $menu = Menu::find($request->id);
        $menu->update([
            'history'=>$request->history?json_encode($request->history):$menu->history,
            'preview'=>$this->convertImage($request->image),
        ]);

        if(isset($request->layers)){
            $menu->DesignTemplate()->delete();
            foreach($request->layers as $index=>$value){
                $result = json_decode($value)->attrs;
                $menu->DesignTemplate()->create([
                    "type"=>isset($result->name)?$result->name:"background",
                    "file"=>isset($result->name) ? $result->name == 'image' || $result->name == 'video'?$result->class:null:null,
                    "content"=>json_encode($result),
                ]);
            }
        }
       
        $this->setMessage("success");
        return $this->SendApiResponse();
        
    }

    public function updata(Request $request,$id){
        $request->validate([
            'view'=>"required|string|in:1,0",
            'width'=>"required",
            'height'=>"required",
        ]);
        $menu = Menu::find($id);
        $menu->update([
            // 'view'=>$request->view,
            // 'width'=>(string)$request->width,
            // 'height'=>(string)$request->height,
            'name'=>$request->name
        ]);
        $this->setMessage("success");
        return $this->SendApiResponse();
    }

    public function convertImage($image){
        $image = $image;
        $imageInfo = explode(";base64,", $image);
        $imgExt = str_replace('data:image/', '', $imageInfo[0]);
        $image = str_replace(' ', '+', $imageInfo[1]);
        $imageName = "post-".time().".".$imgExt;
        FacadesStorage::disk('local')->put("storage/Template/Preview/".$imageName, base64_decode($image));
        return "storage/Template/Preview/".$imageName;
    }

    

   

 







   
     

    

    public function destroy(Request $request){
        $menu = Menu::find($request->id);
        $menu->load("DesignTemplate");
        $menu->DesignTemplate()->delete();
        $menu->delete();
        return Response::json(["message"=>"success deleted"],200);
    }

    public function getTemplate($id){
        $menu = Menu::find($id);
        $template = Menu::where("type","0")->get();
        $menu->load(['ListTemplate','ListTemplate.sizes','DesignTemplate'=>function($query){
            return $query->orderByDESC("zindex");
        }]);
        $allchildern = [];
        $images=[];
        $videos=[];
        foreach($menu->DesignTemplate as $value){
            if(json_decode($value->content)){
                // foreach(json_decode($value->content) as $v){
                if($value->type == 'menu'){
                    $allchildern[] = $this->Listmenu($id,$value->content,$value->num);
                }elseif($value->type == 'image'){
                    $images[] = json_decode($value->content);
                }elseif($value->type == 'video'){
                    $videos[] = json_decode($value->content);
                }else{
                    $allchildern[] = json_decode($value->content);
                }
                // }
            }
        }
//        $layers = json_decode($menu->DesignTemplate[0]->content);
        $layers = $allchildern;

        return response()->json(["menu"=>$menu,"layers"=>$layers,'images'=>$images,'videos'=>$videos],200);
    }

public function Listmenu($id,$menu,$numlist){
    $tmenu = Menu::find($id);
    $resultfinal = json_decode($menu);
    $imdproduct = count($tmenu->lists) > 0?count($tmenu->lists[0]->products):0;
    $numproduct = 0;
    $indexsize = 0;
    $imdsize = 0;
    $numlist = $numlist;
    if($imdproduct > 0){
           foreach(json_decode($menu)->children as $value){
        if(isset($value->children)){
            $products = [];
            $sizetext = [];
            $sizeprice = [];
            $info =[];
            $finallResult = [];
            foreach($value->children as $res){
                $classNameO = (string)$res->className;
                $objsva = json_encode($res);
                if($res->className == 'Text'){
                    $groubBy = $res->attrs->text;
                    if($res->attrs->text == 'Title Menu'){
                        $res->attrs->text = $tmenu->lists[$numlist]->name;
                        $resultfinal->children[0]->children[] = $res;
                    }

                    if($res->attrs->text == '120' && $tmenu->lists[$numlist]->status_price == '1'){
                        $res->attrs->text = $tmenu->lists[$numlist]->price;
                        $resultfinal->children[0]->children[] = $res;
                    }

                    if($res->attrs->text == 'product' && $numproduct < $imdproduct){
                        $res->attrs->text = $tmenu->lists[$numlist]->products[$numproduct]->products->name;
                        // $imdsize += $tmenu->lists[$numlist]->products[$numproduct]->sizes != null ?count($tmenu->lists[$numlist]->products[$numproduct]->sizes):0;

                        $numproduct++;
                        $resultfinal->children[0]->children[] = $res;

                    }
                    if($res->attrs->text == 'info' && $numproduct < $imdproduct){
                        $res->attrs->text = $tmenu->lists[$numlist]->products[$numproduct]->products->description;
                        $numproduct++;
                        $resultfinal->children[0]->children[] = $res;
                        $info[] = $res;
                    }
                    if($res->attrs->text == 'sm'){
                        $resultfinal->children[0]->children[] = $res;
                    }
                    if($res->attrs->text == '12' && $numproduct < $imdproduct){
                        $listsProducts = ProductContentList::where("menu_id",$tmenu->template)->where('order',$numlist)->get();
                        foreach($listsProducts as $products){
                            foreach(json_decode($products->value)->price as $index=>$valuepri){
                                if($tmenu->lists[$numlist]->products[$numproduct]->products->sizes){
                                    $valuepri->attrs->text = (count($tmenu->lists[$numlist]->products[$numproduct]->products->sizes) > $index)?$tmenu->lists[$numlist]->products[$numproduct]->products->sizes[$index]->price:0;
                                    $resultfinal->children[0]->children[] = $valuepri;

                                }
                            }
                            break;
                        }

                        // ;
                        // $indexsize++;
                        // $sizeprice[] = $res;
                    }
                }else{
                    $resultfinal->children[0]->children[] = $res;
                }
            }
            $priceresult = [];
            $start = 0;
            // for ($i=1; $i <= count($products); $i++) {
            //         $priceresult[] = array_slice($sizeprice, $start, count($sizetext));
            //         $start += count($sizetext);
            // }
            // foreach($products as $index => $final){
            //     $finallResult[] = [
            //         'product'=>$final,
            //         'info'=> (count($info)==count($products))?$info[$index]:'',
            //         'price'=> (count($priceresult) > 0)?$priceresult[$index]:[],
            //     ];
            // }

        }
    }
    }
 

    // return $finallResult;

    $products = [];
    $sizetext = [];
    $sizeprice = [];
    $info =[];
    $finallResult = [];
    return $resultfinal;
}
}
