<?php



namespace App\Http\Controllers\Api\Menu;



use App\Http\Controllers\Controller;

use App\Http\Requests\Api\Menu\ListRequest;

use App\Http\Requests\Api\Menu\MenuRequest;

use App\Http\Resources\Api\Menu\MenuResource;

use App\Http\Resources\Api\Menu\TemplateResource;

use App\Models\Menu;

use App\Models\ListTemplate;

use App\Models\Lists;

use Illuminate\Http\Request;
use App\Models\DesignTemplate;


use Pdfcrowd\HtmlToImageClient;
use App\Models\FontFamil;




class MenuController extends Controller

{



    public $user;

    public function __construct(){

        $this->user = AuthApi();

    }

    /**

     * Display a listing of the resource.

     */

    public function index()

    {





        $menus = $this->user->load([

            "Menus"

        ])->Menus;

        $menus->load("Tempalet");

     

        $data = [];

        foreach($menus as $menu){

            $data[] = [

                "id"=>$menu->id,

                "name"=>$menu->name,

                "image"=>asset($menu->preview!=null?$menu->preview:"Dashboard/image/logo.png"),

            ];

        }

        $this->setMessage("success");

        $this->setDate("",$data);

        return $this->SendApiResponse();

    }



    /**

     * Store a newly created resource in storage.

     */

    public function store(MenuRequest $request)

    {

        $menus = $this->user->Menus()->create([

            "name"=>$request->name,

            "view"=>$request->view?$request->view:"0",

        ]);

        

        if($request->file){
            $menus->image = $request->file("file")->store("storage/menu");
            $menus->save();

            // $client = new HtmlToImageClient("demo", "ce544b6ea52a5621fb9d55f8b542d14d");

            // $client->setOutputFormat("png");

            // $filname = md5("SAMSIGN".date("Y-M-D H:M:S a"));

            // $image = $client->convertUrlToFile("https://verasign.se/Dashboard/show/template/$menus->id", "storage/Template/preview/"."$filname.png");

            // $menus->preview = "storage/Template/preview".$filname.png;

            // $menus->save();

        }

        

        if($request->template){

            $menus->template= $request->template;
            $menus->style= Menu::find($request->template)->style;
            $menus->width= Menu::find($request->template)->width;
              $menus->height= Menu::find($request->template)->height;
            // $menus->preview= $request->preview;
            $menus->preview= Menu::find($request->template)->preview;
            $menus->image = Menu::find($request->template)->image;
            $menus->view = $request->view;
            $menus->save();
             $templateDesign = DesignTemplate::where("menu_id",$request->template)->get();
            foreach($templateDesign as $index=>$value){
                DesignTemplate::create([
                                "menu_id"=>$menus->id,
                                "type"=>$value->type,
                                "content"=>$value->content,
                                "lock"=>$value->lock,
                                "hidden"=>$value->hidden,
                                "zindex"=>$value->zindex,
                                "dataid"=>$value->dataid,
                                "targetlayer"=>$value->targetlayer,
                                'num'=>$value->num,
                ]);
            }


        }

        

        

         $this->setDate("",[
                "id"=>$menus->id,
                "name"=>$menus->name,
                "image"=>asset($menus->preview!=null?$menus->preview:"Dashboard/image/logo.png"),
                ]);

            $this->setMessage("success Create Menu");

            return $this->SendApiResponse();

        

    }

    

     public function edit(MenuRequest $request,$id)

    {  

        $menu = Menu::find($id);

        $menu->update([

            "name"=>$request->name,

            "view"=>$request->view,

        ]);

        

        if($request->file){
            $menu->image= $request->file("file")->store("storage/menu");
            $menu->save();
        }

        

        if($request->template){

            $menu->template= $request->template;
            $menus->style= Menu::find($request->template)->style;
            $menus->width= Menu::find($request->template)->width;
            $menus->height= Menu::find($request->template)->height;
            $menu->preview= Menu::find($request->template)->preview;
            $menu->image= Menu::find($request->template)->image;
            $menu->save();
            
            $find = DesignTemplate::where("menu_id",$menu->id)->get();
            if(!$find){
            DesignTemplate::where("menu_id",$menu->id)->delete();
            $templateDesign = DesignTemplate::where("menu_id",$request->template)->get();
            foreach($templateDesign as $index=>$value){
                DesignTemplate::create([
                                "menu_id"=>$menu->id,
                                "type"=>$value->type,
                                "content"=>$value->content,
                                "lock"=>$value->lock,
                                "hidden"=>$value->hidden,
                                "zindex"=>$value->zindex,
                                "dataid"=>$value->dataid,
                                "targetlayer"=>$value->targetlayer,
                                'num'=>$value->num,
                ]);
            }
            }
            

        }

        

        

         $this->setDate("",[

                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>asset($menu->preview!=null?$menu->preview:"Dashboard/image/logo.png"),
                ]);

            $this->setMessage("success edit Menu");

            return $this->SendApiResponse();

        

    }

    

    

        public function liststore(ListRequest $request){

            $menu = Menu::find($request->id);

            $listvalues = $menu->Lists()->create([

                'name'=>$request->name,

                'price'=>$request->status_price?$request->price:0,

                'status_price'=>$request->status_price,

                "category_id"=>$request->category_id,

            ]);

            foreach($request->product as $value){

                $product = $listvalues->Products()->create([

                    "product_id"=>$value,

                ]);                

             }

            $this->setMessage("success Create Menu");

            return $this->SendApiResponse();

    }

    

    

     public function MenuLists(string $id){

        $id_template = Menu::find($id);

        $template = Menu::with(["ListTemplate"])->where("id",$id_template->template)->first();


        $data = [];

        $i=1;

        if(count($template->ListTemplate) > 0){

                 foreach($template->ListTemplate as $list){
                    $data[]= [
                        "id"=>(int)($list->id."01024372350"),
                        "name"=>"List".$i,
                        "products"=>(int)$list->product_number,
                        "image"=>asset($id_template->preview!=null?$id_template->preview:"Dashboard/image/logo.png"),

                    ];

                    $i++;

                }   

            }

        $this->setMessage("success");

        $this->setDate("",$data);

        return $this->SendApiResponse();

        

    }

    

    public function editliststore(ListRequest $request,$id){

            $list = Lists::find($id);

            $list->update([

                'name'=>$request->name,

                'price'=>$request->status_price?$request->price:0,

                'status_price'=>$request->status_price,

                "category_id"=>$request->category_id,

            ]);

            $list->Products()->delete();

            foreach($request->product as $value){

                $product = $list->Products()->create([

                    "product_id"=>$value,

                ]);                

             }

            $this->setMessage("success edit List");

            return $this->SendApiResponse();

    }



    /**

     * Display the specified resource.

     */

    public function show(string $id)

    {

        $menu = Menu::find($id);

        $menu->load("screens","Tempalet");

        if($menu->type == "0"){

            $menu->load('ListTemplate');

            $this->setDate("",new TemplateResource($menu));

        }else{

             $menu->load("Tempalet");

            $this->setDate("",new MenuResource($menu));

        }

        $this->setMessage("success");

        

        return $this->SendApiResponse();

    }

    

    

     public function showlist(string $id)

    {

        $idarray = explode("010243",$id);

        $data = []; 

        if(count($idarray)){

            $id = $idarray[0];
            $list = ListTemplate::with(["sizes"])->where("id",$id)->first();
           $this->setMessage($list);

        // $this->setDate("",$data);

        return $this->SendApiResponse();
            $data = [

                "preview"=>asset(Menu::find($list->menu_id)->preview),

                "id"=> 1,

                "name"=> "List",

                "status_price"=> $list->list_price,

                "price"=> 0,

                "list_preview"=>asset(Menu::find($list->menu_id)->preview),

                "category"=>1,

                ];

                if($list->product_number > 0){

                    for($i=1;$i<=$list->product_number;$i++){

                        $data["products"][]=[

                         "id"=> 0,

                        "name"=> "Product".$i,

                        "sizes"=>[

                            [

                                "size"=>1,

                                "price"=>1,

                            ]]

                       ]; 

                    }

                //  foreach($list->products as $value){

                   

                //     }    

                }else{

                    $data["products"] = [];

                }

        }else{

            $id = $idarray[0];

            $list = Lists::with(["Categories"])->where("id",$id)->first();

            

             $data = [

        "preview"=>asset(Menu::find($list->menu_id)->preview),

        "id"=> $list->id,

        "name"=> $list->name,

        "status_price"=> $list->status_price,

        "price"=> $list->status_price?$list->price:0,

        "list_preview"=>asset(Menu::find($list->menu_id)->preview),

        "category"=>$list->Categories,

        ];

        if($list->products){

            foreach($list->products as $value){

            $data["products"][]=[

                 "id"=> $value->products->id,

                "name"=> $value->products->name,

                "sizes"=>$value->products->sizes

            ];

            }    

        }else{

            $data["products"] = [];

        }

        }

        

        

       

        

        $this->setMessage("success");

        $this->setDate("",$data);

        return $this->SendApiResponse();

    }



    /**

     * Update the specified resource in storage.

     */

    public function update(Request $request, string $id)

    {

        //

    }



    /**

     * Remove the specified resource from storage.

     */

    public function destroy(string $id)

    {
        
        DesignTemplate::where("menu_id",$id)->delete();
        Lists::where("menu_id",$id)->delete();
        Menu::where([["id",$id],["user_id",$this->user->id]])->delete();

        $this->setMessage("success Deleted");

        return $this->SendApiResponse();

    }

    

     public function listdestroy(string $id)

    {

        $list = Lists::find($id);

        $list->Products();

        $list->delete();

        $this->setMessage("success Deleted");

        return $this->SendApiResponse();

    }

    

    public function templates()

    {

        $menus = Menu::where("type","0")->get();

        $data = [];

        foreach($menus as $menu){
            $data[] = [
                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>asset($menu->preview),

            ];

        }

        $this->setDate("",$data);

        $this->setMessage("success");

        return $this->SendApiResponse();

    }


    public function deleteimage($id){
        $menu = Menu::find($id);
        // unlike($menu->image);
        $menu->image = null;
        $menu->save();
        $this->setMessage("success");
        return $this->SendApiResponse();
    }
    
    public function menuText($id){
        $menu = Menu::find($id);
        $data = [];
        if($menu){
            $menu->load(["Tempalet"]);
        $templateDesign = DesignTemplate::where("menu_id",$menu->id)->where("type","text")->get(['id','num',"type","content"]);
        
        if(count($templateDesign) > 0){
             $data["titleTemplate"]=[
                            "id"=>$templateDesign[0]->id,
                            "text"=>"title Menu",
                            "oldtext"=>"title Menu",
                    ];      
        }
        if(count($templateDesign) > 0){
            foreach($templateDesign as $index=>$value){
            foreach(json_decode($value->content)->children as $value2){
                if($value2->className == "Text"){
                    $data["group1"][]=[
                      "id"=>$value->id,
                      "text"=>$value2->attrs->text,
                       "oldtext"=>$value2->attrs->text,
                    ]; 
                }
                
            }
            }  
        }    
        }
        
      
        
        
       $this->setDate("",$data);

        $this->setMessage("success");

        return $this->SendApiResponse();
    }
    
    public function updatemenuText(Request $request){
        // return $request;
        $data= [];
        if($request->data && count($request->data) > 0){
                foreach($request->data as $editobject){
            $templateDesign = DesignTemplate::where("id",$editobject['id'])->where("type","text")->first();
          If($templateDesign){
            $design = json_decode($templateDesign->content);
            foreach($design->children as $index=>$value2){
                if($value2->className == "Text" && $value2->attrs->text == $editobject['oldtext']){
                    $value2->attrs->text = $editobject['text'];
                    $templateDesign->content = json_encode($design);
                    $templateDesign->save();
                }
            }
            }
        }
            
        }
        $this->setMessage("success");
        return $this->SendApiResponse();
        
    }

    public function fonts(){
        $fonts = FontFamil::get();
        $this->setDate("",$fonts);
        $this->setMessage("success");
        return $this->SendApiResponse();
        
    }

}

