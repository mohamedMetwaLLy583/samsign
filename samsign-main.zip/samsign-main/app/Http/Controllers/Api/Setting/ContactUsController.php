<?php

namespace App\Http\Controllers\Api\Setting;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Setting\ContactUsRequest;
use App\Models\ContactUs;

class ContactUsController extends Controller
{
    public function ContactUs(ContactUsRequest $request){
        try{
            ContactUs::create([
                "message"=>$request->message,
                "email"=>$request->email,
                "phone"=>$request->phone,
            ]);
            $this->setMessage("success send your message");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }
}
