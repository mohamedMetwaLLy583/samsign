<?php

namespace App\Http\Controllers\Api\Setting;

use App\Http\Controllers\Controller;
use App\Models\setting;
use App\Models\language;
use Mail;
class SettingController extends Controller
{
    public function About(){
        $about = setting::where("type","about")->first();
        $this->setMessage("");
        $this->setStatus(200);
        $this->setDate("",$about);
        return $this->SendApiResponse();
    }

    public function Privacy(){
        $privacy = setting::where("type","privacy")->first();
        $this->setMessage("");
        $this->setStatus(200);
        $this->setDate("",$privacy);
        return $this->SendApiResponse();
    }
    
    public function social(){
        $this->setMessage("");
        $this->setStatus(200);
        $this->setDate("",[
            "facebook"=>"https://www.facbook.com",
            "instagram"=>"https://www.instagram.com",
            "twitter"=>"https://www.twitter.com",
            "youtube"=>"https://youtube.com/",
             "tiktok"=>"https://www.tiktok.com/explore",
            "whatsapp"=>"https://web.whatsapp.com/send/?phone=201145863221",
            "email"=>"vera@vera.com",
            "phone"=>"01145863221"
        ]);
        return $this->SendApiResponse();
    }
    
      public function language(){
          
        //   $data = array('name'=>"Virat Gandhi");
        //   Mail::send('mail.test-email', $data, function($message) {
        //      $message->to('amrg7088@gmail.com', 'Tutorials Point')->subject
        //         ('Laravel HTML Testing Mail');
        //      $message->from('vera@innovative-techs.com','Virat Gandhi');
        //   });
     
          $data = [];
        $languages = language::where("status","1")->get();
        foreach($languages as $language){
          $data[] = [
                    "icon"=> asset($language->icon),
                    "name"=> $language->name,
                    "code"=> $language->code 
             ];  
        }
        $this->setMessage("");
        $this->setStatus(200);
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }
    
   

}
