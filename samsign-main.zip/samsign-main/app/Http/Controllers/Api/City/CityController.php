<?php

namespace App\Http\Controllers\Api\City;

use App\Http\Controllers\Controller;
use App\Models\City;
class CityController extends Controller
{

    public function index(){
        $cities = City::get();
        $this->setDate("",$cities);
        $this->setMessage("success");
        $this->setStatus(200);
        return $this->SendApiResponse();
    }
    public function city($country){
        
        $cities = City::where("country_id",$country)->get();
        $this->setDate("",$cities);
        $this->setMessage("success");
        $this->setStatus(200);
        return $this->SendApiResponse();
    }
}
