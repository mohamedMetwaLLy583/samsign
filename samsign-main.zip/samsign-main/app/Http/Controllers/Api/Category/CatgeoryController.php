<?php

namespace App\Http\Controllers\Api\Category;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class CatgeoryController extends Controller
{
    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
    public function index(){
        $categories = Category::where("user_id",$this->user->id)->get();
        $this->setDate("",$categories);
        return $this->SendApiResponse();
    }
    
    public function create(Request $request){
        
        Category::create([
            "user_id"=>$this->user->id,
            "en"=>["name"=>$request["name"]["en"]],
            "ar"=>["name"=>$request["name"]["ar"]],
        ]);
        
        return $this->index();
    }

    public function edit(Request $request , $id){

        Category::find($id)->update([
             "en"=>["name"=>$request["name"]["en"]],
            "ar"=>["name"=>$request["name"]["ar"]],
        ]);
        
        return $this->index();
    }

    public function destroy($id){
        Category::find($id)->delete();
        Product::where("category_id",$id)->delete();
        return $this->SendApiResponse();
    }
    
}
