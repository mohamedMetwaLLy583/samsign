<?php

namespace App\Http\Controllers\Api\Account;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Acount\addressRequest;
use App\Http\Requests\Api\Acount\addAddressRequest;
use App\Http\Requests\Api\Acount\businessRequest;
use App\Http\Requests\Api\Acount\personalRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\BusinessAddress;
class AccountController extends Controller
{
    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
    public function personal(personalRequest $request){
        try{
        $erro = "";
        
        if($request->email !== $this->user->email){
            $validator = Validator::make($request->all(),[
                "email"=>"unique:users,email",
            ]);
            if($validator->fails()){
                $erro .= $validator->errors()->first();
            }else{
                $this->user->email=$request->email;
                $this->user->save();
            }
            
        }
        
        if($request->phone !== $this->user->phone){
           $validator = Validator::make($request->all(),[
                "phone"=>"unique:users,phone",
            ]);
            if($validator->fails()){
               $erro .= $validator->errors()->first();
            }else{
                 $this->user->phone=$request->phone;
                $this->user->save();
            }
        }
        
        if($request->username !== $this->user->username){
             $validator = Validator::make($request->all(),[
                "username"=>"unique:users,username",
            ]);
            if($validator->fails()){
                $erro .= $validator->errors()->first();
            }else{
                $this->user->username= $request->username;
                $this->user->save();
            }
            
        }
            if($erro != ""){
                $this->setMessage("success Edit your data but".$erro);
            }else{
                $this->setMessage("success Edit your data");    
            }
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }

    public function business(businessRequest $request){
        try{
            $erro = "";
            $this->user->Business()->update([
                "name"=>$request->name,
                "description"=>$request->description,
            ]);
             if($request->org_no !== $this->user->business->org_no){
           $validator = Validator::make($request->all(),[
                "org_no"=>"required|string|min:3|unique:business_details,org_no",
            ]);
            if($validator->fails()){
               $erro .= $validator->errors()->first();
            }else{
                $this->user->Business()->update([
                "org_no"=>$request->org_no,
                ]);
            }
            }
            
            if($request->number !== $this->user->business->number){
                 $validator = Validator::make($request->all(),[
                    "number"=>"required|string|min:8|unique:business_details,number",
                ]);
                if($validator->fails()){
                    $erro .= $validator->errors()->first();
                }else{
                    $this->user->Business()->update([
                        "number"=>$request->number,
                    ]);
                }
                
            }
            
            if($request->image){
                $this->user->image = $request->image->store("storage/User");
                $this->user->save();
            }
                if($erro != ""){
                    $this->setMessage("success Edit your data but".$erro);
                }else{
                    $this->setMessage("success Edit your data");    
                }
            
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }


    public function Editaddress(addressRequest $request){
        try{
            $Adrees= BusinessAddress::where([["id",$request->address_id],["user_id",$this->user->id]])->first();
            $Adrees->update([
                "country_id"=>$request->country_id,
                "city_id"=>$request->city_id,
                "street_name"=>$request->street_name,
                "postal_no"=>$request->postal_no,
            ]);
            $this->setMessage("success Edit your data");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }
    
     public function Addaddress(addAddressRequest $request){
        try{
            BusinessAddress::create([
                "user_id"=>$this->user->id,
                "country_id"=>$request->country_id,
                "city_id"=>$request->city_id,
                "street_name"=>$request->street_name,
                "postal_no"=>$request->postal_no,
            ]);
            return $this->address();
            
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }
    
     public function address(){
        try{
            $address = $this->user->load("Address")->address;
            $this->setMessage("success Edit your data");
            $this->setDate("",$address);
            
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }
    
    
    public function deleteaddress(Request $request){
        try{
            $Adrees= BusinessAddress::where([["id",$request->address_id],["user_id",$this->user->id]])->delete();
            $this->setMessage("success delete your data");
            $this->setStatus(200);
        }catch(\Exception $e){
            $this->setMessage("request faild");
            $this->setStatus(500);
        }
        return $this->SendApiResponse();
    }


    public function storeOrUpdateTokenFcm(Request $request){
        $this->user->update([
            "platform"=>$request->platform,
            "fcm_token"=>$request->fcm_token
        ]);
        $this->setStatus(200);
        $this->setMessage("success");
        return $this->SendApiResponse();
    }
    
    public function Profile(){
        $user = AuthApi();
        
        $result = [
             "id"=>$user->id,
            "username"=>$user->username,
            "email"=>$user->email,
            "phone"=>$user->phone,
            "status"=>$this->statusUser($user->status),
            "business"=>[
                "id"=>$user->business->id,
                "name"=>$user->business->name,
                "image"=>asset($user->image),
                "description"=>$user->business->description,
                "org_no"=>$user->business->org_no,
                "number"=>$user->business->number
            ],    
        ];
        $this->setDate("",$result);
                $this->setStatus(200);
                $this->setMessage("success");
                return $this->SendApiResponse();
    }
    
    
    public function statusUser($status){
        
        if($status == "1"){
            return 1; //"Active"
        }elseif($status == "2"){
            return 2; //"Stopped"
        }elseif($status == "3"){
            return 3; //"Refused"
        }elseif($status == "4"){
            return 4; //"trail"
        }else{
            return 0; //"pending"
        }
        
    }
}
