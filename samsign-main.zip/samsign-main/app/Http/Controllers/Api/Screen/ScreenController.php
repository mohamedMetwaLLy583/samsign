<?php

namespace App\Http\Controllers\Api\Screen;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Screen\ScreenResource;
use App\Http\Resources\Api\Screen\ScreenTemplateResource;
use App\Models\Screens;
use App\Models\ScreenTemplate;
use Illuminate\Http\Request;

class ScreenController extends Controller
{
    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
    public function index(){
        $screens = Screens::where("user_id",$this->user->id)->get();
        $screens->load("ScreensTemplate");
        
        $this->setDate("",new ScreenResource($screens));
        $this->setMessage("success");
        return $this->SendApiResponse();
    }
    public function show($id){
        $screens = Screens::find($id);
        $screens->load("ScreensTemplate"); 
        $this->setDate("",new ScreenTemplateResource($screens));
        $this->setMessage("success");
        return $this->SendApiResponse();
    }

    public function store(Request $request){
            $screen = $this->user->screens()->create([
                "name"=>$request->name,
                "type"=>$request->type,
            ]);
            if($request->type == "1"){
                $screen->ScreensTemplate()->create([
                    "template_id"=>$request->template[0]["id"]
                ]);
            }else{
                foreach($request->template as $result){
                    $screen->ScreensTemplate()->create([
                        "template_id"=>$result["id"],
                        "from"=>$result["from"],
                        "to"=>$result["to"],
                    ]);     
                }
            }
            return $this->index();
    }
    
     public function edit(Request $request,$id){
        $screen = Screens::find($id);
        $screen->update([
            "name"=>$request->name,
            "type"=>$request->type,
        ]);
        
        if(!is_null($request->template)){
            $screen->ScreensTemplate()->delete();
            if($request->type == "1"){
                $screen->ScreensTemplate()->create([
                    "template_id"=>$request->template[0]["id"]
                ]);
            }else{
                foreach($request->template as $result){
                    $screen->ScreensTemplate()->create([
                        "template_id"=>$result["id"],
                        "from"=>$result["from"],
                        "to"=>$result["to"],
                    ]);     
                }
            }    
        }
        
        return $this->index();
}



    public function destroy($id){
        Screens::find($id)->delete();   
        ScreenTemplate::where("screen_id",$id)->delete();
        $this->setMessage("deleted success");
       return $this->index();

    }
}
