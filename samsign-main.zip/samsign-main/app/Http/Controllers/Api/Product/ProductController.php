<?php

namespace App\Http\Controllers\Api\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Product\ProductRequest;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Category;
class ProductController extends Controller
{
    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
    
    public function all(){
        $products = Product::where("user_id",$this->user->id)->get();
        $data = [];
        foreach($products as $product){
            $data [] =  [
            "id"=>$product->id,
            "name"=>$product->name,
            "description"=>$product->description,
            "sizes"=>$product->sizes,
            "category"=>[
                "id"=>(int)$product->category_id,
                "name"=>Category::find((int)$product->category_id)->name,
            ]   
            ];
        }
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }

    public function index($id){
        $products = Product::where("category_id",$id)->where("user_id",$this->user->id)->get();
        $data = [];
        foreach($products as $product){
            $data [] =  [
            "id"=>$product->id,
            "name"=>$product->name,
            "description"=>$product->description,
            "sizes"=>$product->sizes,
            "category"=>[
                "id"=>(int)$id,
                "name"=>Category::find((int)$id)->name,
            ]   
            ];
        }
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }

    public function show($id){
        $product = Product::where("id",$id)->where("user_id",$this->user->id)->first();
             $data = [];
        if($product){
            $data [] =  [
            "id"=>$product->id,
            "name"=>$product->name,
            "description"=>$product->description,
            "sizes"=>$product->sizes,
            "category"=>[
                "id"=>(int)$id,
                "name"=>Category::find((int)$product->category_id)->name,
            ]   
            ]; 
        }
        
        
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }

    public function store(ProductRequest $request){
            $product = $this->user->Products()->create([
                "name"=>$request->name,
                "description"=>$request->description,
                "category_id"=>$request->category
            ]);
            if($request->sizes){
                foreach($request->sizes as $size){
                    $product->sizes()->create([
                        "size"=>$size["size"],
                        "price"=>$size["price"],
                    ]); 
                }
            }
            $this->setMessage("success Create product");
            return $this->all();
    }

    public function update(ProductRequest $request,$id){
        $product = Product::find($id);
        if(!$product){
            $this->setMessage("the product not found");
            return $this->SendApiResponse();
        }
        $product->update([
            "name"=>$request->name,
            "description"=>$request->description,
        ]);

        if($request->sizes){
            if($product->sizes()){
                $product->sizes()->delete();
            }
            foreach($request->sizes as $size){
                $product->sizes()->create([
                    "size"=>$size["size"],
                    "price"=>$size["price"],
                ]); 
            }
        }

        $this->setMessage("success edit Product");
        return $this->all();
    }


    public function destroy($id){
        Product::find($id)->delete();
        $this->setMessage("success Deleted");
        return $this->SendApiResponse();
    }
    
}
