<?php

namespace App\Http\Controllers\Api\Search;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Screen\ScreenResource;
use App\Http\Resources\Api\Menu\MenuResource;
use App\Models\Menu;
use App\Models\Screens;
use App\Models\Lists;
use App\Models\Category;
use App\Models\Product;
use App\Models\language;
use Illuminate\Http\Request;

class SearchController extends Controller
{

    public $user;
    public function __construct(){
        $this->user = AuthApi();
    }
   
    public function index(Request $request)
    {
        $data = [];
        if($request->type == "menu"){
           $data =  $this->menus($request->search);
        }else if($request->type == "template"){
            $data = $this->template($request->search);
        }else if($request->type == "product"){
            $data = $this->product($request->search,$request->category_id);
        }else{
            $data =  $this->screens($request->search);
        }
        $this->setMessage("success");
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }
    
    public function screens($search){
        $screens = Screens::where("name",'like', '%' . $search . '%')->where("user_id",$this->user->id)->get();
        return new ScreenResource($screens);
    }
    
    
    public function menus($search){
        $menus = Menu::where("name",'like', '%' . $search . '%')->where("user_id",$this->user->id)->where("type","1")->get();
        $data = [];
        foreach($menus as $menu){
            $data[] = [
                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>asset("example.png"),
            ];
        }
        
        return $data;
    }
    
     public function template($search){
        $menus = Menu::where("name",'like', '%' . $search . '%')->where("type","0")->get();
        $data = [];
        foreach($menus as $menu){
            $data[] = [
                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>asset("example.png"),
            ];
        }
        
        return $data;
    }
    
    public function product($search,$id){
        $data = [];
        if($id > 0){
            $products = Product::where("name",'like', '%' . $search . '%')->where("user_id",$this->user->id)->where("category_id",$id)->get();
          
        foreach($products as $product){
            $data [] =  [
            "id"=>$product->id,
            "name"=>$product->name,
            "description"=>$product->description,
            "sizes"=>$product->sizes,
            "category"=>[
                "id"=>(int)$product->category_id,
                "name"=>Category::find((int)$product->category_id)->name,
            ]   
            ];
        }
        }else{
            $products =  Product::where("name",'like', '%' . $search . '%')->where("user_id",$this->user->id)->get();
            foreach($products as $product){
            $data [] =  [
            "id"=>$product->id,
            "name"=>$product->name,
            "description"=>$product->description,
            "sizes"=>$product->sizes,
            "category"=>[
                "id"=>(int)$product->category_id,
                "name"=>Category::find((int)$product->category_id)->name,
            ]   
            ];
        }
        }
        return $data;
    }
    
    
    public function language(Request $request)
    {
     


        $languages = language::where('name', 'like', '%' . request('search') . '%')->get();
        $this->setMessage("success");
        $this->setDate("",$languages);
        return $this->SendApiResponse();
        
    }

    
}
