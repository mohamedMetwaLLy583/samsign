<?php

namespace App\Http\Controllers\DashBoard\Home;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Menu;
class HomeController extends Controller
{
    public function index(){
        $users = User::select()->where("status","<>","0");
        $count = User::select()->where("status","0")->count();
        $users = $users->paginate(10);
        return view("Dashboard.Home.index",compact('users','count'));
    }
    
    
      public function template($id){
        $menu = Menu::find($id);
        return view("template",compact('menu'));
    }
}
