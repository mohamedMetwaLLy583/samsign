<?php

namespace App\Http\Controllers\Dashboard\City;

use App\Http\Controllers\Controller;
use App\Models\City;
use App\Models\Country;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function index(){
        $country = Country::get();
        $users = City::paginate(10);
        return view('Dashboard.City.index',compact('users','country'));
    }

    public function store(Request $request){
        
         $data = [   
            "ar"=>["name"=>$request->name["ar"]],
            "en"=>["name"=>$request->name["en"]],
            "country_id"=>$request->country_id,
            "postal_no"=>$request->postal_no,
        ];
        City::create( $data);
        
        return response(["message"=>"kdfjgkfjdgdflk"],200);

    }


    public function update(Request $request ,$id){
       $country =  City::find($id);
       $country->update($request); 
       return response(["message"=>"kdfjgkfjdgdflk"],200);

    }


    public function destroy(Request $request){
        $country = City::find($request->id);
        $country->delete();
        return response(["message"=>"kdfjgkfjdgdflk"],200);
    }
}
