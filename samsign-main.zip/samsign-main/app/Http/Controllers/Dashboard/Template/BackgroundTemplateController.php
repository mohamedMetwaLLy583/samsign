<?php
namespace App\Http\Controllers\Dashboard\Template;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Pion\Laravel\ChunkUpload\Exceptions\UploadMissingFileException;
use Pion\Laravel\ChunkUpload\Handler\HandlerFactory;
use Pion\Laravel\ChunkUpload\Receiver\FileReceiver;
use Illuminate\Http\UploadedFile;
use App\Models\Menu;
class BackgroundTemplateController extends Controller
{
    public function uploadImage(Request $request){
       
      
        $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));

        if ($receiver->isUploaded()) {
            $save = $receiver->receive();
            if ($save->isFinished()) {
                $file= $save->getFile();
                $fileName = $this->createFilename($file);
                // Group files by mime type
                $mime = str_replace('/', '-', $file->getMimeType());
                // Group files by the date (week
                $dateFolder = date("Y-m-W");
        
                // Build the file path
                $filePath = "Template/Image/{$dateFolder}/";
                $finalPath = storage_path("../public/storage/".$filePath);
        
                // move the file name
                $file->move($finalPath, $fileName.explode("-",$mime)[1]);
                $menu = Menu::find($request->id);
                $menu->image = $filePath.$fileName.explode("-",$mime)[1];
                $menu->save(); 
                $imagez = getimagesize(asset("storage/".$filePath.$fileName.explode("-",$mime)[1]));
                return response(["image"=>asset("storage/".$filePath.$fileName.explode("-",$mime)[1]),"width"=>$imagez[0],"height"=>$imagez[1]],200);
            } else {
                /** @var AbstractHandler $handler */
                $handler = $save->handler();
                return response()->json([
                    "done" => $handler->getPercentageDone(),
                ]);
            }
        } else {
            throw new UploadMissingFileException();
        }    
        
}


public function uploadVideo(Request $request){
       
    
    $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));

    if ($receiver->isUploaded()) {
        $save = $receiver->receive();
        if ($save->isFinished()) {
            return $this->saveFile($save->getFile());
        } else {
            /** @var AbstractHandler $handler */
            $handler = $save->handler();
            
            return response()->json([
                "done" => $handler->getPercentageDone(),
            ]);
        }
    } else {
        throw new UploadMissingFileException();
    }

    


    // $save = $receiver->receive();
    // $file = $save->getFile();
    // $video = $file->getPathname();
    // return $file.".mp4";


           
    // $extension = $file->getClientOriginalExtension();
    // $fileName = str_replace('.'.$extension, '', $file->getClientOriginalName()); //file name without extenstion
    // $fileName .= '_' . md5(time()) . '.' . $extension; // a unique file name
    // $disk = Storage::disk(config('filesystems.default'));
    // $path = $disk->putFileAs('storage/Template/video', $file, $fileName);
    
    // $menu = Menu::find($request->id);
    // $menu->video = $video;
    // $menu->save();
    // return response(["video"=>$video],200);
}


protected function saveFile(UploadedFile $file)
    {
        $fileName = $this->createFilename($file);
        // Group files by mime type
        $mime = str_replace('/', '-', $file->getMimeType());
        // Group files by the date (week
        $dateFolder = date("Y-m-W");

        // Build the file path
        $filePath = "Template/Video/{$dateFolder}/";
        $finalPath = storage_path("../public/storage/".$filePath);

        // move the file name
        $file->move($finalPath, $fileName.explode("-",$mime)[1]);

        return response()->json([
            'path' => $filePath,
            'name' => $fileName.explode("-",$mime)[1],
            'mime_type' => $mime,
            'extension'=>$file->getClientOriginalExtension()
        ]);
    }

    protected function createFilename(UploadedFile $file)
    {
        $extension = $file->getClientOriginalExtension();
        $filename = str_replace(".".$extension, "", $file->getClientOriginalName()); // Filename without extension

        // Add timestamp hash to name of the file
        $filename .= "_" . md5(time()) . ".";

        return $filename.$extension;
    }
}
