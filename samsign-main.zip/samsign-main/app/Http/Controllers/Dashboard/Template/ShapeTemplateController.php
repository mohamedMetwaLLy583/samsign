<?php

namespace App\Http\Controllers\Dashboard\Template;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ShapeTemplateController extends Controller
{
    //
}
