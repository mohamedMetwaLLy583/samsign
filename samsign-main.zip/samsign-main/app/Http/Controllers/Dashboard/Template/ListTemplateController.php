<?php

namespace App\Http\Controllers\Dashboard\Template;

use App\Http\Controllers\Controller;
use App\Models\ListTemplate;
use App\Models\Menu;
use Illuminate\Http\Request;

class ListTemplateController extends Controller
{
    public function process(Request $request){
        if(isset($request->id)&&$request->id > 0){
            $data = $this->update($request,$request->id);
        $this->setDate("",$data);
        }else{
            $data = $this->store($request);
            $this->setDate("",$data);
        }
        
        return $this->SendApiResponse();
    }


    public function store(Request $request){
        
        $menu = Menu::find($request->menu_id);
        $data = $request->except(["_token","menu_id","sizes"]);
        $list = $menu->ListTemplate()->create($data);
        if($request->size_number){
            // foreach($request->sizes as $index=>$size){
            //     $list->sizes()->create($size);
            // }
                
        }
        return $list;
    }

    public function update($request , $id){
        $list = ListTemplate::find($id);
        $data = $request->except(["_token","menu_id","sizes"]);
        $list->update($data);
        if($request->size_number>0){
            $list->sizes()->delete();
            foreach($request->sizes as $index=>$size){
                $list->sizes()->create($size);
            }
                
        }
        return $list;
    }

}
