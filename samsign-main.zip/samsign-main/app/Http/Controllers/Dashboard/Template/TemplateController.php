<?php

namespace App\Http\Controllers\Dashboard\Template;

use App\Http\Controllers\Controller;
use App\Models\DesignTemplate;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage as FacadesStorage;
use Spatie\Browsershot\Browsershot;
use App\Models\menuContent;
use App\Models\ProductContentList;
class TemplateController extends Controller
{
    public function index(Request $request){
        if($request->view == "0" || $request->view == "1"){
            $menus = Menu::select()->where("view",$request->view)->where("type","0")->paginate(8);
                $this->setMessage("success");
            $this->setDate("",$menus);
            return $this->SendApiResponse();
        }
        $menus = Menu::select()->where("type","0");
        $users = $menus->paginate(8);
        return view("Dashboard.Template.index",compact('users'));
    }

    public function getshow($id){
        $template = Menu::find($id);
        $template->load(['ListTemplate','ListTemplate.sizes','DesignTemplate'=>function($query){
            return $query->orderByDESC("zindex");
        }]);
        $allchildern = [];
        $images=[];
        $videos=[];
        foreach($template->DesignTemplate as $value){
            if(json_decode($value->content)){
                // foreach(json_decode($value->content) as $v){
                if($value->type == 'menu'){
                    $allchildern[] = $this->Listmenu($id,$value->content,$value->num);
                }elseif($value->type == 'image'){
                    $images[] = json_decode($value->content);
                }elseif($value->type == 'video'){
                    $videos[] = json_decode($value->content);
                }else{
                    $allchildern[] = json_decode($value->content);
                }
                // }
            }
        }
        $templates = Menu::where("type","0")->get();
        $layers = $allchildern;
        $data['template']= $template;
        $data['templates']= $templates;
        $this->setMessage("success");
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }

    public function edit($id){
        $menu = Menu::find($id);
        $template = Menu::where("type","0")->get();
        $menu->load(['ListTemplate','ListTemplate.sizes','DesignTemplate'=>function($query){
            return $query->orderByDESC("zindex");
        }]);
        $allchildern = [];
        $images=[];
        $videos=[];
        foreach($menu->DesignTemplate as $value){
            if(json_decode($value->content)){
                // foreach(json_decode($value->content) as $v){
                if($value->type == 'menu'){
                    $allchildern[] = $this->Listmenu($id,$value->content,$value->num);
                }elseif($value->type == 'image'){
                    $images[] = json_decode($value->content);
                }elseif($value->type == 'video'){
                    $videos[] = json_decode($value->content);
                }else{
                    $allchildern[] = json_decode($value->content);
                }
                // }
            }
        }
        
        $layers = $allchildern;
        return view("Dashboard.Template.Editor",compact('menu','template'))->with(["layers"=>$layers,'images'=>$images,'videos'=>$videos]);
    }

    public function editor($id){
        $template = Menu::find($id);
        $templates = Menu::where("type","0")->get();
        $data['template']= $template;
        $data['templates']= $templates;
        
        return view("Dashboard.Template.Editor",compact('data'));
    }

    


    public function store(Request $request){
        $height = $request->view =='0'?"800":"700";
        $width = $request->view =='0'?"600":"1000";
        if(isset($request->height)){
            $height = $request->height;
        }

        if(isset($request->width)){
            $width = $request->width;
        }


        $data = [
            "name"=>"Template",
            "type"=>"0",
            "view"=>$request->view,
            "height"=>$height,
            "width"=>$width,
        ];
        $menu = Menu::create($data);
        return Response::json(["menu"=>$menu],200);
    }

    public function update (Request $request,$id){

        $menu = Menu::find($id);
        $data = [
            "name"=>$request->name?$request->name:$menu->name,
            "view"=>$request->view == "0" || $request->view == "1" ?$request->view:$menu->view,
            "height"=>$request->height?$request->height:$menu->height,
            "width"=>$request->width?$request->width:$menu->width,
        ];

        $menu->update($data);
        return Response::json(["name"=>$request->name],200);
    }

    public function preview($id){

            $menu = Menu::find($id);
            $menu->load('DesignTemplate');
            return view("Dashboard.Template.Make.preview",compact('menu'));

    }

    public function storepreview(Request $request){
        $image = $request->image;
        $imageInfo = explode(";base64,", $image);
        $imgExt = str_replace('data:image/', '', $imageInfo[0]);
        $image = str_replace(' ', '+', $imageInfo[1]);
        $imageName = "post-".time().".".$imgExt;
        FacadesStorage::disk('local')->put("storage/Template/Preview/".$imageName, base64_decode($image));

        $data = [
            "preview"=>"storage/Template/Preview/".$imageName,
        ];
        $menu = Menu::find($request->id)->update($data);

        return Response::json(["name"=>$request->name],200);
    }







    public function makeTemlate($id){

        $template = Menu::find($id);
        $templates = Menu::where("type","0")->get();
        $data['template']= $template;
        $data['templates']= $templates;
        
        return view("Dashboard.Template.Editor",compact('data'));
    }
     public function show($id){
        $menu = Menu::find($id);
        $template = Menu::where("type","0")->get();
        $menu->load(['DesignTemplate'=>function($query){
            return $query->orderByDESC("zindex");
        }]);
        $allchildern = [];
        $images=[];
        $videos=[];
        foreach($menu->DesignTemplate as $value){
            if(json_decode($value->content)){
                // foreach(json_decode($value->content) as $v){
                if($value->type == 'menu'){
                    $allchildern[] = $this->Listmenu($id,$value->content,$value->num);
                }elseif($value->type == 'image'){
                    $images[] = json_decode($value->content);
                }elseif($value->type == 'video'){
                    $videos[] = json_decode($value->content);
                }else{
                    $allchildern[] = json_decode($value->content);
                }
                // }
            }
        }

        $layers = $allchildern;

        
      
            return view("Dashboard.Template.show",compact('menu'))->with(["layers"=>$layers,'images'=>$images,'videos'=>$videos]);

    }

    public function saveContent(Request $request){
        $idMenu = (int)$request->menu_id;
        $dataidarray = [];
        $menu = Menu::find($idMenu);
        $menuDesign = DesignTemplate::where("menu_id",$idMenu)->get();
        if(count($menuDesign) > 0 ){
            DesignTemplate::where("menu_id",$idMenu)->delete();

        }
        foreach($request->arrayContent as $content){
                    $menu->DesignTemplate()->create([
                            "type"=>$content["type"],
                            "content"=>$content["value"],
                            "lock"=>'0',
                            "hidden"=>'0',
                            "zindex"=>'0',
                            "dataid"=>"menu_1255",
                            "targetlayer"=>"target1545",
                    ]);
        }

        $menu->update([
             "name"=>$request->name?$request->name:"Template",
             "style"=>$request->style,
             "history"=>$request->history,
        ]);
        $menu->load("DesignTemplate");
        return response()->json(["desgin"=>$menu->design_template],200);
    }

    public function destroy(Request $request){
        $menu = Menu::find($request->id);
        $menu->load("DesignTemplate");
        $menu->DesignTemplate()->delete();
        $menu->delete();
        return Response::json(["message"=>"success deleted"],200);
    }

    public function getTemplate($id){
        $menu = Menu::find($id);
        $template = Menu::where("type","0")->get();
        $menu->load(['ListTemplate','ListTemplate.sizes','DesignTemplate'=>function($query){
            return $query->orderByDESC("zindex");
        }]);
        $allchildern = [];
        $images=[];
        $videos=[];
        foreach($menu->DesignTemplate as $value){
            if(json_decode($value->content)){
                // foreach(json_decode($value->content) as $v){
                if($value->type == 'menu'){
                    $allchildern[] = $this->Listmenu($id,$value->content,$value->num);
                }elseif($value->type == 'image'){
                    $images[] = json_decode($value->content);
                }elseif($value->type == 'video'){
                    $videos[] = json_decode($value->content);
                }else{
                    $allchildern[] = json_decode($value->content);
                }
                // }
            }
        }
//        $layers = json_decode($menu->DesignTemplate[0]->content);
        $layers = $allchildern;

        return response()->json(["menu"=>$menu,"layers"=>$layers,'images'=>$images,'videos'=>$videos],200);
    }

public function Listmenu($id,$menu,$numlist){
    $tmenu = Menu::find($id);
    $resultfinal = json_decode($menu);
    $imdproduct = count($tmenu->lists) > 0?count($tmenu->lists[0]->products):0;
    $numproduct = 0;
    $indexsize = 0;
    $imdsize = 0;
    $numlist = $numlist;
    if($imdproduct > 0){
           foreach(json_decode($menu)->children as $value){
        if(isset($value->children)){
            $products = [];
            $sizetext = [];
            $sizeprice = [];
            $info =[];
            $finallResult = [];
            foreach($value->children as $res){
                $classNameO = (string)$res->className;
                $objsva = json_encode($res);
                if($res->className == 'Text'){
                    $groubBy = $res->attrs->text;
                    if($res->attrs->text == 'Title Menu'){
                        $res->attrs->text = $tmenu->lists[$numlist]->name;
                        $resultfinal->children[0]->children[] = $res;
                    }

                    if($res->attrs->text == '120' && $tmenu->lists[$numlist]->status_price == '1'){
                        $res->attrs->text = $tmenu->lists[$numlist]->price;
                        $resultfinal->children[0]->children[] = $res;
                    }

                    if($res->attrs->text == 'product' && $numproduct < $imdproduct){
                        $res->attrs->text = $tmenu->lists[$numlist]->products[$numproduct]->products->name;
                        // $imdsize += $tmenu->lists[$numlist]->products[$numproduct]->sizes != null ?count($tmenu->lists[$numlist]->products[$numproduct]->sizes):0;

                        $numproduct++;
                        $resultfinal->children[0]->children[] = $res;

                    }
                    if($res->attrs->text == 'info' && $numproduct < $imdproduct){
                        $res->attrs->text = $tmenu->lists[$numlist]->products[$numproduct]->products->description;
                        $numproduct++;
                        $resultfinal->children[0]->children[] = $res;
                        $info[] = $res;
                    }
                    if($res->attrs->text == 'sm'){
                        $resultfinal->children[0]->children[] = $res;
                    }
                    if($res->attrs->text == '12' && $numproduct < $imdproduct){
                        $listsProducts = ProductContentList::where("menu_id",$tmenu->template)->where('order',$numlist)->get();
                        foreach($listsProducts as $products){
                            foreach(json_decode($products->value)->price as $index=>$valuepri){
                                if($tmenu->lists[$numlist]->products[$numproduct]->products->sizes){
                                    $valuepri->attrs->text = (count($tmenu->lists[$numlist]->products[$numproduct]->products->sizes) > $index)?$tmenu->lists[$numlist]->products[$numproduct]->products->sizes[$index]->price:0;
                                    $resultfinal->children[0]->children[] = $valuepri;

                                }
                            }
                            break;
                        }

                        // ;
                        // $indexsize++;
                        // $sizeprice[] = $res;
                    }
                }else{
                    $resultfinal->children[0]->children[] = $res;
                }
            }
            $priceresult = [];
            $start = 0;
            // for ($i=1; $i <= count($products); $i++) {
            //         $priceresult[] = array_slice($sizeprice, $start, count($sizetext));
            //         $start += count($sizetext);
            // }
            // foreach($products as $index => $final){
            //     $finallResult[] = [
            //         'product'=>$final,
            //         'info'=> (count($info)==count($products))?$info[$index]:'',
            //         'price'=> (count($priceresult) > 0)?$priceresult[$index]:[],
            //     ];
            // }

        }
    }
    }
 

    // return $finallResult;

    $products = [];
    $sizetext = [];
    $sizeprice = [];
    $info =[];
    $finallResult = [];
    return $resultfinal;
}
}
