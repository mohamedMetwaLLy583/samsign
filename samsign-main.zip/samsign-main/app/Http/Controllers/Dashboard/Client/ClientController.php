<?php

namespace App\Http\Controllers\Dashboard\Client;

use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\City;
use App\Models\User;
use App\Models\Screens;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Pdfcrowd\HtmlToImageClient;

class ClientController extends Controller
{
    public function index(){
        
        $users = User::select()->where("status","<>","0");
        $count = User::select()->where("status","0")->count();
        $users = $users->paginate(10);
       
        // return $users;
        return view("Dashboard.Client.index",compact('users','count'));
    }
    public function show($id){
        $user = User::find($id);
        $user->load("screens","screens.ScreensTemplate");
        // return $user;
        return view("Dashboard.Client.show",compact('user'));
    }

    
    public function edit($id){
        $user = User::find($id);
        $user->personal = [
            "username"=> $user->username,
            "email"=> $user->email,
            "phone"=> $user->phone,
            "status"=> $user->status,
            "image"=>$user->image,
            "password"=> $user->password_text,
        ];         
        return view("Dashboard.Client.edit",compact('user'));
    }

    public function screen($id){
        $user = User::find($id);
        $screens = $user->load("screens","screens.ScreensTemplate")->screens;
        return view("Dashboard.Client.part.screens",compact('screens'));
    }

 public function screenshow($id){
        $screen = Screens::find($id);
        $screen->load("ScreensTemplate");
        
        return view("Dashboard.Client.part.show",compact('screen'));
    }

   

    public function template($id){
        $user = User::find($id);
        $menus = $user->menus;
        return view("Dashboard.Client.part.template",compact('menus'));
    }




    public function destroy(Request $request){
        User::find($request->id)->delete();
        return Response::json(["message"=>"success deleted"],200);
    }
}
