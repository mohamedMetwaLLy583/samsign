<?php

namespace App\Http\Controllers\Dashboard\Search;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\Screen\ScreenResource;
use App\Http\Resources\Api\Menu\MenuResource;
use App\Models\Menu;
use App\Models\Screens;
use App\Models\Lists;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\language;
use Illuminate\Http\Request;

class SearchController extends Controller
{

    public $user;
    public function __construct(){
        $this->user = AuthAdmin();
    }
   
    public function index(Request $request)
    {
        $data = [];
        if($request->type == "menu"){
           $data =  $this->menus($request->search);
        }else if($request->type == "template"){
            $data = $this->template($request);
        }else if($request->type == "client"){
            $data = $this->client($request->search);
        }else{
            $data =  $this->requestClient($request->search);
        }
        $this->setMessage("success");
        $this->setDate("",$data);
        return $this->SendApiResponse();
    }
    
    public function screens($search){
        $screens = Screens::where("name",'like', '%' . $search . '%')->where("user_id",$this->user->id)->get();
        return new ScreenResource($screens);
    }
    
    
    public function menus($search){
        $menus = Menu::where("name",'like', '%' . $search . '%')->where("type","1")->get();
        $data = [];
        foreach($menus as $menu){
            $data[] = [
                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>$menu->image,
            ];
        }
        
        return $data;
    }
    
     public function template($request){

        $datasearch = [];
        if(isset($request->search) && $request->search != 'undefined'){
            $datasearch[] = ['name','like', '%' .  $request->search . '%'];
        }
        if(isset($request->show) && $request->show != 'undefined'){
            $datasearch[] = ['view',$request->show];
        }
        
        $menus = Menu::where($datasearch)->where("type","0")->get();
        
        $data = [];
        foreach($menus as $menu){
            $data[] = [
                "id"=>$menu->id,
                "name"=>$menu->name,
                "image"=>$menu->image,
                "preview"=>$menu->preview,
                "created_at"=>$menu->created_at,
            ];
        }
        
        return $data;
    }
    
    public function requestClient($search){
          $query = User::query();
            $columns = ['email', 'phone', 'username'];
            foreach($columns as $column){
                $query->orWhere($column, 'LIKE', '%' . $search . '%');
            }
            $users = $query->where("status","0")->get();
            return $users;
    }
    
    
      public function client($search){
            $query = User::query();
            $columns = ['email', 'phone', 'username'];
            foreach($columns as $column){
                $query->orWhere($column, 'LIKE', '%' . $search . '%');
            }
            $users = $query->where("status","<>","0")->get();
            return $users;
    }

}
