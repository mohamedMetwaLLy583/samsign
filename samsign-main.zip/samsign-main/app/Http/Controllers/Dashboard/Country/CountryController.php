<?php

namespace App\Http\Controllers\Dashboard\Country;

use App\Http\Controllers\Controller;
use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends Controller
{
    public function index(){
        $users = Country::paginate(10);
        return view('Dashboard.Country.index',compact('users'));
    }

    public function show($id){
        $country = Country::find($id);
        return response([$country],200);
    }

    public function store(Request $request){
        
        $data = [   
            "ar"=>["name"=>$request->name["ar"]],
            "en"=>["name"=>$request->name["en"]],
            "image"=>$request->image,
            "code"=>$request->code,
            'status'=>"1",
        ];
        Country::create( $data);
        return response(["message"=>"kdfjgkfjdgdflk"],200);

    }

    public function uploadImage(Request $request){
        $image = $request->file("file")->store("storage/Country/");
        return response(["image"=>$image],200);
    }

    public function update(Request $request ,$id){
       $country =  Country::find($id);
       $country->update($request); 
       return response(["message"=>"kdfjgkfjdgdflk"],200);

    }


    public function destroy(Request $request){
        $country = Country::find($request->id);
        $country->delete();
        return response(["message"=>"kdfjgkfjdgdflk"],200);
    }
}
