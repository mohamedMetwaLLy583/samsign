<?php

namespace App\Http\Controllers\Dashboard\Notification;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\notification;
use App\Models\User;
class NotificationController extends Controller
{
     public function index()
    {
        

        $user_id = User::where('branch_id',auth('admin')->user()->branch_id)->pluck('id');
        $notifications = notification::orderBy('id', 'DESC')->whereIn('notifiable_id',$user_id)->paginate(10);
        return view($this->path_folder.'index')->with(['notifications'=>$notifications]);

    }

 
    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required|string|min:2',
            'body'=>'required|string|min:2',
            
            'user_id'=>'required|numeric|exists:users,id',
            ]);

            // foreach($request->user_id as $user){
                $user = User::find($request->user_id);
              notification::create([
                'title'=>$request->title,
                'type'=>"info",
                'body'=>$request->body,
                'notifiable_id'=>$user->id
                ]);
                send_notification([$user->fcm_token],$request->title,$request->body, "info");
            // }

            return response(['success' => "success"],200);
    }

    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $notification = notification::find($id);
        $notification->delete();
        return redirect(route('admin.notification.index'));
    }

   
    
  
    
}
