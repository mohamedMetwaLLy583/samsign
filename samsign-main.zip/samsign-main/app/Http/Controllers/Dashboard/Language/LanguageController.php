<?php

namespace App\Http\Controllers\Dashboard\Language;

use App\Http\Controllers\Controller;
use App\Models\language;
use Illuminate\Http\Request;

class LanguageController extends Controller
{
    public function index(){
        $users = language::paginate(10);
        return view('Dashboard.Language.index',compact('users'));
    }

    public function store(Request $request){
        language::create($request);
        return response(["message"=>"kdfjgkfjdgdflk"],200);

    }
    public function uploadImage(Request $request){
        $image = $request->file("file")->store("storage/Notification/");
        return response(["image"=>$image],200);
    }

    public function update(Request $request ,$id){
       $country =  language::find($id);
       $country->update($request); 
       return response(["message"=>"kdfjgkfjdgdflk"],200);

    }


    public function destroy(Request $request){
        $country = language::find($request->id);
        $country->delete();
        return response(["message"=>"kdfjgkfjdgdflk"],200);
    }
}
