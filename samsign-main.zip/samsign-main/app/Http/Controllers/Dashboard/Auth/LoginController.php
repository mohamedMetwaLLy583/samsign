<?php

namespace App\Http\Controllers\DashBoard\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\dashboard\Auth\LoginRequest;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index(){
        if(AuthAdmin() && AuthAdmin()->id > 0){
            return redirect()->route("dashboard.Home.index");
        }
        return view("Dashboard.Auth.Login");
    }

    public function Process(LoginRequest $request){
        try{
            $data = ["username"=>$request->username,"password"=>$request->password];
            $token = Auth::guard('admin')->attempt($data,true);
            if($token){
                $user = AuthAdmin();
                // Auth::login($user,true);
                $this->setDate("",["id"=>$user->id,"name"=>$user->username]);
                $this->setStatus(200);
                $this->setMessage("success");
            }else{
                $this->setStatus(422);
                $this->setMessage("your username Or Password Invilad");
            }
            
        }catch(\Exception $e){
            $this->setStatus(422);
            $this->setMessage("unathintacted");     
        }
        return $this->SendApiResponse();
    }
    
    
    public function logout(){
        Auth::guard('admin')->logout();
          $this->setStatus(200);
          $this->setMessage("success");
          return $this->SendApiResponse();
        
    }
}
