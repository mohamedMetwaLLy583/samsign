<?php

namespace App\Http\Controllers\Dashboard\Users;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Auth\RegisterRequest;
use App\Models\Country;
use App\Models\City;
use App\Models\User;
use App\Models\BusinessAddress;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response as FacadesResponse;
use Illuminate\Support\Facades\Validator;
use App\Models\FontFamil;
use Illuminate\Support\Facades\Storage;
use Pion\Laravel\ChunkUpload\Exceptions\UploadMissingFileException;
use Pion\Laravel\ChunkUpload\Handler\HandlerFactory;
use Pion\Laravel\ChunkUpload\Receiver\FileReceiver;
use Illuminate\Http\UploadedFile;

class UserController extends Controller
{
    public function index(){
        
        $users = User::select()->where("status","<>","0");
        $count = User::select()->where("status","0")->count();
        $users = $users->paginate(10);
        return view("Dashboard.Client.index",compact('users','count'));
    }
    public function create(){
        $cities = City::with(['country'])->get();
        $countries = Country::get();
        return view("Dashboard.Client.createe",compact('cities','countries'));
    }


    public function store(RegisterRequest $request)
    {
        $datauser = $request->except(["business","address"]);
        $dataaddress = $request->except(["personal","business"]);
        $databussines = $request->except(["address","personal"]);
        $user = User::create($datauser["personal"]);
        if($datauser["personal"]["image"]){
            $user->image = $request->personal["image"];
            $user->save();
        }
        foreach($request->address as $address){
            $user->Address()->create([
                "street_name"=>$address['street_name']?$address['street_name']:'no street name',
                "city_id"=>(int)$address['city_id'] > 0?$address['city_id']:null,
                "country_id"=>(int)$address['country_id'] > 0?$address['country_id']:null,
                "postal_no"=>(int)$address['postal_no']?$address['postal_no']:'no postal number',
            ]);
        }
        
        $user->password_text = $request->personal["password"];
        $user->save();
        $user->Business()->create($databussines["business"]);
        $user->ActiveUser()->create([
            "code"=>"123456",
            "status"=>"0",
        ]);
        
        return FacadesResponse::json(["message"=>"dskjfdjkfjdsfjdskl"],200);
    }



    public function update(Request $request,$id): JsonResponse
    {
        $erro = "";
        $user = User::find($id);
        if($request->personal["email"] !==$user->email){
            $validator = Validator::make($request->all(),[
                "personal.email"=>"unique:users,email",
            ]);
            if($validator->fails()){
                $erro .= $validator->errors()->first();
            }else{
               $user->email=$request->personal["email"];
               $user->save();
            }
            
        }
        
        if($request->personal["phone"] !==$user->phone){
           $validator = Validator::make($request->all(),[
                "personal.phone"=>"unique:users,phone",
            ]);
            if($validator->fails()){
               $erro .= $validator->errors()->first();
            }else{
                $user->phone=$request->personal["phone"];
               $user->save();
            }
        }


        if($request->personal["password"]){
            $validator = Validator::make($request->all(),[
                 "personal.password"=>"required|string|min:8",
             ]);
             if($validator->fails()){
                $erro .= $validator->errors()->first();
             }else{
                 $user->password=Hash::make($request->personal["password"]);
                 $user->password_text =$request->personal["password"];
                $user->save();
             }
         }


         if($request->personal["status"]){
            $validator = Validator::make($request->all(),[
                 "personal.status"=>"required|in:0,1,2,3",
             ]);
            //  send_notification([$user->fcm_token], "Congratulations" , "Congratulations Your account has been block","refused");
             store_notification($user->id, "Congratulations" , "Congratulations Your account has been block","info");
             if($validator->fails()){
                $erro .= $validator->errors()->first();
             }else{
                 $user->status=$request->personal["status"];
                    $user->save();
             }
         }
        
        if($request->personal["username"] !==$user->username){
             $validator = Validator::make($request->all(),[
                "personal.username"=>"unique:users,username",
            ]);
            if($validator->fails()){
                $erro .= $validator->errors()->first();
            }else{
               $user->username= $request->personal["username"];
               $user->save();
            }
            
        }


       $user->Business()->update([
            "name"=>$request->business["name"],
            "description"=>$request->business["description"],
        ]);
         if($request->business["org_no"] !==$user->business->org_no){
       $validator = Validator::make($request->all(),[
            "business.org_no"=>"required|string|min:3|unique:business_details,org_no",
        ]);
        if($validator->fails()){
           $erro .= $validator->errors()->first();
        }else{
           $user->Business()->update([
            "org_no"=>$request->business["org_no"],
            ]);
        }
        }
        
        if($request->business["number"] !==$user->business->number){
             $validator = Validator::make($request->all(),[
                "business.number"=>"required|string|min:8|unique:business_details,number",
            ]);
            if($validator->fails()){
                $erro .= $validator->errors()->first();
            }else{
               $user->Business()->update([
                    "number"=>$request->business["number"],
                ]);
            }
            
        }

        if($request->personal["image"]){
            $user->image = $request->personal["image"];
            $user->save();
        }

        $user->Address()->delete();
        foreach($request->address as $address){
            
            BusinessAddress::create([
                "user_id"=>$user->id,
                "street_name"=>$address['street_name'],
                "city_id"=>(int)$address['city_id'],
                "country_id"=>(int)$address['country_id'],
                "postal_no"=>(int)$address['postal_no'],
            ]);
        }

        
        return FacadesResponse::json(["message"=>"dskjfdjkfjdsfjdskl"],200);
    }







    public function showclient($id){
        $user = User::find($id);
        return view("Dashboard.Client.part.clientshow",compact('user'));
    }


    public function client(){
        $users = User::where("status","0")->paginate(10);
        $count = User::where("status","0")->get()->count();
        return view("Dashboard.Client.part.client",compact('users','count'));
    }

    public function ChangeStatus(Request $request){
        $user = User::find($request->id);
        $user->status= $request->status;
        $user->save();
        send_notification([$user->fcm_token], "Congratulations" , "Congratulations Your account has been block","refused");
        store_notification($user->id, "Congratulations" , "Congratulations Your account has been block","info");
        return response(["user"=>$user],200);
    }


    public function uploadImage(Request $request){
            $image = $request->file("file")->store("storage/Users/");
            return response(["image"=>$image],200);
    }
    
        public function uploadFont(Request $request){
        $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));
        $fileFont;
            if ($receiver->isUploaded()) {
                $save = $receiver->receive();
                if ($save->isFinished()) {
                    $font = $this->saveFile($save->getFile(),$request->name);
                    $fileFont = FontFamil::create($font);
                } else {
                    /** @var AbstractHandler $handler */
                    $handler = $save->handler();
                    
                    return response()->json([
                        "done" => $handler->getPercentageDone(),
                    ]);
                }
            } else {
                throw new UploadMissingFileException();
            }
        
        return response(["fonts"=>$fileFont],200);
    }



    protected function saveFile(UploadedFile $file,$name)
    {
        $fileName = $this->createFilename($file);
        $mime = str_replace('/', '-', $file->getMimeType());
        $dateFolder = date("Y-m-W");
        $filePath = "Fonts/{$dateFolder}/";
        $finalPath = storage_path("../public/storage/".$filePath);
        $file->move($finalPath, $fileName);
        return[
            'file' => 'storage/'.$filePath.$fileName,
            'name' => $name,
            'type' => "ttf",
        ];
    }


    protected function createFilename(UploadedFile $file)
    {
        $extension = $file->getClientOriginalExtension();
        $filename = str_replace(".".$extension, "", $file->getClientOriginalName()); // Filename 
        $filename .= "_" . md5(time()) . ".";
        return $filename."ttf";
    }


    public function getAllUsers(){
        $users = User::select()->where("status","<>","0")->paginate(15);
        $this->setDate("",$users);
        $this->setStatus(200);
        $this->setMessage("success");     
        return $this->SendApiResponse();
    }

    public function getAllUsersFilter(Request $request){
        $datawhere = [];
        foreach($request->search as $index=>$value){
            $datawhere[]=[$value['name'],'LIKE','%'.$value['value'].'%'];
        }
       
        $users = User::where($datawhere)->where("status","<>","0")->paginate(15);
        $this->setDate("",$users);
        $this->setStatus(200);
        $this->setMessage("success");     
        return $this->SendApiResponse();
    }

}
