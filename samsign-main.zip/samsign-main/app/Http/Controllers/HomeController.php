<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Menu;
use App\Models\ProductContentList;
use App\Models\menuContent;
use App\Models\DesignTemplate;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index($id)
    {
            $template = Menu::find($id);
            $data['template']= $template;
            return view("home",compact('data'));      
        }
        public function show($id){
            $menu = Menu::find($id);
            return view('show')->with(["menu"=>$menu]); 
        }

}
