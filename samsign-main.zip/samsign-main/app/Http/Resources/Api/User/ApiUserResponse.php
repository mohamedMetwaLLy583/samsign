<?php

namespace App\Http\Resources\Api\User;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ApiUserResponse extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data =  parent::toArray($request);
        $result = [
            "id"=>$data["id"],
            "username"=>$data["username"],
            "email"=>$data["email"],
            "phone"=>$data["phone"],
            "token"=>$data["token"],
            "status"=>$this->statusUser($data["status"]),
            "isverified"=>$data["active_user"]!==null? false: true,
            "business"=>[
                "id"=>$data["business"]["id"],
                "name"=>$data["business"]["name"],
                "description"=>$data["business"]["description"],
                "org_no"=>$data["business"]["org_no"],
                "number"=>$data["business"]["number"]
            ],
        ];
        return $result;

    }
    
    
       public function statusUser($status){
        
        if($status == "1"){
            return 1; //"Active"
        }elseif($status == "2"){
            return 2; //"Stopped"
        }elseif($status == "3"){
            return 3; //"Refused"
        }elseif($status == "4"){
            return 4; //"trail"
        }else{
            return 0; //"pending"
        }
        
    }
}
