<?php

namespace App\Http\Resources\Api\Menu;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Mpdf;
use Pdfcrowd\HtmlToImageClient;
use Spatie\Browsershot\Browsershot;
use App\Models\DesignTemplate;
class MenuResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        $result = [
            "id"=>$data["id"],
            "image"=>asset($data['tempalet']?$data['tempalet']['preview']:"Dashboard/image/logo.png"),
            "name"=>$data["name"],
            "view"=>$data["view"],
            "created"=>date("Y-m-d",strtotime($data["created_at"])),
            "updated"=>date("Y-m-d",strtotime($data["updated_at"])),
            "screen"=>count($data["screens"]),
            "background"=>asset($data['image']),
            "menu_preview"=>asset($data['tempalet']?$data['tempalet']['preview']:asset($data['image'])),
            "template"=>[
                "id"=>$data['template'],
                "image"=>asset($data['tempalet']?$data['tempalet']['preview']:"Dashboard/image/logo.png"),
            ],
            "lists"=> $this->textDeign($data["id"]),
            ];
        //     if($data["lists"]){
        //          foreach($data["lists"] as $list){
        //     $result['lists'][]= [
        //          "id"=>$list["id"],
        //         "name"=>$list["name"],
        //     ];
        // }   
        //     }else{
        //         $result["lists"] = [];
        //     }
        return $result;
    }
    
    
    public function textDeign($id){
        $templateDesign = DesignTemplate::where("menu_id",$id)->where("type","text")->get(['id','num',"type","content"]);
        $data = [];
        if($templateDesign){
              $data["titleTemplate"]=[
                            "id"=>$templateDesign[0]->id,
                            "text"=>"title Menu",
                            "oldtext"=>"title Menu",
                    ];            
        }
        foreach($templateDesign as $index=>$value){
            foreach(json_decode($value->content)->children as $value2){
                if($value2->className == "Text"){
                    $data["group1"][]=[
                      "id"=>$value->id,
                      "text"=>$value2->attrs->text,
                      "oldtext"=>$value2->attrs->text,
                    ]; 
                }
                
            }
        }
    
        return $data;
        
    }
}
