<?php

namespace App\Http\Resources\Api\Menu;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TemplateResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        
        $result = [
            "id"=>$data["id"],
            "image"=>asset($menu->preview),
            "name"=>$data["name"],
            "view"=>$data["view"],
            "created"=>date("Y-m-d",strtotime($data["created_at"])),
            "updated"=>date("Y-m-d",strtotime($data["updated_at"])),
            "screen"=>count($data["screens"]),
            "background"=>asset($data['image']),
            "menu_preview"=>asset($menu->preview),
            "template"=>[
                "id"=>$data['template'],
                "image"=>asset("example.png"),
            ],

            ];
            if($data["list_template"]){
            $i = 1;
            foreach($data["list_template"] as $index=>$list){
            $result['lists'][]= [
                "id"=>(int)($list["id"]."01024372350"),
                "name"=>"List".$i,
            ];
            $i++;
        }   
            }else{
                $result["lists"] = [];
            }
        return $result;
    }
    
}
