<?php

namespace App\Http\Resources\Api\Screen;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Pdfcrowd\HtmlToImageClient;
class ScreenTemplateResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        
        $result =  parent::toArray($request);
        // return $result;
        $data = [];
        if($result){
             $data = [
                    "name"=>$result["name"],
                    "use"=>$result["use"],
                    "type"=>$result["type"] == "1"?"fixed":"schedule",
                    "created"=>date("Y-m-d",strtotime($result["created_at"])),
                    "updated"=>date("Y-m-d",strtotime($result["updated_at"]))
            ];
            foreach($result["screens_template"] as $value){            
                    $data["menus"][]=[
                        "id"=>$value["id"],
                        "name"=>$value["menus"]["name"],
                        "from"=>$value["from"],
                        "to"=>$value["to"],
                        "image"=>"https://verasign.se/public/".$value["menus"]['id'],
                    ];
                    $data["view"] = $value["menus"]["view"]?"Hirozental":"virtacl";
            }
        }
        return $data;
    }
}
