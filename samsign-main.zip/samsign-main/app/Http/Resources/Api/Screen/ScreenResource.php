<?php

namespace App\Http\Resources\Api\Screen;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Pdfcrowd\HtmlToImageClient;

class ScreenResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $result =  parent::toArray($request);
        $data = [];
                          
        if($result){
           
                foreach($result as $screen){            
                    $data[]=[
                        "id"=>$screen["id"],
                        "name"=>$screen["name"],
                        "image"=>asset($screen["screens_template"]?$screen["screens_template"][0]["menus"]?"https://verasign.se/public/".$screen["screens_template"][0]["menus"]["id"]:"Dashboard/image/logo.png":"Dashboard/image/logo.png"),
                    ];
            }
        }

        return $data;
    }
}
