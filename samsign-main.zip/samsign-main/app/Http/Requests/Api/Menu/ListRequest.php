<?php

namespace App\Http\Requests\Api\Menu;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
class ListRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            "id"=>"required|numeric|exists:menus,id",
            "name"=>"required|string|min:3",
            "status_price"=>"required|string|in:1,0",
            "price"=>"sometimes",
            "product"=>"required|array",
            "product.*"=>"required|numeric|exists:productss,id",
        ];
    }
    protected function failedValidation(Validator $validator) { 
        $response = [
            "message"   =>$validator->errors()->first(),
            "status"    =>422,
        ];
        throw new HttpResponseException(response()->json($response, 422)); 
    }
}
