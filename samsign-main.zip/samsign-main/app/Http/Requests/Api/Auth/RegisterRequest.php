<?php

namespace App\Http\Requests\Api\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
          return [
            "personal"=>"required|array",
            "address"=>"required|array",
            "business"=>"required|array",
            
            "personal.username"=>"required|string|min:3|unique:users,username",
            "personal.phone"=>"required|numeric|min:3|unique:users,phone",
            "personal.email"=>"required|email|min:3|unique:users,email",
            "personal.password"=>"required|string|min:8",
            "personal.platform"=>"sometimes|string|min:3|in:ios,android",
            "personal.fcm_token"=>"sometimes|string|min:5",
            
            // "address.country_id"=>"required|numeric|exists:countries,id",
            // "address.city_id"=>"required|numeric|exists:cities,id",
            // "address.street_name"=>"required|string|min:5",
            // "address.postal_no"=>"required|string|min:4",
            
            
            "business.name"=>"required|string|min:3|unique:business_details,name",
            // "business.description"=>"required|string|min:5",
            // "business.org_no"=>"required|string|min:3|unique:business_details,org_no",
            // "business.number"=>"required|string|min:8|unique:business_details,number",
        ];
    }


    public function messages(){
        return [

        ];
    }
    
    protected function failedValidation(Validator $validator) { 
        $response = [
            "message"   =>$validator->errors()->first(),
            "status"    =>422,
        ];
        throw new HttpResponseException(response()->json($response, 422)); 
    }
}
