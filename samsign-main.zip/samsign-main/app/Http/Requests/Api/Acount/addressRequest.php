<?php

namespace App\Http\Requests\Api\Acount;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
class addressRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            "address_id"=>"required|numeric|exists:business_addresses,id",
            "country_id"=>"required|numeric|exists:countries,id",
            "city_id"=>"required|numeric|exists:cities,id",
            "street_name"=>"required|string|min:5",
            "postal_no"=>"required|string|min:4",
        ];
    }

    public function messages(){
        return [

        ];
    }
    
    protected function failedValidation(Validator $validator) { 
        $response = [
            "message"   =>$validator->errors()->first(),
            "status"    =>422,
        ];
        throw new HttpResponseException(response()->json($response, 422)); 
    }
}
