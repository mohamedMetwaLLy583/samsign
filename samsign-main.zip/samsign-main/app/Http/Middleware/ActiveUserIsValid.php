<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class ActiveUserIsValid
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {

        if( Auth::check() && Auth::user()->ActiveUser != null){
            Auth::guard("api")->logout();
            return new JsonResponse([
                "message"   =>"Verification code has been sent to your email For Active your Account, please check",
                "status"    =>"401",
            ],Response::HTTP_UNAUTHORIZED);
        }
        return $next($request);
    }
}
