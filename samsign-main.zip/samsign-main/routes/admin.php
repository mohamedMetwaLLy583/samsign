<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "Dashboard" middleware group. Make something great!
|
*/

;

Route::group(["prefix"=>"Auth","namespace"=>"Auth","as"=>"auth."],function(){
    Route::get('/login', "LoginController@index")->name('index');
    Route::post('process/login', "LoginController@Process")->name('login');

});

Route::group(["prefix"=>"/","middleware"=>"auth:admin"],function(){
    Route::group(["prefix"=>"/","namespace"=>"Home","as"=>"Home."],function(){
        Route::get("index","HomeController@index")->name("index");
    });
     Route::group(["prefix"=>"/template","namespace"=>"Template","as"=>"template."],function(){
        Route::get("/","TemplateController@index")->name("index");
        Route::get("/make/create/{id}","TemplateController@makeTemlate")->name("make.create");
        Route::get("/edit/{id}","TemplateController@edit")->name("edit");
        Route::get("/editor/{id}","TemplateController@editor");
        Route::get("/{id}","TemplateController@show")->name("show");
        Route::get("/get/{id}","TemplateController@getshow");
        Route::get("preview/{id}","TemplateController@preview")->name("preview");
        Route::post("/store","TemplateController@store")->name("store");
        Route::post("/update/{id}","TemplateController@update")->name("update");
        Route::post("/delete","TemplateController@destroy")->name("delete");
        Route::get("get/template/{id}","TemplateController@getTemplate");


        Route::post("/store/preview","TemplateController@storepreview")->name("store.preview");

        Route::post("/save/action","TemplateController@saveContent");

        // Background
        Route::post("/upload/image","BackgroundTemplateController@uploadImage")->name("upload.image");
        Route::post("/upload/video","BackgroundTemplateController@uploadVideo")->name("upload.video");
        // List Template
        Route::post("/List","ListTemplateController@process")->name("List");        
    
    });

    Route::group(["prefix"=>"/clients","namespace"=>"Client","as"=>"client."],function(){
        Route::get("/","ClientController@index")->name("index");
        Route::get("/{id}","ClientController@show")->name("show");
        Route::get("/create","UserController@create")->name("user.create");
        Route::get("/edit/{id}","ClientController@edit")->name("edit");
        Route::get("/update/{id}","ClientController@update")->name("update");
        Route::get("/screen/{id}","ClientController@screen")->name("show.screen");
        Route::get("/template/{id}","ClientController@template")->name("show.template");
        Route::post("/delete","ClientController@destroy")->name("delete");
        Route::get("/screen/show/{id}","ClientController@screenshow")->name("template.screen");

    });

    Route::group(["prefix"=>"Users","namespace"=>"Users","as"=>"User."],function(){
        Route::get("/","UserController@index")->name("index");
        Route::get("/create","UserController@create")->name("create");
        Route::post("/store","UserController@store")->name("store");
        Route::post("/update/{id}","UserController@update")->name("update");

        Route::get("/request/client/{id}","UserController@showclient")->name("show.client.form");
        Route::get("/request","UserController@client")->name("show.client");
        Route::post("/upload/image","UserController@uploadImage")->name("upload.image");
        Route::post("/upload/font","UserController@uploadFont")->name("upload.font");
        Route::post("/Change/Status","UserController@ChangeStatus")->name("change.status");

        Route::get("/get/all","UserController@getAllUsers");
        Route::post("/get/filter","UserController@getAllUsersFilter");

    });

    Route::group(["prefix"=>"Setting","namespace"=>"Setting","as"=>"setting."],function () {
        Route::get("/","SettingController@index")->name("index");
    });

    Route::group(["prefix"=>"City","namespace"=>"City","as"=>"city."],function () {
        Route::get("/","CityController@index")->name("index");
        Route::post("/upload/image","CityController@uploadImage")->name("upload.image");
        Route::post("/store","CityController@store")->name("store");
        Route::post("/delete","CityController@destroy")->name("delete");
        Route::get("/show/{id}","CityController@show")->name("show");
    });

    Route::group(["prefix"=>"Country","namespace"=>"Country","as"=>"country."],function () {
        Route::get("/","CountryController@index")->name("index");
        Route::post("/upload/image","CountryController@uploadImage")->name("upload.image");
        Route::post("/store","CountryController@store")->name("store");
        Route::post("/delete","CountryController@destroy")->name("delete");
        Route::get("/show/{id}","CountryController@show")->name("show");
    });

    Route::group(["prefix"=>"Language","namespace"=>"Language","as"=>"language."],function () {
        Route::get("/","LanguageController@index")->name("index");
    });

    Route::group(["prefix"=>"notification","namespace"=>"Notification","as"=>"notification."],function () {
        Route::get("/","NotificationController@index")->name("index");
          Route::post("/store","NotificationController@store")->name("store");
    });
    Route::group(["prefix"=>"search","namespace"=>"Search","as"=>"search."],function(){
        Route::get('/', "SearchController@index")->name('index');
    });
    Route::group(["prefix"=>"Auth","namespace"=>"Auth","as"=>"auth."],function(){
        Route::get('/account',"LoginController@indexAcount")->name('account.index');
        Route::get('edit/account',"LoginController@editAcount")->name('account.update');
        Route::post('/logout', "LoginController@logout")->name('logout');
    });
});
Route::get('/home/{id}', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
