<?php
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/



Route::group(["prefix"=>"Auth","namespace"=>"Auth"],function(){
    Route::post("/login","LoginController@authentication");
    
    Route::post("/Register","RegisterController@store");
    Route::post("/forget/password","ForgetPasswordController@ForgetPassword");
    Route::post("/code/forget/password","verificationController@checkCodeForget");
    Route::post("resend/code","verificationController@resend");
    Route::post("check/code","verificationController@checkCodeUser");


    Route::get("/QR/code","LoginController@QRcode");
    Route::post("/QR/scan/code","LoginController@scanQrCode");
    Route::post("/QR/check/code","LoginController@CheckQrCode");
});

Route::group(["prefix"=>"country","namespace"=>"Country"],function(){
    Route::get("/","CountryController@country");
    Route::get("code/number","CountryController@codeNumber");
    Route::get('/get/address','CountryController@getAddress');
});

Route::group(["prefix"=>"city","namespace"=>"City"],function(){
    Route::get("/","CityController@index");
    Route::get("/{id}","CityController@city");
});
Route::group(['prefix'=>'template',"namespace"=>"Menu"],function(){
    Route::get("/design/{id}","TemplateController@show");
    Route::post("/design/stores","TemplateController@store");
    Route::post("/updata/{id}","TemplateController@updata");
});
Route::group(["prefix"=>"fonts","namespace"=>"Menu"],function(){
    Route::get("/","MenuController@fonts");
});

Route::group(["middleware"=>["auth:api","activeUserIsValid"]],function(){
    Route::group(["prefix"=>"Auth","namespace"=>"Auth"],function(){
        Route::post("reset/password","ResetPasswordController@reset");
        Route::post("change/password","ResetPasswordController@change");
        Route::post("/logout","LogoutController@logout");
    });

    Route::group(["prefix"=>"menu","namespace"=>"Menu"],function(){
        Route::get("/template","MenuController@templates");
        Route::get("/","MenuController@index");
        Route::get("/text/{id}","MenuController@menuText");
         Route::post("/text/update/{id}","MenuController@updatemenuText");
        Route::get("/{id}","MenuController@show");
        Route::post("/first/create","MenuController@store");
        Route::post("/second/create","MenuController@liststore");
        
        Route::get("lists/{id}","MenuController@MenuLists");
        Route::delete("delete/background/{id}","MenuController@deleteimage");
        Route::post("/first/edit/{id}","MenuController@edit");
        Route::post("/second/edit/{id}","MenuController@editliststore");
        
        Route::get("list/{id}","MenuController@showlist");
         Route::delete("list/delete/{id}","MenuController@listdestroy");
         
         
        Route::delete("delete/{id}","MenuController@destroy");
    });
    
      Route::group(["prefix"=>"screen","namespace"=>"Screen"],function(){
          Route::get("/","ScreenController@index");
        Route::get("/{id}","ScreenController@show");
        Route::post("/create","ScreenController@store");
         Route::post("/edit/{id}","ScreenController@edit");
        Route::delete("delete/{id}","ScreenController@destroy");
    });
    
    Route::group(["prefix"=>"Search","namespace"=>"Search"],function(){
        Route::get("/","SearchController@index");
    });
    
      Route::group(["prefix"=>"notificatios","namespace"=>"notifications"],function(){
                Route::get("/","notificationController@index");
    });



    Route::group(["prefix"=>"account","namespace"=>"Account"],function(){
        Route::post("edit/personal","AccountController@personal");
        Route::get("address","AccountController@address");
        Route::post("edit/address","AccountController@Editaddress");
        Route::post("add/address","AccountController@Addaddress");
        Route::post("delete/address","AccountController@deleteaddress");
        Route::post("edit/business","AccountController@business");
        Route::get("/Profile","AccountController@Profile");
        
    });
    Route::group(["prefix"=>"category","namespace"=>"Category"],function(){
        Route::get("/","CatgeoryController@index");
          Route::post("/create","CatgeoryController@create");
        Route::post("/edit/{id}","CatgeoryController@edit");
        Route::delete("/delete/{id}","CatgeoryController@destroy");
    });
    
    Route::group(["prefix"=>"products","namespace"=>"Product"],function(){
        Route::get("/","ProductController@all");
        Route::get("/{id}","ProductController@index");
        Route::get("/show/{id}","ProductController@show");
        Route::post("/create","ProductController@store");
        Route::post("/edit/{id}","ProductController@update");
        Route::delete("/{id}","ProductController@destroy");
    });

});


Route::group(["prefix"=>"setting","namespace"=>"Setting"],function(){
    Route::get("/about","SettingController@About");
    Route::get("/privacy","SettingController@privacy");
    Route::post("/contact","ContactUsController@ContactUs");
     Route::get("/social","SettingController@social");
});
Route::group(["prefix"=>"language","namespace"=>"Setting"],function(){
    Route::get("/","SettingController@language");
});

Route::group(["prefix"=>"Search","namespace"=>"Search"],function(){
    Route::get("/language","SearchController@language");
});

  Route::group(["prefix"=>"/template","namespace"=>"API","as"=>"template."],function(){
        // Background
        Route::post("/upload/image","BackgroundTemplateController@uploadImage")->name("upload.image");
        Route::post("/upload/video","BackgroundTemplateController@uploadVideo")->name("upload.video");      
});
