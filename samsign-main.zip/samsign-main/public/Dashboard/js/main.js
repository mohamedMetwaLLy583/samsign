function randomString(type,idvideo="") {
    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
    var string_length = 8;
    var randomstring = '';
    for (var i = 0; i < string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        randomstring += chars.substring(rnum, rnum + 1);
    }
    if (type == "text" && type != undefined) {
        objectsUse.unshift({ "id": "text-" + randomstring, "type": type });
    } else if(type == "video" && type != undefined){
        objectsUse.unshift({ "id": idvideo, "type": type });
    }else{
        if(type != undefined){
            objectsUse.unshift({ "id": randomstring, "type": type });
        }
    }
    // objectsUse.reverse();
    InsertItemHistory(objectsUse);
    InsertItemObject(objectsUse);
    return randomstring;
}
const frames = [];
window.sizenumber = 0;
window.zindex = 1;
window.styleparent;
// TouchEmulator();
//      Konva.hitOnDragEnabled = true;
//      Konva.captureTouchEventsEnabled = true;



function SaveActionTemplate() {
    var id = $(this).attr("data-id");
    var type = $(this).attr("data-type");
    var content = $(this);

    var dataSend = {
        "type": type,
        "content": content,
        "_token": $('meta[name="csrf-token"]').attr('content'),
    };

    if (id > 0) {
        var lock = $(this).attr("data-lock");
        var hidden = $(this).attr("data-hidden");
        dataSend.id = id;
        dataSend.lock = lock;
        dataSend.hidden = hidden;
    }

    $.post({
        "url": Base_Url + "Dashboard/template/save/action",
        data: dataSend,
    }).then((data) => {
        console.log(data);
    });

}


$(document).on("click", "#shape", function () {
    $('#list-shape-show').slideToggle("slow");
});

$(document).on('input', '#preview-background', function () {
    var backgedit = stage.find('#priview-background')[0];
    console.log(backgedit);
    console.log($(this).val());
    backgedit.fill($(this).val());
})



