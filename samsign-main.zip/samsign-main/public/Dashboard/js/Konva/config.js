
var width = $("#body-design").width();
var height = $("#body-design").height();
if (templateDesign.length > 0) {
    var designTemplate = JSON.parse(JSON.parse(menudesign));
    templateDesign.map((v, i) => {
        designTemplate.children.push(JSON.parse(v));
    });
    window.stage = Konva.Node.create('{"attrs":{"width":' + width + ',"height":' + height + '},"className":"Stage","children":[{"attrs":{},"className":"Layer","children":[' + JSON.stringify(designTemplate) + ',{"attrs":{},"className":"Transformer"},{"attrs":{"fill":"rgba(0,0,255,0.5)","visible":false},"className":"Rect"}]}]}', 'body-design');
} else {
    window.stage = Konva.Node.create('{"attrs":{"width":' + width + ',"height":' + height + '},"className":"Stage","children":[{"attrs":{},"className":"Layer","children":[{"attrs":{},"className":"Transformer"},{"attrs":{"fill":"rgba(0,0,255,0.5)","visible":false},"className":"Rect"}]}]}', 'body-design');
}
window.layer = new Konva.Layer();
if (templateDesign.length <= 0) {
    var widthshow = '1024';
    
    var x = 1000 /25;
    var y = 10;
    if (templateShow == '0') {
        x = 600 /5;
    }
    window.group = new Konva.Group({
        x: 0,
        y: 0,
        width: width,
        height: height,
        id: "Group-edit"
    });
    var background = new Konva.Rect({
        x: 0,
        y: 0,
        width: width,
        height: height,
        fill: "#fff",
        listening: false,
        id: "priview-background",
    });
    background.zIndex(-1);
    // 
    window.layer.add(group);
    window.group.add(background);
}

if (images.length > 0) {
    images.map((value, index) => {
        var imageget = JSON.parse(value);
        Konva.Image.fromURL(imageget.attrs.id, function (darthNode) {
            darthNode.setAttrs(imageget.attrs);
            stage.find('#Group-edit')[0].add(darthNode);
        });
    });
}

if (videos.length > 0) {
    videos.map((value, index) => {
        var videoget = JSON.parse(value);
        var video = document.createElement('video');
        video.src = videoget.attrs.id.split('video')[1];
        var objattr = videoget.attrs;
        objattr.image = video;
        var image = new Konva.Image(objattr);
        stage.find('#Group-edit')[0].add(image);
        var anim = new Konva.Animation(function () { }, stage.find('#Group-edit')[0].getLayer());
        video.addEventListener('loadedmetadata', function (e) {
            image.width(video.videoWidth);
            image.height(video.videoHeight);
        });
        if (typeof video.loop == 'boolean') { // loop supported
            video.loop = true;
        } else { // loop property not supported
            video.addEventListener('ended', function () {
                this.currentTime = 0;
                this.play();
            }, false);
        }
        video.muted = true;
        video.play();
        anim.start();
    });

}

function widthDisplayH(){
    var x = 0;
    var width = $(window).width();
    if(width < 400){
        console.log("400");
        x = width/30;
    }else if(width > 400 && width < 1000){
        console.log("1000");
        x = width/28;
    }else if(width > 1000 && width < 1024){
        console.log("1024");
        x = width/15;
    }else if(width > 1024 && width < 1500){
        console.log("1025");
        x = width/10;
    }else{
        x = width/6;
    }
    return x;
}

function widthDisplayv(){
    var x = 0;
    var width = $(window).width();
    if(width < 400){
        console.log("400");
        x = width/30;
    }else if(width > 400 && width < 1000){
        console.log("1000");
        x = width/40;
    }else if(width > 1000 && width < 1024){
        console.log("1024");
        x = width/60;
    }else if(width > 1024 && width < 1500){
        console.log("1025");
        x = width/30;
    }else if(width > 1500 && width < 1900){
        console.log("1026");
        x = width/10;
    }else{
        console.log("1027");
        x = width/5;
    }
    return x;
}
