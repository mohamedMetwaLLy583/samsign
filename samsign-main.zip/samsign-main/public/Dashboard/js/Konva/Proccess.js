window.stage.on('click', function (e) {
    console.log(e.target);
    $('html').keyup(function (x) {
        $idext = [];
        if (x.keyCode == 46) {
            if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                $(`div[layer-div=${e.target.attrs.id}]`).remove();
                    objectsUse.map((v, index) => {
                        if (v.id == e.target.attrs.id) {
                            delete objectsUse[index];
                        }
                    });
                e.target.destroy();
            }
        }
    });

    $(document).on("click", ".header-delete-shape", function () {
        if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
            $(`div[layer-div=${e.target.attrs.id}]`).remove();
            objectsUse.map((v, index) => {
                if (v.id == e.target.attrs.id) {
                    delete objectsUse[index];
                }
            });
            e.target.destroy();
        }
    });

    
   

    $(document).on("click", ".header-lock-diplcated", function () {
        e.target.attrs.x +=20;
        e.target.attrs.y +=20;
        if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
            if (e.target.textArr) {
                stage.find('#Group-edit')[0].add(new Konva.Text(e.target.attrs));
            } else if (e.target.attrs.image) {
                stage.find('#Group-edit')[0].add(new Konva.Image(e.target.attrs));
            } else {                
                if(e.target.className == 'Circle'){
                    stage.find('#Group-edit')[0].add(new Konva.Circle(e.target.attrs));
                }else if(e.target.className == 'Star'){
                        stage.find('#Group-edit')[0].add(new Konva.Star(e.target.attrs));
                }else if(e.target.className == 'RegularPolygon'){
                        stage.find('#Group-edit')[0].add(new Konva.RegularPolygon(e.target.attrs));
                }else if(e.target.className == 'Arrow'){
                        stage.find('#Group-edit')[0].add(new Konva.Arrow(e.target.attrs));
                }else{
                    stage.find('#Group-edit')[0].add(new Konva.Rect(e.target.attrs));
                }
                
            }

        }
    });



    if (e.target._id == 2 || e.target._id == 1) {
        $('#list-shape-show-edit').css("display", "none");
        $('#list-shape-show').css("display", "none");
        $("#text-template-show").css("display", "none");
    } else {
        if (e.target.textArr) {
            var textNode = e.target;
            textNode.on('transform', () => {
                // with enabled anchors we can only change scaleX
                // so we don't need to reset height
                // just width
                textNode.setAttrs({
                  width: Math.max(textNode.width() * textNode.scaleX(), 20),
                  scaleX: 1,
                  scaleY: 1,
                });
              });
            
            ActiveButtonCheckText(e.target);
            EditTextByTools(e);
        } else {
            EditShapeByTools(e);
        }

    }

});


function EditShapeByTools(e){
    if(e.target.className == 'Circle'){
        $('#list-shape-show-edit #shape-border-raduis').parent().css('display','none'); 
    }else{
        $("#dropdown-border-shape").css("padding-bottom","20px");
        $("#dropdown-border-shape").css("max-height","fit-content");
         $('#list-shape-show-edit #shape-border-raduis').parent().css('display','block'); 
    }
    $('#list-shape-show-edit').css("display", "block");
            $('#list-shape-show-edit #shape-border-shape').on("input", function () {
                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.stroke(value);
                }
            });
            var amplitude = 50;
            var period = 3000;
            // in ms
            var centerX = stage.width() / 2;
            $('#list-shape-show-edit #shape-background-shape').on("input", function () {

                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    // var anim = new Konva.Animation(function (frame) {
                    //     e.target.x(
                    //       amplitude * Math.sin((frame.time * 2 * Math.PI) / period) + centerX
                    //     );
                    //   }, layer);
                    //     anim.start();
                    e.target.fill(value);
                }
            });

            $('#list-shape-show-edit #shape-border-size').on("input", function () {
                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.strokeWidth(Number(value));
                    e.target.strokeHeight(Number(value));
                }
            });


            $('#list-shape-show-edit #shape-border-raduis').on("input", function () {
                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.cornerRadius(Number(value));
                }
            });


            $('#list-shape-show-edit #clear-shape-background').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.fill("#fff0");
                }
            });

            $('#list-shape-show-edit #shape-optciy').on("click", function () {
                var value = $(this).val();
                    
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.opacity(value);
                }

            });



            $('#list-shape-show-edit #shadow-menu-shape .colors').on("input", function () {
                var value = $(this).val();
                console.log(value);
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.shadowColor(value);
                }
            });
            $('#clear-shadow-shape').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    $('#list-shape-show-edit #shadow-menu-shape .xss').val(0);
                    $('#list-shape-show-edit #shadow-menu-shape .yss').val(0);
                    $('#list-shape-show-edit #shadow-menu-shape .blur-shadows').val(0);
                    
                    e.target.shadowColor('fff');
                    e.target.shadowBlur(0);
                    e.target.shadowOffsetY(0);
                    e.target.shadowOffsetX(0);
                }
            });
            $('#list-shape-show-edit #shadow-menu-shape .xss').on("input", function () {
                var value = $(this).val();

                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.shadowOffsetX(value);
                }
            });

            $('#list-shape-show-edit #shadow-menu-shape .yss').on("input", function () {
                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.shadowOffsetY(value);
                }
            });

            $('#list-shape-show-edit #shadow-menu-shape .blur-shadows').on("input", function () {
                var value = $(this).val();
            
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.shadowBlur(value);
                }
            });

            $('#list-shape-show-edit #shadow-menu-shape .blur-shadows').on("input", function () {
                var value = $(this).val();
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.shadowBlur(value);
                }
            });






            $(document).on("change", ".animate", function () {
                period = $("#animate-timer").val() * 1000;
                amplitude = $("#animate-amplitude").val();
                var value = $(this).val();
                var centerX = e.target.attrs.x;
                var centery = e.target.attrs.y;
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    window.anim = new Konva.Animation(function (frame) {
                        e.target.rotate((frame.timeDiff * amplitude) / period);
                    }, layer);
                }


                anim.start();

            });
}


function EditTextByTools(e){
    e.target.on("dblclick dbltap", function () {
                textNodeText(e.target);
            });

            $("#text-template-show").css("display", "block");
            $('#list-text-show-edit #font-fimaly').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.fontFamily(value);
                }
            });


            $('#list-text-show-edit #font-size').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.fontSize(value);
                }
            });

            $('#list-text-show-edit #line-height').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.lineHeight(Number(value));
                }
            });

            // $('#list-text-show-edit #shape-border-raduis').on("input",function(){
            //      if(e.target._id == e.currentTarget.mouseClickEndShape._id){
            //     var value = $(this).val();
            //     e.target.radius(Number(value));

            //     }
            // });


            $('#list-text-show-edit #clear-shape-background').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    e.target.fill("#fff0");
                }
            });
            
            $('#list-text-show-edit #font-width').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    console.log(e.target.width());
                    e.target.setAttrs({
                        width: Number(value),
                    });
                }
            });

            $('#list-text-show-edit #shape-optciy').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.opacity(value);
                }

            });

            $('#list-text-show-edit #shadow-menu .colorst').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.shadowColor(value);
                }

            });
            $('#list-text-show-edit #shadow-menu .xsst').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.shadowOffsetX(value);
                }
            });

            $('#list-text-show-edit #shadow-menu .ysst').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.shadowOffsetY(value);
                }
            });

            $('#list-text-show-edit #color-text').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.fill(value);
                }
            });

            $('#list-text-show-edit #align').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.align(value);
                }
            });

            $('#list-text-show-edit #text-inline').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    if (e.target.attrs.textDecoration === "line-through") {
                        e.target.textDecoration("none");
                        $("#text-inline").css("background-color", "#12121200!important");
                    } else {
                        e.target.textDecoration("line-through");
                        $("#text-inline").css("background-color", "#000!important");
                    }

                }
            });

            $('#list-text-show-edit #text-underline').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    if (e.target.attrs.textDecoration === "underline") {
                        e.target.textDecoration("none");
                        $("#text-underline").css("background-color", "#12121200!important");
                    } else {
                        e.target.textDecoration("underline");
                        $("#text-underline").css("background-color", "#000!important");
                    }
                }
            });

            $('#list-text-show-edit #text-bold').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    if (e.target.attrs.fontStyle === "bold") {
                        e.target.fontStyle("normal");
                        $("#text-bold").css("background-color", "#12121200!important");
                    } else {
                        e.target.fontStyle("bold");
                        $("#text-bold").css("background-color", "#000!important");
                    }
                }
            });

            $('#list-text-show-edit #shape-border').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.stroke(value);
                }
            });

            $('#list-text-show-edit #shape-border-size').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.strokeWidth(value);
                }
            });


            $('#list-text-show-edit #opacity-text').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    e.target.opacity(value);
                }
            });


            $('#list-text-show-edit #text-itlaic').on("click", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {

                    if (e.target.attrs.fontStyle == "italic") {
                        e.target.fontStyle("normal");
                        $("#text-itlaic").css("background-color", "#12121200!important");
                    } else {
                        e.target.fontStyle("italic");
                        $("#text-itlaic").css("background-color", "#000!important");
                    }
                }
            });

            $('#list-text-show-edit #shadow-menu .blur-shadowst').on("input", function () {
                if (e.target._id == e.currentTarget.mouseClickEndShape._id) {
                    var value = $(this).val();
                    // e.target.shadowOffset({
                    //   x: 20,
                    //   y: 10
                    // });
                    // e.target.shadowColor('#00ff00');
                    e.target.shadowBlur(value);
                }
            });
}

function textNodeText(textNode) {
   
}

function ActiveButtonCheckText(textNode){
    if (textNode.attrs.fontStyle && textNode.attrs.fontStyle == "bold") {
        $("#text-bold").css("background-color", "#000!important");
        $("#text-bold").css("padding", "5px 9px!important");
    } else {
        $("#text-bold").css("background-color", "#12121200!important");

    }
 if (textNode.attrs.fontStyle && textNode.attrs.fontStyle == "italic") {
        $("#text-itlaic").css("background-color", "#000!important");
    } else {
        $("#text-itlaic").css("background-color", "#12121200!important");

    }

    if (textNode.attrs.textDecoration && textNode.attrs.textDecoration == "underline") {
        $("#text-underline").css("background-color", "#000!important");
    } else {
        $("#text-underline").css("background-color", "#12121200!important");

    }

    if (textNode.attrs.textDecoration && textNode.attrs.textDecoration == "line-through") {
        // textDecoration("line-through")
        $("#text-inline").css("background-color", "#000!important");
    } else {
        $("#text-inline").css("background-color", "#12121200!important");

    }
}

// stage.on('dblclick tap', (e) => {
//     // if we have scale, just reset
//     const zoomed = stage.scaleX() !== 1;
//     if (zoomed) {
//       stage.to({
//         x: 0,
//         y: 0,
//         scaleX: 1,
//         scaleY: 1
//       });
//       return;
//     }
//     // ignore if clicked not on shape
//     const clickOnShape = e.target instanceof Konva.Shape;
//     if (!clickOnShape) {
//       return;
//     }
//     // where shape is placed
//     const box = e.target.getClientRect();
//     // how much do we need to zoom for that
//     const scale = Math.min(stage.width() / box.width, stage.height() / box.height);
  
//     // let's do it
//     stage.to({
//       x: -box.x * scale,
//       y: -box.y * scale,
//       scaleX: scale,
//       scaleY: scale,
//     })
//   })