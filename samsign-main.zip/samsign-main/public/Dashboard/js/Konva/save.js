const dataContentarray = [];
var i = 1;
function FilterShapeToSave() {
    stage.find('#Group-edit')[0].children.map((value, index) => {
        if (stage.find('#Group-edit')[0].children.length >= i) {
            if (value.className == "Image") {
                if (value.attrs.id.split('/')[0] == 'video') {
                    dataContentarray.push({ "type": "video", "value": JSON.stringify(value) });
                } else {
                    dataContentarray.push({ "type": "image", "value": JSON.stringify(value) });
                }
            } else if (value.attrs.id && value.attrs.id.split('-')[0] == 'text') {
                dataContentarray.push({ "type": "text", "value": JSON.stringify(value) });
            } else {
                dataContentarray.push({ "type": "shape", "value": JSON.stringify(value) });
            }
            i += 1;
        }
    });
    stage.find('#Group-edit')[0].children = [];
    // stage.find('#Group-edit')[0].attrs.scaleX = 1;
    // stage.find('#Group-edit')[0].attrs.scaleY = 1;
    window.styleparent = stage.find('#Group-edit')[0];
    objectsUse.length = 0;
    $("#body-layer").children().map((e,i)=>{
        objectsUse.push({
            "id":$(i).attr("layer-div"),
            "type":$(i).attr("layer-type")
        });
    });
    return dataContentarray;
};