var i = 0.1;
var total=1.0;
var templatetransform ;
var zoomCount= 10;
$(document).on("click","#zoomin",function(){
    var GFG = $("#body-design");
    var transformexysi = $("#body-design").css('transform');
    templatetransform = templatetransform !== undefined?templatetransform:transformexysi; 
    GFG.css("transform" ,"scale("+(i+total)+")");
    zoomCount = zoomCount+5;
    $("#count-zoom").text((zoomCount)+"%");
    
    total = i+total;
});

$(document).on("click","#zoomout",function(){
    console.log(total);
    var GFG = $("#body-design");
    var transformexysi = $("#body-design").css('transform');
    templatetransform = templatetransform !== undefined?templatetransform:transformexysi; 
    if(total > 0.2){
         GFG.css("transform","scale("+(total-0.1)+")");
         zoomCount = zoomCount-5;
         $("#count-zoom").text(zoomCount+"%");
         total-=0.1;
    }

});



$(document).on("click","#all-templates",async function(e){
    var myElement = $('#template-show');
    Swal.fire({
     title: '<p class="text-center text-white" style="font-size: 20px;border-bottom: 1px solid #c7c3c3a6;line-height: 57px;font-weight: 400;">Open from Existing templates</p>',
     html:myElement,
     customClass:"swal2-popup-template",
     focusConfirm: false,
   });
});

$(document).on("dblclick",".use-template",function(){
    var id = $(this).attr("data-id");
    $.get({url:"/Dashboard/template/get/template/"+id}).then((data)=>{
        if(data.menu.style != null){
        var width = $("#body-design").width();
        var height = $("#body-design").height();
        var designTemplate = JSON.parse(JSON.parse(data.menu.style));
        if (data.layers.length > 0) {
            data.layers.map((v, i) => {
                designTemplate.children.push(JSON.parse(v));
            });
    }
    
    window.stage = Konva.Node.create('{"attrs":{"width":' + width + ',"height":' + height + '},"className":"Stage","children":[{"attrs":{},"className":"Layer","children":[' + JSON.stringify(designTemplate) + ',{"attrs":{},"className":"Transformer"},{"attrs":{"fill":"rgba(0,0,255,0.5)","visible":false},"className":"Rect"}]}]}', 'body-design');
        window.layer = new Konva.Layer();
        window.stage.add(window.layer);

       if (images.length > 0) {
        images.map((value, index) => {
            var imageget = JSON.parse(value);
            Konva.Image.fromURL(imageget.attrs.id, function (darthNode) {
                darthNode.setAttrs(imageget.attrs);
                stage.find('#Group-edit')[0].add(darthNode);
            });
        });
}

if (videos.length > 0) {
    videos.map((value, index) => {
        var videoget = JSON.parse(value);
        var video = document.createElement('video');
        video.src = videoget.attrs.id.split('video')[1];
        var objattr = videoget.attrs;
        objattr.image = video;
        var image = new Konva.Image(objattr);
        stage.find('#Group-edit')[0].add(image);
        var anim = new Konva.Animation(function () { }, stage.find('#Group-edit')[0].getLayer());
        video.addEventListener('loadedmetadata', function (e) {
            image.width(video.videoWidth);
            image.height(video.videoHeight);
        });
        if (typeof video.loop == 'boolean') { // loop supported
            video.loop = true;
        } else { // loop property not supported
            video.addEventListener('ended', function () {
                this.currentTime = 0;
                this.play();
            }, false);
        }
        video.muted = true;
        video.play();
        anim.start();
    });

}        
        }else{
             Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: "Template not ready to Use.",
                        showConfirmButton: false,
                        timer: 2500
                    });
        }
   
    Swal.close();
    });
});

$(document).on("keyup", "#template-name", function() {
    var value = $(this).val();
    var id =$("#menu_idd").val();
    $.post({
        url: "/Dashboard/template/update/"+id,
        data: {
            'name': value,
            _token: '{{ csrf_token() }}'
        }
    }).then((data) => {
        $(this).val(data.name);
    }).catch((error) => {
        console.log(error);
    });
});



$(document).on("input","#preview-background",function(){
    var shape = stage.find('#priview-background')[0];
    shape.fill($(this).val());
});


$(document).on("click","#preview-opacity",function(){
	$(".preview").css("background-color","#0000");
});

$(document).on("click",".close-layer",function(){
    $("#dropdownLeftEnd").addClass("hidden");
    $("#dropdownLeftEnd").removeClass("block");
})

$(document).on("click","#dropdownLeftEndButton",function(){
    $("#dropdownLeftEnd").addClass("block");
    $("#dropdownLeftEnd").removeClass("hidden");
    $("#dropdownLeftEnd").css("position","absolute");
    $("#dropdownLeftEnd").css("right","20%");
    $("#dropdownLeftEnd").css("transform","translate(-52px, -120px)");

})



$(document).ready(function(){
    objectsUse.map((e,i)=>{
        console.log(e);
        if(e.id != undefined){
            stage.find("#"+e.id)[0].zIndex(zi);
        }
    });    
});


