$(document).on("click", "#preview-template", async function () {
    // $(".swal2-popup-list").remove();
    // html2canvas(document.getElementById("html-content-holder"), {
    //     allowTaint: true, useCORS: true
    // }).then(function (canvas) {
    //     var anchorTag = document.createElement("a");
    //     document.body.appendChild(anchorTag);
    //     $(".preview-Img").append(canvas);
    // });
    const id = $(this).attr('layer-id');
    Swal.fire({
        title: '<p class="text-center text-white" style="font-size: 15px;border-bottom: 1px solid #c7c3c3a6;line-height: 57px;font-weight: 400;">File name</p>',
        html: ` <div class="relative shadow-md p-0 overflow-hidden card" style="background-color: rgba(255, 255, 255, 0.16)">
            <iframe
            class="min-h-screen"
                id="inlineFrameExample"
                title="Inline Frame Example"
                width="1000"
                height="600"
                style="width: 100%!important"
                src="https://verasign.se/${id}">
                </iframe>
            
        </div>`,
        customClass: "swal2-popup-preivew",
        focusConfirm: false,
    });


});

Swal.close();
