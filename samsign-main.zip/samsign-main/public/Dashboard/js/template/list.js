$(document).on("click", "#list-template", async function () {
    var token = $('meta[name="csrf-token"]').attr('content');
    var myElement3 = $('#list-show');
    var AllElemen = myElement3 != null?myElement3:AllElemen;
    console.log(myElement3);
    const { value: formValues } = await Swal.fire({
     title: '<p class="text-center text-white" style="font-size: 25px;border-bottom: 1px solid #c7c3c3a6;line-height: 57px;font-weight: 700;">Create new list</p>',
     html:AllElemen,
     customClass:"swal2-popup-list",
     focusConfirm: false,
     preConfirm: () => {
       // return [{
       //     "_token":document.getElementById('token').value,
       //     "user_id":document.getElementById('user_id').value,
       //     "title":document.getElementById('title').value,
       //     "body":document.getElementById('body').value
       // }]
     }
   })

   if (formValues) {

   }
});





function handleClick(cb) {
    cb.value = cb.checked ? 1 : 0;
}

$(document).on("submit","#list-form",function(e){
    e.preventDefault();
    var elms = JSON.parse(window.stage.toJSON()).children;
    var menu = [
  {
    "attrs": {
      "text": "Title Menu",
      "fontSize": 40,
      "fill": "#fff",
      "fillAfterStrokeEnabled": true,
      "name": "rect",
      "draggable": true,
      "width": 200,
      "x": 132,
      "y": 7,
      "scaleX": 0.9999999999999996,
      "scaleY": 0.7
    },
    "className": "Text"
  },
  {
    "attrs": {
      "text": "category",
      "fontSize": 40,
      "fill": "#fff",
      "fillAfterStrokeEnabled": true,
      "name": "rect",
      "draggable": true,
      "width": 200,
      "x": 128.99999999999986,
      "y": 38.99999999999983,
      "scaleX": 0.9800000000000008,
      "scaleY": 0.7749999999999994
    },
    "className": "Text"
  },
  {
    "attrs": {
      "text": "120",
      "fontSize": 40,
      "fill": "#fff",
      "fillAfterStrokeEnabled": true,
      "name": "rect",
      "draggable": true,
      "width": 200,
      "x": -5.999999999999886,
      "y": 1.0000000000000853,
      "scaleX": 0.4368814308429516,
      "scaleY": 0.4368814308429514
    },
    "className": "Text"
  },

  {
    "attrs": {
      "text": "12",
      "fontSize": 40,
      "fill": "#000",
      "fillAfterStrokeEnabled": true,
      "name": "rect",
      "draggable": true,
      "width": 200,
      "x": 149.62864707180717,
      "y": 130.3257294143615,
      "scaleX": 0.4918567646409637,
      "scaleY": 0.49185676464096334
    },
    "className": "Text"
  },
  {
    "attrs": {
      "text": "15",
      "fontSize": 40,
      "fill": "#000",
      "fillAfterStrokeEnabled": true,
      "name": "rect",
      "draggable": true,
      "width": 200,
      "x": 227.03721521694297,
      "y": 130.6680052472218,
      "scaleX": 0.3991693451444018,
      "scaleY": 0.4382230088696574
    },
    "className": "Text"
  },
];
    var dataForm = $(this).serializeArray();

    var contenMenu=[{
    "attrs": {
      "width": 330,
      "height": 250,
      "fill": "#f0f0f0",
      "name": "rect",
      "x": -5.840586671519988e-14,
      "y": -10.999999999999954,
      "scaleX": 1.1359254910073042,
      "scaleY": 1.1799254910073047
    },
    "className": "Rect"
  },
  {
                "attrs": {
                  "width": 150,
                  "height": 80,
                  "fill": "blue",
                  "stroke": "white",
                  "cornerRadius": 10,
                  "strokeWidth": 3,
                  "name": "rect",
                  "draggable": true,
                  "x": 111.54901960784298,
                  "y": 38.20481927710841,
                  "scaleX": 1.366013071895426,
                  "scaleY": 0.46987951807229006
                },
                "className": "Rect",
              }

  ];
    var valueProducts=0;
    dataForm.map((value,index)=>{

        if(value.name == 'list_name' && value.value == '1'){
            contenMenu.push({
                "attrs": {
                  "width": 150,
                  "height": 80,
                  "fill": "black",
                  "stroke": "white",
                  "cornerRadius": 10,
                  "strokeWidth": 3,
                  "name": "rect",
                  "draggable": true,
                  "x": 128.43137254901978,
                  "y": 3.1686746987950993,
                  "scaleX": 1.2875816993464038,
                  "scaleY": 0.4457831325301209
                },
                "className": "Rect"
              });
            contenMenu.push(menu[0]);
        }

        if(value.name == 'list_price' && value.value == '1'){
            contenMenu.push({
                "attrs": {
                  "radius": 70,
                  "fill": "blue",
                  "stroke": "white",
                  "strokeWidth": 4,
                  "name": "rect",
                  "draggable": true,
                  "x": 7.088520763511042,
                  "y": 13.687400975097319,
                  "scaleX": 0.41345677863841523,
                  "scaleY": 0.3985749996569076
                },
                "className": "Circle"
              });
            contenMenu.push(menu[2]);
        }

        if(value.name=='size_number' && Number(value.value) > 0){
            for (var i = 1; i <= Number(value.value); ++i) {
                var x = 159.68666189892457;
                if(i == 2){

                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x+(i*20),
                      "y": 102.68666189892457,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "sm",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x+(i*20),
                       "y": 96.99999999999956,
                      "scaleX":0.4118461291591778,"scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );
                }else if(i == 1){

                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x,
                      "y": 102.68666189892457,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "sm",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x,
                      "y": 96.99999999999956,
                      "scaleX":0.4118461291591778,"scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );

                }else{
                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x+(i*30),
                      "y": 102.68666189892457,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "sm",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x+(i*26),
                      "y": 96.99999999999956,
                      "scaleX":0.4118461291591778,"scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );
                }

            }
        }




        if(value.name=='product_number' && Number(value.value) > 0){
            var biggerz = 30;
            valueProducts  = Number(value.value);
            for (var i = 1; i <= Number(value.value); ++i) {

                if(i > 1){
                    contenMenu.push({
                        "attrs": {
                            "text": "product",
                            "fontSize": 40,
                            "fill": "#000",
                            "fillAfterStrokeEnabled": true,
                            "name": "rect",
                            "draggable": true,
                            "width": 200,
                            "x": 9.999999999999964,
                            "y": 121.99999999999967+biggerz*i,
                            "scaleX": 0.6599999999999997,
                            "scaleY": 0.7999999999999957
                        },
                        "className": "Text"
                    });
                    biggerz+=2;
                }else{
                    contenMenu.push({
                        "attrs": {
                            "text": "product",
                            "fontSize": 40,
                            "fill": "#000",
                            "fillAfterStrokeEnabled": true,
                            "name": "rect",
                            "draggable": true,
                            "width": 200,
                            "x": 9.999999999999964,
                            "y": 121.99999999999967+25*i,
                            "scaleX": 0.6599999999999997,
                            "scaleY": 0.7999999999999957
                        },
                        "className": "Text"
                    });
                }


                    if(sizenumber > 0){
                        for (var z = 1; z <= window.sizenumber; ++z) {
                           var x = 159.38666189892457;
                        if(z == 2){
                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x+(z*20),
                      "y": 120.3257294143615+40*i,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "12",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x+(z*20),
                       "y": 120.3257294143615+40*i,
                      "scaleX":0.4118461291591778,
                      "scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );
                }else if(z == 1){

                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x,
                      "y": 120.3257294143615+40*i,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "12",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x,
                      "y": 120.3257294143615+40*i,
                      "scaleX":0.4118461291591778,"scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );

                }else{
                    contenMenu.push({
                    "attrs": {
                      "radius": 70,
                      "fill": "black",
                      "stroke": "white",
                      "strokeWidth": 4,
                      "name": "rect",
                      "draggable": true,
                      "x": x+(z*30),
                      "y": 120.3257294143615+40*i,
                      "scaleX": 0.22657414029271505,
                      "scaleY": 0.22657414029271522
                    },
                    "className": "Circle"
                });
                contenMenu.push(
                    {
                    "attrs": {
                      "text": "12",
                      "fontSize": 40,
                      "fill": "#fff",
                      "fillAfterStrokeEnabled": true,
                      "name": "rect",
                      "draggable": true,
                      "width": 200,
                      "x": x+(z*26),
                      "y": 120.3257294143615+40*i,
                      "scaleX":0.4118461291591778,"scaleY":0.4118461291591776
                    },
                    "className": "Text"
                  },
                );
                }

                        }
                    }
            }
        }


        if(value.name == "product_description"){
            var biggerd = 20;
            for (var i = 1; i <= valueProducts; ++i) {
                contenMenu.push({
                    "attrs": {
                        "text": "info",
                        "fontSize": 40,
                        "fill": "#000",
                        "fillAfterStrokeEnabled": true,
                        "name": "rect",
                        "draggable": true,
                        "width": 200,
                        "x": 46.000000000000036,
                        "y": 153+biggerd*i,
                        "scaleX": 0.47888090698724156,
                        "scaleY": 0.47888090698724184
                    },
                    "className": "Text"
                });
                biggerd+=6;
            }
        }
    });
             var randomStringb = randomString("menu");
           elms.push({"attrs":{},"className":"Layer","children":[{"attrs":{"x":85,"y":85,"width":130,"height":25,"draggable":true,"id":randomStringb},"className":"Group","children":contenMenu},{"attrs":{"x":135.00000000000003,"y":241},"className":"Shape"}]},{"attrs":{},"className":"Layer","children":[{"attrs":{},"className":"Transformer"},{"attrs":{"fill":"rgba(0,0,255,0.5)","visible":false},"className":"Rect"}]});
            window.stage = Konva.Node.create('{"attrs":{"width":1024,"height":400},"className":"Stage","children":' + JSON.stringify(elms) +'}', 'html-content-holder');
            window.layer = new Konva.Layer();
            window.stage.add(window.layer);

            $.post({
        url:"/Dashboard/template/List",
        data:$(this).serializeArray()
    }).then((data)=>{
        console.log(data);
        Swal.fire('Saved!', '', 'success');
        Swal.close();
        var products = "";
        // var randomStringb = randomString();
        }).catch((error)=>{
            console.log("Error");
        });


});

$(document).on("input",'#list-price',function(){
    if($(this).val() == 1){
        $("#number_price_size").css("display","none!important");
        $('.size-number-list').css("display","none!important");
    }else{
        $("#number_price_size").css("display","block!important");
        $('.size-number-list').css("display","none!important");
    }

});

