$(document).on("click","#background-template",async function(){
    var token = $('meta[name="csrf-token"]').attr('content');
    var myElement2 = $('#background-show');
    var AllElemen = myElement2 != null?myElement2:AllElemen;
    console.log(AllElemen);
    const { value: formValues } = await Swal.fire({
     title: '<p class="text-center text-white" style="font-size: 25px;border-bottom: 1px solid #c7c3c3a6;line-height: 57px;font-weight: 700;">Upload</p>',
     'html':myElement2 != null?myElement2:AllElemen,
     customClass:"swal2-popup-background",
     focusConfirm: false,

     preConfirm: () => {
       // return [{
       //     "_token":document.getElementById('token').value,
       //     "user_id":document.getElementById('user_id').value,
       //     "title":document.getElementById('title').value,
       //     "body":document.getElementById('body').value
       // }]
     }
   })

   if (formValues) {

   }

});

$(document).on("click","#videoPreview",function(){
    let idMenu = $(this).attr("data-id");
    let browseFile = $('#videoUpload');
    let resumable = new Resumable({
    target:"/Dashboard/template/upload/video",
    query:{_token:$('meta[name="csrf-token"]').attr('content'),id:idMenu},
    fileType: ["mpeg","ogg","mp4","webm","3gp","mov","flv","avi","wmv","ts"],
    headers: {
        'Accept' : 'application/json'
    },
    testChunks: false,
    throttleProgressCallbacks: 1,
});

resumable.assignBrowse(browseFile[0])
resumable.on('fileAdded', function (file) {

    resumable.upload() ;
     AmagiLoader.show();
});
resumable.on('fileSuccess', function (file, response) {
    AmagiLoader.show();
	console.log(response);
   var video = document.createElement('video');
      video.src =`/storage/${JSON.parse(response).path}/${JSON.parse(response).name }`;

      var image = new Konva.Image({
        image: video,
        draggable: true,
        x: 50,
        y: 20,
        name: 'rect',
        id:`video/storage/${JSON.parse(response).path}/${JSON.parse(response).name }`
      });
      stage.find("#Group-edit")[0].add(image);
     objectsUse.unshift({"id":`video/storage/${JSON.parse(response).path}/${JSON.parse(response).name }`,"type":"video"});
     InsertItemHistory(objectsUse);
     InsertItemObject(objectsUse);
    var anim = new Konva.Animation(function () {
        // do nothing, animation just need to update the layer
      }, stage.find("#Group-edit")[0].getLayer());

      // update Konva.Image size when meta is loaded
      video.addEventListener('loadedmetadata', function (e) {
        image.width(video.videoWidth);
        image.height(video.videoHeight);
      });
      if (typeof video.loop == 'boolean') { // loop supported
          video.loop = true;
        } else { // loop property not supported
          video.addEventListener('ended', function () {
            this.currentTime = 0;
            this.play();
          }, false);
      }
      video.play();
      anim.start();
   AmagiLoader.hide();
   Swal.close();
});
});


$(document).on("click","#imagePrevieww",function(){
    let idMenu = $(this).attr("data-id");
    let browseFile = $('#imageUpload');
    let resumable = new Resumable({
    target:"/Dashboard/template/upload/image",
    query:{_token:$('meta[name="csrf-token"]').attr('content'),id:idMenu},
    fileType: ["jpg","png","jpeg"],
    headers: {
        'Accept' : 'application/json'
    },
    testChunks: false,
    throttleProgressCallbacks: 1,
});

resumable.assignBrowse(browseFile[0])
resumable.on('fileAdded', function (file) {
     AmagiLoader.show();
    resumable.upload()
});
resumable.on('fileSuccess', function (file, response) {
        
        AmagiLoader.show();
            var imageObj = new Image();
            imageObj.onload = function () {
                var yoda = new Konva.Image({
                  x: 50,
                  y: 50,
                  image: imageObj,
                  name: 'rect',
                  draggable: true,
                  id:`${JSON.parse(response).image}`,
                });
                stage.find("#Group-edit")[0].add(yoda);
              }
              
            imageObj.src=`${JSON.parse(response).image}`;
            objectsUse.unshift({"id":`${JSON.parse(response).image}`,"type":"image"});
            InsertItemHistory(objectsUse);
            InsertItemObject(objectsUse);

    AmagiLoader.hide();
        Swal.close();
});
});


