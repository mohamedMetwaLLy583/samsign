$(document).on("click","#font-template",async function(){
    // $('#font-show').css('display','block');
    const myElement = $('#font-show').html();
    const { value: formValues } = await Swal.fire({
        title: '<p class="text-center text-white" style="font-size: 25px;border-bottom: 1px solid #c7c3c3a6;line-height: 57px;font-weight: 700;">Upload Font Family</p>',
        html:`<form action="#" method="post" id="font-show">
                    <input type="hidden" value="${menuid}" id="id-menu">
                    <div class="relative w-full max-w-md max-h-full">
                        <div class="relative bg-dark rounded-2xl shadow" style="background-color: #121212;    padding: 30px 20px 15px 20px;
                        width: 32vw;text-align: justify;">
                            <div style="" class="items-center  mt-1 font-medium text-gray-900 grid grid-cols-1 whitespace-nowrap dark:text-white">
                                <div class="flex flex-col mr-4">
                                    <label class="font-semibold leading-none text-gray-300">Font Name </label>
                                    <input required type="name"  style="border-radius:10px!important;height: 52px;background-color: rgba(255, 255, 255, 0.05);" class="leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded-sm sm:rounded-full name-font" placeholder="Font Name" id="name-font" name="name"/>
                                </div>
                            </div>
                            <div class="p-6 text-center" style="text-align: justify;">



                                    <label for="uploadfont" id="uploadfontClick" style="width: 24vw;justify-content: center;background: linear-gradient(93.55deg, #E50914 1.09%, #FF6666 99.2%)!important;" class="button-link-model text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                                    <img src="/Dashboard/image/editor/blus.png" style="width:21px!important">
                                    </label>
                                    <input type="file" id="uploadfont" style="width:100%;display: none!important;">
                            </div>
                        </div>
                </form>`,
        customClass: 'swal-wide-resize',
        focusConfirm: false,
        preConfirm: () => {
            
        }
    })
});

$(document).on("click","#uploadfontClick",function(){
    let browseFile = $('#uploadfont');
    console.log($(".name-font").val());
    let resumable = new Resumable({
    target:"/Dashboard/Users/upload/font",
    query:{_token:$('meta[name="csrf-token"]').attr('content'),"name":$(".name-font").val()},
    fileType: ["otf",'ttf'],
    headers: {
        'Accept' : 'application/json'
    },
    testChunks: false,
    throttleProgressCallbacks: 1,
});

resumable.assignBrowse(browseFile[0])
resumable.on('fileAdded', function (file) {
     AmagiLoader.show();
    resumable.upload()
});
resumable.on('fileSuccess', function (file, response) {
        AmagiLoader.show();
        AmagiLoader.hide();
        Swal.close();
        $("#font-fimaly").empty();
        $("#font-fimaly").append(`<option value="" selected="" hidden="" disabled="">font Family</option>`);
        console.log(file);
        console.log(JSON.parse(response));
        JSON.parse(response).fonts.map((v,i)=>{
            $("#font-fimaly").append(`<option value="${v.name}">${v.name}</option>`);
        });
        var lastfont = JSON.parse(response).fonts[JSON.parse(response).fonts.length - 1];
        var newStyle = document.createElement('style');
        newStyle.appendChild(document.createTextNode('@font-face{font-family: '+lastfont.name+'; src: url('+lastfont.file+');}'));
        document.body.appendChild(newStyle)

});
});
