
$(document).on("click","#Square",function(){
    var randomStringb = randomString("squre");

            var star = new Konva.Rect({
               x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                width: 80,
                height: 80,
                fill: 'red',
                 stroke: 'black',
                cornerRadius: 1,
                strokeWidth: 3,
                name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
            zindex++;

    })