
$(document).on("click","#rectangular",function(){
    var randomStringb = randomString("rectangular");

            var star = new Konva.Rect({
              x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                width: 200,
                height: 100,
                fill: 'red',
                cornerRadius: 10,
                strokeWidth: 3,
                 stroke: 'black',
                name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
            zindex++;
            })