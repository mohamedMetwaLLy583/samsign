
$(document).on("click", "#circle", function () {
        var randomStringb = randomString('circle');
        var circle = new Konva.Circle({
                x: stage.find('#Group-edit')[0].width() / 2,
                y: stage.find('#Group-edit')[0].height() / 2,
                radius: 70,
                fill: 'red',
                stroke: 'black',
                strokeWidth: 4,
                shadowOffsetX: 20,
                shadowOffsetY: 25,
                shadowBlur: 40,
                id: randomStringb,
                name: 'rect',
                draggable: true,
        });
        stage.find('#Group-edit')[0].add(circle);
        zindex++;
});



