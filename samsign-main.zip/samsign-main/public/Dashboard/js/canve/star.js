
$(document).on("click","#star",function(){
    var randomStringb = randomString('star');
            var star = new Konva.Star({
              x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                numPoints: 6,
                innerRadius: 40,
                outerRadius: 70,
                fill: 'yellow',
                stroke: 'black',
                strokeWidth: 4,
                 name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
            zindex++;
})
   