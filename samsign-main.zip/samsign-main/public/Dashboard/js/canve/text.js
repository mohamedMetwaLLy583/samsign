$(document).on("click","#text-template",function(){
    var randomStringb = randomString('text');
    var textNode = new Konva.Text({
        text: 'Title Menu',
        x: stage.find('#Group-edit')[0].width() / 2,
        y: stage.find('#Group-edit')[0].height() / 2,
        fill:'#000',
        fontSize: 40,
        fillAfterStrokeEnabled: true,
        name: 'rect',
        draggable: true,
        width: 200,
        id:"text-"+randomStringb,
      });
      // tr = new Konva.Transformer({
      //   nodes: [textNode],
      //   padding: 5,
      //   flipEnabled: false,
      //   // enable only side anchors
      //   enabledAnchors: ['middle-left', 'middle-right'],
      //   // limit transformer size
      //   boundBoxFunc: (oldBox, newBox) => {
      //     if (Math.abs(newBox.width) < MIN_WIDTH) {
      //       return oldBox;
      //     }
      //     return newBox;
      //   },
      // });
      stage.find('#Group-edit')[0].add(textNode);
});



window.stage.on('dblclick dbltap',function(e){
  if(e.target.attrs.text != undefined){
    var textNode = e.target;
    var x = textNode.offsetLeft;
            var y = textNode.offsetTop;
            textNode.hide();
            tr.hide();

        var textPosition = textNode.absolutePosition();
        var areaPosition = {
          x: textPosition.x / 1,
          y: textPosition.y / 1,
        };
        var textarea = document.createElement('textarea');
        $(".konvajs-content").append(textarea);

        textarea.value = textNode.text();
        textarea.style.position = 'absolute';
        textarea.style.top = areaPosition.y + 'px';
        textarea.style.left = areaPosition.x + 'px';
        textarea.style.width = textNode.width() - textNode.padding() * 2 + 'px';
        textarea.style.height =
        textNode.height() - textNode.padding() * 2 + 5 + 'px';
        textarea.style.fontSize = textNode.fontSize() + 'px';
        textarea.style.textShadow = `2px 2px ${textNode.stroke()}`;
        textarea.style.padding = '0px';
        textarea.style.margin = '0px';
        textarea.style.overflow = 'hidden';
        textarea.style.background = 'none';
        textarea.style.outline = 'none';
        textarea.style.resize = 'none';
        textarea.style.lineHeight = textNode.lineHeight();
        textarea.style.fontFamily = textNode.fontFamily();
        textarea.style.transformOrigin = 'left top';
        textarea.style.textAlign = textNode.align();
        textarea.style.color = textNode.fill();
        rotation = textNode.rotation();
        var transform = '';
        if (rotation) {
          transform += 'rotateZ(' + rotation + 'deg)';
        }

        var px = 0;
        // also we need to slightly move textarea on firefox
        // because it jumps a bit
        var isFirefox =
          navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
        if (isFirefox) {
          px += 2 + Math.round(textNode.fontSize() / 20);
        }
        transform += 'translateY(-' + px + 'px)';

        textarea.style.transform = transform;

        // reset height
        textarea.style.height = 'auto';
        // after browsers resized it we can set actual value
        textarea.style.height = textarea.scrollHeight + 3 + 'px';
        textarea.focus();
        function removeTextarea() {
          textarea.parentNode.removeChild(textarea);
          window.removeEventListener('click', handleOutsideClick);
          textNode.show();
          tr.show();
          tr.forceUpdate();
        }

        function setTextareaWidth(newWidth) {
          if (!newWidth) {
            // set width for placeholder
            newWidth = textNode.placeholder.length * textNode.fontSize();
          }
          // some extra fixes on different browsers
          var isSafari = /^((?!chrome|android).)*safari/i.test(
            navigator.userAgent
          );
          var isFirefox =
            navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
          if (isSafari || isFirefox) {
            newWidth = Math.ceil(newWidth);
          }

          var isEdge =
            document.documentMode || /Edge/.test(navigator.userAgent);
          if (isEdge) {
            newWidth += 1;
          }
          textarea.style.width = newWidth + 'px';
        }

        textarea.addEventListener('keydown', function (e) {
          // hide on enter
          // but don't hide on shift + enter
          if (e.keyCode === 13 && !e.shiftKey) {
            textNode.text(textarea.value);
            removeTextarea();
          }
          // on esc do not set value back to node
          if (e.keyCode === 27) {
            removeTextarea();
          }
        });

        textarea.addEventListener('keydown', function (e) {
          scale = textNode.getAbsoluteScale().x;
          setTextareaWidth(textNode.width() * scale);
          textarea.style.height = 'auto';
          textarea.style.height =
            textarea.scrollHeight + textNode.fontSize() + 'px';
        });

        function handleOutsideClick(e) {
          if (e.target !== textarea) {
            textNode.text(textarea.value);
            removeTextarea();
          }
        }
        setTimeout(() => {
          window.addEventListener('click', handleOutsideClick);
        });
  }
});
