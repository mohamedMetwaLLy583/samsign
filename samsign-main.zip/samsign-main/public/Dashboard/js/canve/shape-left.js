
$(document).on("click","#shape-left",function(){
    var randomStringb = randomString("arrowleft");

            var star = new Konva.Arrow({
              x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                points: [8,5,120,5],
                pointerLength: 10,
                pointerWidth: 30,
                fill: 'black',
                stroke: 'black',
                strokeWidth: 8,
                name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
            zindex++;
            })