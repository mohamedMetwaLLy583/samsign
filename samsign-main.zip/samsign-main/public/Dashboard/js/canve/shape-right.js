
$(document).on("click","#shape-right",function(){
    var randomStringb = randomString("arrowright");

            var star = new Konva.Arrow({
              x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                points: [120,0,0,0],
                pointerLength: 10,
                pointerWidth: 30,
                fill: 'black',
                stroke: 'black',
                strokeWidth: 8,
                name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
        zindex++;
      })