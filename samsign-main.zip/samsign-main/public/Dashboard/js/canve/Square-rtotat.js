
$(document).on("click","#Square-rtotat",function(){
    var randomStringb = randomString("squrerotat");
    var star = new Konva.RegularPolygon({
               x: stage.find('#Group-edit')[0].width() / 2,
    y: stage.find('#Group-edit')[0].height() / 2,
                sides: 4,
                radius: 70,
                fill: 'red',
                stroke: 'black',
                strokeWidth: 4,
                shadowOffsetX : 20,
                shadowOffsetY : 25,
                shadowBlur : 40,
                name: 'rect',
                id:randomStringb,
                draggable: true,
              });
        stage.find('#Group-edit')[0].add(star);
              zindex++;
    })