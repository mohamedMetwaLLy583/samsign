


function InsertItemHistory(items){
    $("#body-layer").empty();
    items.map((value,index)=>{
        if(value.type != undefined ){
        $("#body-layer").append(`
            <div class="grid grid-cols-2 mt-2 mb-2 border rounded rounded-50" layer-icon="${value.icon}"  layer-type="${value.type}" layer-div="${value.id}" style="border-color:#1e1e1e;background-color:#1e1e1e;width: 100%;padding: 10px 5px;align-items: center;">
                                                    <div>
                                                        ${value.type}
                                                    </div>
                                                    <div class="flex flex-inline" style="justify-self: end;">
                                                        <button status="0"  layer-id-btn="${value.id}" rel="noopener noreferrer" style="background-color: #1e1e1e!important;" class="btn-lock flex items-center p-2 space-x-3 rounded-md">
                                                                <img src="/Dashboard/image/editor/lock.png" style="width:20px" />
                                                        </button>
                                                        <button  status="0" layer-id-btn="${value.id}" rel="noopener noreferrer" style="background-color: #1e1e1e!important;"
                                                            class="btn-hidden flex items-center p-2 space-x-3 rounded-md">
                                                            <img src="/Dashboard/image/editor/unhidden.png" style="width:20px" />
                                                        </button>
                                                    </div>
                                                </div>

        `);
        }
    });
}

function InsertItemObject(items){

    $("#body-layer-object").empty();
    
    $("#body-layer-object").append(`
           <div class="grid grid-col-2 mt-2 mb-2 border rounded rounded-50"  style="border-color:#1e1e1e;background-color:#1e1e1e;width: 100%;padding: 10px 5px;align-items: center;text-align: center;display:inline-flex">
                                                                            <div style="margin-right: 22px;">
                                                                                <img src="/Dashboard/image/editor/Initial.png" alt="Initial" width="35" />
                                                                            </div>
                                                                            <div class="flex flex-inline" style="justify-self: end;">
                                                                                Initial
                                                                            </div>
                                                                        </div>
        `);
    items.map((value,index)=>{
        if(value.type != undefined ){
        $("#body-layer-object").append(`
            <div class="grid grid-col-2 mt-2 mb-2 border rounded rounded-50"  style="border-color:#1e1e1e;background-color:#1e1e1e;width: 100%;padding: 10px 5px;align-items: center;text-align: center;display:inline-flex">
                                                    <div style="margin-right: 22px;">
                                                        <img src="/Dashboard/image/editor/${value.type =='text'?"text.png":"shape.png"}" alt="${value.type}" width="35" />
                                                    </div>
                                                    <div class="flex flex-inline" style="justify-self: end;">
                                                        Added : ${value.type}
                                                    </div>
                                                </div>
        `);
        }
    });

}

// InsertItemHistory(objectsUse);
$(document).on("click","#html-content-holder",function(e){
	var elm = e.target;
	if($('#list-shape-show-edit').css("display") == "block"){

	}
});


$(document).on("click",".btn-hidden",function(){
    var layer_id = $(this).attr("layer-id-btn");
    var status = $(this).attr("status");
    if(status == "0"){
        $(".preview [layer-target='"+layer_id+"']").css("display","none");
        $(".preview [layer-target='"+layer_id+"']").attr("data-hide","1");
        $(this).empty();
        $(this).append(`<img src="/Dashboard/image/editor/hidden.png" style='width:20px'>`);
        $(this).attr("status","1");
        var shape = stage.find('#'+layer_id)[0];
        shape.hide();
    }else{
        $(".preview [layer-target='"+layer_id+"']").css("display","block");
        $(".preview [layer-target='"+layer_id+"']").attr("data-hide","0");
        $(this).empty();
        $(this).append(`<img src="/Dashboard/image/editor/unhidden.png" style='width:20px'>`);
        $(this).attr("status","0");
        var shape = stage.find('#'+layer_id)[0];
        shape.show();
    }
});


$(document).on("click",".btn-lock",function(){
    var layer_id = $(this).attr("layer-id-btn");
    var status = $(this).attr("status");
    if(status == "0"){
        $(".preview [layer-target='"+layer_id+"']").css("display","none");
        $(".preview [layer-target='"+layer_id+"']").attr("data-hide","1");
        $(this).empty();
        $(this).append(`<img src="/Dashboard/image/editor/unlock.png" style='width:20px'>`);
        $(this).attr("status","1");
        var shape = stage.find('#'+layer_id)[0];
        shape.listening(false);
    }else{
        $(".preview [layer-target='"+layer_id+"']").css("display","block");
        $(".preview [layer-target='"+layer_id+"']").attr("data-hide","0");
        $(this).empty();
        $(this).append(`<img src="/Dashboard/image/editor/lock.png" style='width:20px'>`);
        $(this).attr("status","0");
        var shape = stage.find('#'+layer_id)[0];
        shape.listening(true);
    }
});
