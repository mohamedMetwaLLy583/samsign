<!DOCTYPE html>
<html>
  <head>
      <script src=" {{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery_3.7.0_jquery.min.js')}} "></script>
      <script src=" {{asset('Dashboard/vendor/js/cdn.tailwindcss.com_3.3.3')}} "></script>
     <script src=" {{asset('Dashboard/vendor/js/konva.min.js')}}"></script>
    <meta charset="utf-8" />
    <title>SAMSINE|{{$menu->name}}</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #f0f0f0;
      }
    </style>
  </head>
    <body class="bg-dark dark:bg-black" id="design"> 

<section class="">
    <div class="">
        <div class="relative shadow-md sm:rounded-lg overflow-hidden card min-h-screen" style="background-color: rgba(255, 255, 255, 0.16)">
            <iframe
            class="min-h-screen"
                id="inlineFrameExample"
                title="Inline Frame Example"
                width="300"
                height="200"
                style="width: 100%!important"
                src="http://127.0.0.1:8000/{{$menu->id}}"
                scrolling="no"    
                >
                </iframe>
            
        </div>
    </div>
</section>
</body>
</html>
