<!DOCTYPE html>
<html>
  <head>
      <script src=" {{asset('Dashboard/js/cdn.tailwindcss.com_3.3.3')}} "></script>
     <script src=" {{asset('Dashboard/js/konva.min.js')}}"></script>
    <meta charset="utf-8" />
    <title>SAMSINE</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #f0f0f0;
      }
    </style>
  </head>

  <body class="h-screen p-4 sm:max-h-screen bg-black dark:bg-black" style="height: 100vh!important;"> 
    <div class="preview max-h-full h-full overflow-hidden  gap-2 justify-center items-center border dark:border-gray-800 sm:rounded-lg"
                                        style="
                                        background-color: rgba(255, 255, 255, 0.16);text-align:center; background-size: cover;background-repeat: no-repeat;background-position: center;width: 100%!important; margin: 0 auto;display: inherit;">

                                            <div id="container" style="background-color: rgba(255, 255, 255, 0.16)"></div>

    </div>

    <script>
      var content = @json($layers);
         var images = @json($images);
      var videos = @json($videos);
      console.log(JSON.stringify(content));
      const stage = Konva.Node.create('{"attrs":{"width":1924,"height":1024},"className":"Stage","children":'+JSON.stringify(content)+'}', 'container') 

      const layer = new Konva.Layer();
      stage.add(layer);
      stage.stopDrag();
      images.map((value,index)=>{
        console.log(value.children[value.children.length-1].attrs.id);
        Konva.Image.fromURL(value.children[value.children.length-1].attrs.id, function (darthNode) {
                darthNode.setAttrs(value.children[value.children.length-1].attrs);
                layer.add(darthNode);
              });
      });



      videos.map((value,index)=>{
        var video = document.createElement('video');
        video.src =value.children[value.children.length-1].attrs.id.split('video')[1];
        var objattr = value.children[value.children.length-1].attrs;
        objattr.image = video;
        var image = new Konva.Image(objattr);
        layer.add(image);
       var anim = new Konva.Animation(function () {}, layer);
        video.addEventListener('loadedmetadata', function (e) {
          image.width(video.videoWidth);
          image.height(video.videoHeight);
        });
        if (typeof video.loop == 'boolean') { // loop supported
            video.loop = true;
          } else { // loop property not supported
            video.addEventListener('ended', function () {
              this.currentTime = 0;
              this.play();
            }, false);
        }
        video.muted = true;
        video.play();
        anim.start();
      });
      // generate random shapes
      

      // function updatePreview() {
      //   const scale = 1 / 4;
      //   // use pixelRatio to generate smaller preview
      //   const url = stage.toDataURL({ pixelRatio: scale });
      //   document.getElementById('preview').src = url;
      // }

      // update preview only on dragend for performance
      // stage.on('dragend', updatePreview);
    </script>
  </body>
</html>