@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div>
            <span style="color: #525252;">Dashboard</span>
         <span style="color: #525252;"> > </span>
         <span style="color: #dcd8d8;">Client List</span>
         </div>
      </div>
  
</div>
<section class="">

   </section>
@endsection

@section("bottom-js")

@endsection