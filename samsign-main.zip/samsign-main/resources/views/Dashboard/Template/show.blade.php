@extends("Dashboard.layouts.master")
@section("title","Templates")
@section("main-content")  
<style>
    *{
       
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
    }
    .card-body .items-center{
        background-color: #000!important;
        border-radius: 12px;
        border: 1px solid #212121;
    }

    .card-body .items-center img{
        background-color: #232323c2!important;
    }

    table , tr{
        color:#717171!important;
        background-color:#000!important;
        vertical-align: baseline!important;
        margin:auto 0px;
    }
    table , tr th{
        vertical-align: baseline!important;
    }
    table , tr td{
        text-align: right;
        padding-right:50px; 
        color:#ababab!important;
    }
    table , tr th svg{
        margin-right: 10px;
    }
    .card-header{

        font-family: 'Inter';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;

    }
</style>
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">{{$menu->name}}</h1>
         <div class="mt-2">
            <span style="color: #9f9f9f;">Dashboard</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #9f9f9f;">Templates</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #dcd8d8;">{{$menu->name}}</span>
        
        </div>
      </div>
      <div class="flex Client-Head">
        
      </div>
</div>
<section class="">
    <div class="">
        <div class="relative shadow-md sm:rounded-lg overflow-hidden card mt-4 min-h-screen" style="background-color: rgba(255, 255, 255, 0.16)">
            <iframe
            class="min-h-screen"
                id="inlineFrameExample"
                title="Inline Frame Example"
                width="300"
                height="200"
                style="width: 100%!important"
                src="http://127.0.0.1:8000/{{$menu->id}}"
                scrolling="no"    
                >
                </iframe>
            
        </div>
    </div>
</section>
@endsection
@section("bottom-js")
    <script>

    </script>
@endsection