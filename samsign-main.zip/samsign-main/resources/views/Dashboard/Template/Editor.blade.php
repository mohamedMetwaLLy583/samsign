@extends("Dashboard.layouts.design")
@section("title","Editor")
@section("main-content")  
    <editor-component :id="{{$data['template']->id}}" :width="{{$data['template']->width}}" :height="{{$data['template']->height}}" ></editor-component>
@endsection
@section("bottom-js")

@endsection
