@extends("Dashboard.layouts.Auth")
@section("main-content")
<div class="container mx-auto px-4">
    <div class="grid grid-rows-1 grid-flow-col">
        <section>
            <div class="min-h-full flex-col justify-end" style="min-height: 44%;">
                <div class="sm:mx-auto sm:w-full sm:max-w-sm">
                    <img src="{{asset("Dashboard/image/logo.png")}}" alt="" loading="lazy">
                </div>
              </div>
            <div class="sm:mx-auto sm:w-full sm:max-w-sm text-white">
                <h1>Welcome Back .!</h1>
                <p>login to access your control pannel</p>
            </div>
        </section>
        
        <section style="margin: 55px 0px;">
            <svg class="fi-circle" xmlns="http://www.w3.org/2000/svg" width="221" height="221" viewBox="0 0 221 221" fill="none">
                <circle cx="110.157" cy="110.157" r="110" transform="rotate(-28.5 110.157 110.157)" fill="url(#paint0_linear_4_913)"/>
                <defs>
                  <linearGradient id="paint0_linear_4_913" x1="110.157" y1="0.157021" x2="110.157" y2="220.157" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#FF4D4D"/>
                    <stop offset="1" stop-color="#E50914"/>
                  </linearGradient>
                </defs>
              </svg>
            <div class="flex-col justify-start px-6 pt-12 lg:px-8" style="text-align: center;text-align: -webkit-center;">
                <div class="sm:mx-auto sm:w-full sm:max-w-sm form-content text-white text-start">
                        <div class="w-100 text-start" style="    align-self: start;">
                            <h3>Login</h3>
                        <p>Glad you’re back.!</p>
                        </div>
                        <form class="space-y-6 px-12 py-6" id="form-login" action="#" method="POST">
                          <div>
                            <div class="mt-2">
                              <input id="username" placeholder="Username" name="username" type="text"  required class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                            </div>
                          </div>
                    
                          <div>
                            <div class="mt-2">
                              <input id="password" placeholder="Password" name="password" type="password"  required class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                            </div>
                          </div>
                          
                          <div>
                            <p id="errorText" style="    color: #ff3636;
    font-size: 13px;
    font-weight: 500;"></p>
                          </div>

                          <div style="display: flex">
                            <div class="mt-2">
                              <input id="remmber" name="remmber" type="checkbox"   class=" w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                            </div>
                            <label for="remmber" class="block text-sm font-medium leading-6 text-gray-900">Remember me</label>
                          </div>

                          <div>
                            <button type="submit" class="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Sign in</button>
                          </div>
                        </form>
                </div>
              </div>
              <div style="width:100%;text-align:-webkit-right!important;text-align: right">
                <svg  xmlns="http://www.w3.org/2000/svg" width="189" height="189" viewBox="0 0 221 221" fill="none" style="    margin-top: -16%;
                margin-right: 9%;">
                    <circle cx="110.157" cy="110.157" r="110" transform="rotate(-28.5 110.157 110.157)" fill="url(#paint0_linear_4_913)"/>
                    <defs>
                      <linearGradient id="paint0_linear_4_913" x1="110.157" y1="0.157021" x2="110.157" y2="220.157" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#FF4D4D"/>
                        <stop offset="1" stop-color="#E50914"/>
                      </linearGradient>
                    </defs>
                  </svg>
              </div>
        </section>
    </div>
</div>
@endsection