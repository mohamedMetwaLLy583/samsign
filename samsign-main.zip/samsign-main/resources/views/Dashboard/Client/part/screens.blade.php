@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<style>
    *{
       
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
    }
    .card-body .items-center{
        background-color: #000!important;
        border-radius: 12px;
        border: 1px solid #212121;
    }

    .card-body .items-center img{
        background-color: #232323c2!important;
    }

    table , tr{
        color:#717171!important;
        background-color:#000!important;
        vertical-align: baseline!important;
        margin:auto 0px;
    }
    table , tr th{
        vertical-align: baseline!important;
    }
    table , tr td{
        text-align: right;
        padding-right:50px; 
        color:#ababab!important;
    }
    table , tr th svg{
        margin-right: 10px;
    }
    .card-header{

        font-family: 'Inter';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;

    }
</style>
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div class="mt-2">
            <span style="color: #9f9f9f;">Dashboard</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #9f9f9f;">Client List</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #9f9f9f;">Clients Details</span> 
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #dcd8d8;">Clients Screens</span> 
        </div>
      </div>
      <div class="flex Client-Head">
        
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       

       <div class="border dark:border-gray-800 relative shadow-md sm:rounded-lg overflow-hidden card mt-4">
        <div class="card-header grid grid-cols-2 px-5 py-5" style="background-color: #232323;color: #fff;">
                <div class="flex" style="font-size: 17px;align-self: center;">
                    <svg width="24" class="mr-2" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.56 17.97H6.44C2.46 17.97 1.25 16.76 1.25 12.78V6.44C1.25 2.46 2.46 1.25 6.44 1.25H17.55C21.53 1.25 22.74 2.46 22.74 6.44V12.77C22.75 16.76 21.54 17.97 17.56 17.97ZM6.44 2.75C3.3 2.75 2.75 3.3 2.75 6.44V12.77C2.75 15.91 3.3 16.46 6.44 16.46H17.55C20.69 16.46 21.24 15.91 21.24 12.77V6.44C21.24 3.3 20.69 2.75 17.55 2.75H6.44Z" fill="white" fill-opacity="0.87"/>
                        <path d="M12 22.7507C11.59 22.7507 11.25 22.4107 11.25 22.0007V17.2207C11.25 16.8107 11.59 16.4707 12 16.4707C12.41 16.4707 12.75 16.8107 12.75 17.2207V22.0007C12.75 22.4107 12.41 22.7507 12 22.7507Z" fill="white" fill-opacity="0.87"/>
                        <path d="M22 13.75H2C1.59 13.75 1.25 13.41 1.25 13C1.25 12.59 1.59 12.25 2 12.25H22C22.41 12.25 22.75 12.59 22.75 13C22.75 13.41 22.41 13.75 22 13.75Z" fill="white" fill-opacity="0.87"/>
                        <path d="M16.5 22.75H7.5C7.09 22.75 6.75 22.41 6.75 22C6.75 21.59 7.09 21.25 7.5 21.25H16.5C16.91 21.25 17.25 21.59 17.25 22C17.25 22.41 16.91 22.75 16.5 22.75Z" fill="white" fill-opacity="0.87"/>
                        </svg>
                        
                        
                        Client Screens
                </div>
                <div class="flex " style="justify-self: self-end;">
                </div>
        </div>
        <div class="card-body">
            <div class="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-2 gap-4 m-4 ">
                @foreach($screens as $screen)

                <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="height:207px;margin-top: 18px;" src="{{asset(count($screen->ScreensTemplate) > 0 ?$screen->ScreensTemplate[0]->menus->preview?$screen->ScreensTemplate[0]->menus->preview:'Dashboard/image/logo.png':'Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                            <a href="{{route('dashboard.client.template.screen',$screen->id)}}" style="    text-decoration: none;color:#fff!important;">
                                <h5 class="mb-2 text-2x font-bold tracking-tight text-gray-900 dark:text-white">{{$screen->name}}</h5>
                            </a>
                            <p class="mb-3 font-normal text-gray-700 dark:text-gray-400" style="color:#9b9b9b!important;">Created in {{date("Y-m-d",strtotime($screen->created_at))}}.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                        </div>
                     </div>
                </div>

                @endforeach
        
            </div>
        </div>
       </div>
   </div>
   </section>
@endsection