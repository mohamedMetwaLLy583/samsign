@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div>
            <span style="color: #525252;">Dashboard</span>
         <span style="color: #525252;"> > </span>
         <span style="color: #dcd8d8;">Clients List</span>
         <span style="color: #525252;"> > </span>
         <span style="color: #dcd8d8;">Clients Requests</span>
         </div>
      </div>
      <div class="flex Client-Head">
        <a type="button" href="{{route('dashboard.User.show.client')}}" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            @if($count > 0)
            <span  class="mr-2" style="    background-color: rgba(246, 65, 65, 1);
          
            border-radius: 20px;
            width: 24px;
            height: 23px;
            font-size: 16px;
            line-height: 20px;
            text-align: -webkit-center;
            text-align: center;
            font-weight: 700;">
            @else
            <span  class="mr-2" style="    background-color: rgb(128 124 124);
          
            border-radius: 20px;
            width: 24px;
            height: 23px;
            font-size: 16px;
            line-height: 20px;
            text-align: -webkit-center;
            text-align: center;
            font-weight: 700;">
            @endif
            {{$count}}
            </span>               
            Client Request
        </a>
         <a type="button" href="{{route('dashboard.User.create')}}" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            <svg class="h-3.5 w-3.5 mr-2" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            </svg>
            Add new Client
        </a>
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       <div class="border dark:border-gray-800 relative shadow-md sm:rounded-lg overflow-hidden">
           <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
            <div class="w-50 md:w-1/2">
                <form class="flex items-center">
                    <label for="simple-search" class="sr-only">Search</label>
                    <div class="relative w-full">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M11 20.75C5.62 20.75 1.25 16.38 1.25 11C1.25 5.62 5.62 1.25 11 1.25C16.38 1.25 20.75 5.62 20.75 11C20.75 16.38 16.38 20.75 11 20.75ZM11 2.75C6.45 2.75 2.75 6.45 2.75 11C2.75 15.55 6.45 19.25 11 19.25C15.55 19.25 19.25 15.55 19.25 11C19.25 6.45 15.55 2.75 11 2.75Z" fill="white" fill-opacity="0.6"/>
                              <path d="M20.1601 22.79C20.0801 22.79 20.0001 22.78 19.9301 22.77C19.4601 22.71 18.6101 22.39 18.1301 20.96C17.8801 20.21 17.9701 19.46 18.3801 18.89C18.7901 18.32 19.4801 18 20.2701 18C21.2901 18 22.0901 18.39 22.4501 19.08C22.8101 19.77 22.7101 20.65 22.1401 21.5C21.4301 22.57 20.6601 22.79 20.1601 22.79ZM19.5601 20.49C19.7301 21.01 19.9701 21.27 20.1301 21.29C20.2901 21.31 20.5901 21.12 20.9001 20.67C21.1901 20.24 21.2101 19.93 21.1401 19.79C21.0701 19.65 20.7901 19.5 20.2701 19.5C19.9601 19.5 19.7301 19.6 19.6001 19.77C19.4801 19.94 19.4601 20.2 19.5601 20.49Z" fill="white" fill-opacity="0.6"/>
                           </svg>
                        </div>
                        <input type="text" id="simple-search" class="search_text bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Search" required="">
                    </div>
                </form>
            </div>
               <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                  
                   <div class="flex items-center space-x-3 w-full md:w-auto">

                   </div>
               </div>
           </div>
           <div class="overflow-x-auto">
               <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                   <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                       <tr>
                           <th scope="col" class="px-4 py-4">Client</th>
                           <th scope="col" class="px-4 py-4">Account status</th>
                           <th scope="col" class="px-4 py-4">Address</th>
                           <th scope="col" class="px-4 py-4">Phone number</th>
                           <th scope="col" class="px-4 py-4">Settings</th>
                          
                       </tr>
                   </thead>
                   <tbody id="result">

                    @foreach ($users as $user)
                    <tr class="border-b dark:border-gray-700">
                        <th scope="row" class="flex items-center px-4 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                           <img src="{{asset($user->image?$user->image:"Dashboard/image/logo.png")}}" alt="{{$user->username}} Front Image" class="w-auto h-11 mr-3 border-gray-300 rounded">
                          <a href="{{route('dashboard.User.show.client.form',$user->id)}}" style="color: #fff!important;">
                           <p>
                           {{$user->business?$user->business->name:" "}}
                           <br />
                           <span style="color: #717171;font-size: 12px;">#{{$user->business?$user->business->org_no:" "}}</span>
                          </p>
                        </a>
                       </th>
                        <td class="px-4 py-3">
                            <button class="btn-status refuased" style="background:rgba(239, 167, 0, 1)!important;">trail(7days)</button>
                        </td>
                           <td class="px-4 py-3">{{count($user->address)>0?$user->address[0]->street_name:""}}</td>
                           <td class="px-4 py-3">{{$user->phone}}</td>
                           <td class="px-4 py-3 flex items-center justify-end">
                               <button data-id="{{$user->id}}" data-status="4" id="apple-imac-27-dropdown-button" data-dropdown-toggle="apple-imac-27-dropdown" class="change-status mr-4 inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none dark:text-gray-400 dark:hover:text-gray-100" type="button">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.9999 0C24.8365 0 32 7.16322 32 15.9996C32 24.8363 24.8365 31.9995 15.9999 31.9995C7.16348 31.9997 0 24.8363 0 15.9996C0 7.16322 7.16348 0 15.9999 0ZM8.8817 17.6243L8.87779 17.6207C8.67337 17.4337 8.56347 17.1819 8.55071 16.9256C8.53795 16.6699 8.62233 16.4087 8.80696 16.2025C8.80956 16.1996 8.81191 16.197 8.81451 16.1944C9.00123 15.9902 9.25305 15.8801 9.5093 15.8673C9.76685 15.8546 10.0296 15.9402 10.2364 16.1272L13.6103 19.1866L21.7063 10.7077C21.899 10.5056 22.155 10.4004 22.4144 10.3942C22.6727 10.3877 22.9337 10.4799 23.136 10.672C23.3384 10.8645 23.4433 11.1213 23.4498 11.3801C23.4563 11.6387 23.3639 11.9002 23.1717 12.1022L14.3955 21.2938C14.3895 21.3001 14.383 21.3061 14.3764 21.3113C14.1902 21.4975 13.947 21.5964 13.6999 21.6056C13.4462 21.6152 13.1887 21.5293 12.9853 21.3451L8.88482 17.6269L8.8817 17.6243Z" fill="url(#paint0_linear_405_12329)"/>
                                    <defs>
                                    <linearGradient id="paint0_linear_405_12329" x1="-2.45869e-08" y1="5.9999" x2="33.2112" y2="8.05848" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#E50914"/>
                                    <stop offset="1" stop-color="#FF6666"/>
                                    </linearGradient>
                                    </defs>
                                    </svg>
                                    
                               </button>
                               <button data-id="{{$user->id}}" data-status="3" id="apple-imac-27-dropdown-button" data-dropdown-toggle="apple-imac-27-dropdown" class="change-status inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none dark:text-gray-400 dark:hover:text-gray-100" type="button">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.9999 0C24.8365 0 32 7.16322 32 15.9996C32 24.8363 24.8365 31.9995 15.9999 31.9995C7.16348 31.9997 0 24.8363 0 15.9996C0 7.16322 7.16348 0 15.9999 0ZM21.2808 9.43378C21.6358 9.07883 22.211 9.07883 22.5662 9.43378C22.9212 9.78872 22.9212 10.3642 22.5662 10.7192L17.285 15.9996L22.566 21.2803C22.9209 21.6352 22.9209 22.2108 22.566 22.566C22.211 22.9206 21.6358 22.9206 21.2806 22.566L15.9999 17.2853L10.7192 22.566C10.3645 22.9206 9.78872 22.9206 9.43378 22.566C9.07883 22.211 9.07883 21.6355 9.43378 21.2803L14.7145 15.9996L9.43378 10.7192C9.07883 10.3642 9.07883 9.78872 9.43378 9.43378C9.78872 9.07883 10.3642 9.07883 10.7192 9.43378L15.9999 14.7145L21.2808 9.43378Z" fill="white" fill-opacity="0.6"/>
                                    </svg>
                                    
                            </button>
                           </td>
                       </tr>
                    @endforeach
                   </tbody>
               </table>
           </div>
           {{ $users->links('pagination::tailwind') }}
       </div>
   </div>
   </section>
@endsection
@section("bottom-js")
   <script>
        $(document).on("click",".change-status",function(){
            var id = $(this).attr("data-id");
            var status = $(this).attr("data-status");
            var statusText;
            if(status == '3'){
                statusText= "Refused";
            }else{
                 statusText= "Active";
            }

            Swal.fire({
              imageUrl: '{{asset('Dashboard/image/warning-2.png')}}',
              imageAlt: 'image',
              text: 'Are you sure you want '+statusText+' this Client ?',
              title: 'Change Status',
                showDenyButton: false,
                showCancelButton: true,
                confirmButtonText: statusText,
              }).then((result) => {
                if (result.isConfirmed) {
                  $.post({
                    url:"{{route('dashboard.User.change.status')}}",
                    "data":{
                      id:id,
                      status:status,
                      "_token":$('meta[name="csrf-token"]').attr('content')
                    }
                  }).then((data)=>{
                    Swal.fire('Saved!', '', 'success');
                    const myTimeout = setTimeout(function(){
                      location.replace("{{url('Dashboard/Users/request')}}");
                    }, 3000);
                    
                  }).catch((error)=>{
                    if(error.status == 422){
                      Swal.fire('Changes are not done', '', 'error')    
                    }
                  });
                } else if (result.isDenied) {
                  Swal.fire('Changes are not done', '', 'info')
                }
              })
          });
          
          
            $(document).on("keyup",".search_text",function(){
                var status;
                $.get({
                    url:"{{route('dashboard.search.index')}}",
                    "data":{
                      "search":$(this).val(),
                      "type":"request"
                    }
                  }).then((data)=>{
                        $("#result").empty();
                        data.data.map((value,index)=>{
                             if (value.status == "1"){
                               status = '<button class="btn-status success" style="background:rgba(63, 174, 0, 1)!important;">Active</button>';
                            }else if(value.status == "2"){
                                    status ='<button class="btn-status stop" style="background:rgba(128, 128, 129, 1)!important;">stoped</button>';
                            }else{
                                status ='<button class="btn-status refuased" style="background:rgba(246, 65, 65, 1)!important;">Refused</button>';
                            }
                             var d = new Date(value.created_at);
                            var datestring =  d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
                            $("#result").append(`
                                     <tr class="border-b dark:border-gray-700">
                                        <th scope="row" class="flex items-center px-4 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                          <img src="{{url('/')}}${value.image?"/"+value.image:"/Dashboard/image/logo.png" }" alt="${value.username} Front Image" class="w-14 h-11 mr-3 border-gray-300 rounded">
                                          <a href="{{url('/')}}${"/Dashboard/Users/request/client/"+value.id}" style="    color: #fff!important;">
                                          <p>
                                          ${value.business.name}
                                          <br />
                                          <span style="color: #717171;font-size: 12px;">#${value.business.org_no}</span>
                                          </p>
                                        </a>
                                      </th>
                                            <td class="px-4 py-3"><button class="btn-status refuased" style="background:rgba(239, 167, 0, 1)!important;">Hanging</button></td>
                                          <td class="px-4 py-3">${value.address?value.address[0].street_name:""}</td>
                                          <td class="px-4 py-3">${value.phone}</td>
                                          <td class="px-4 py-3 flex items-center justify-end">
                                               <button data-id="${value.id}" data-status="1" id="apple-imac-27-dropdown-button" data-dropdown-toggle="apple-imac-27-dropdown" class="change-status mr-4 inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none dark:text-gray-400 dark:hover:text-gray-100" type="button">
                                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.9999 0C24.8365 0 32 7.16322 32 15.9996C32 24.8363 24.8365 31.9995 15.9999 31.9995C7.16348 31.9997 0 24.8363 0 15.9996C0 7.16322 7.16348 0 15.9999 0ZM8.8817 17.6243L8.87779 17.6207C8.67337 17.4337 8.56347 17.1819 8.55071 16.9256C8.53795 16.6699 8.62233 16.4087 8.80696 16.2025C8.80956 16.1996 8.81191 16.197 8.81451 16.1944C9.00123 15.9902 9.25305 15.8801 9.5093 15.8673C9.76685 15.8546 10.0296 15.9402 10.2364 16.1272L13.6103 19.1866L21.7063 10.7077C21.899 10.5056 22.155 10.4004 22.4144 10.3942C22.6727 10.3877 22.9337 10.4799 23.136 10.672C23.3384 10.8645 23.4433 11.1213 23.4498 11.3801C23.4563 11.6387 23.3639 11.9002 23.1717 12.1022L14.3955 21.2938C14.3895 21.3001 14.383 21.3061 14.3764 21.3113C14.1902 21.4975 13.947 21.5964 13.6999 21.6056C13.4462 21.6152 13.1887 21.5293 12.9853 21.3451L8.88482 17.6269L8.8817 17.6243Z" fill="url(#paint0_linear_405_12329)"/>
                                                    <defs>
                                                    <linearGradient id="paint0_linear_405_12329" x1="-2.45869e-08" y1="5.9999" x2="33.2112" y2="8.05848" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#E50914"/>
                                                    <stop offset="1" stop-color="#FF6666"/>
                                                    </linearGradient>
                                                    </defs>
                                                    </svg>
                                                    
                                               </button>
                                               <button data-id="${value.id}" data-status="3" id="apple-imac-27-dropdown-button" data-dropdown-toggle="apple-imac-27-dropdown" class="change-status inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none dark:text-gray-400 dark:hover:text-gray-100" type="button">
                                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.9999 0C24.8365 0 32 7.16322 32 15.9996C32 24.8363 24.8365 31.9995 15.9999 31.9995C7.16348 31.9997 0 24.8363 0 15.9996C0 7.16322 7.16348 0 15.9999 0ZM21.2808 9.43378C21.6358 9.07883 22.211 9.07883 22.5662 9.43378C22.9212 9.78872 22.9212 10.3642 22.5662 10.7192L17.285 15.9996L22.566 21.2803C22.9209 21.6352 22.9209 22.2108 22.566 22.566C22.211 22.9206 21.6358 22.9206 21.2806 22.566L15.9999 17.2853L10.7192 22.566C10.3645 22.9206 9.78872 22.9206 9.43378 22.566C9.07883 22.211 9.07883 21.6355 9.43378 21.2803L14.7145 15.9996L9.43378 10.7192C9.07883 10.3642 9.07883 9.78872 9.43378 9.43378C9.78872 9.07883 10.3642 9.07883 10.7192 9.43378L15.9999 14.7145L21.2808 9.43378Z" fill="white" fill-opacity="0.6"/>
                                                    </svg>
                                                    
                                            </button>
                                         </td>
                                           
                                      </tr>
                            `);
                            console.log(value);
                        });
                    
                  }).catch((error)=>{
                    if(error.status == 422){
                      Swal.fire('Error 505 ', '', 'error')    
                    }
                  });
          });
    </script>
@endsection