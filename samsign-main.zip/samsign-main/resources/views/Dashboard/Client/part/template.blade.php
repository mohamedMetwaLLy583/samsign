@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<style>
    *{
       
        font-style: normal;
        font-weight: 400;
        font-size: 14px;
    }
    .card-body .items-center{
        background-color: #000!important;
        border-radius: 12px;
        border: 1px solid #212121;
    }

    .card-body .items-center img{
        background-color: #232323c2!important;
    }

    table , tr{
        color:#717171!important;
        background-color:#000!important;
        vertical-align: baseline!important;
        margin:auto 0px;
    }
    table , tr th{
        vertical-align: baseline!important;
    }
    table , tr td{
        text-align: right;
        padding-right:50px; 
        color:#ababab!important;
    }
    table , tr th svg{
        margin-right: 10px;
    }
    .card-header{

        font-family: 'Inter';
        font-style: normal;
        font-weight: 400;
        font-size: 14px;

    }
</style>
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div class="mt-2">
            <span style="color: #9f9f9f;">Dashboard</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #9f9f9f;">Client List</span>
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #9f9f9f;">Clients Details</span> 
         <span style="color: #9f9f9f;"> > </span>
         <span style="color: #dcd8d8;">Clients Template</span> 
        </div>
      </div>
      <div class="flex Client-Head">
        
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       

       <div class="border dark:border-gray-800 relative shadow-md sm:rounded-lg overflow-hidden card mt-4">
        <div class="card-header grid grid-cols-2 px-5 py-5" style="background-color: #232323;color: #fff;">
                <div class="flex" style="font-size: 17px;align-self: center;">
                    <svg class="mr-4" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M15 22.75H9C3.57 22.75 1.25 20.43 1.25 15V9C1.25 3.57 3.57 1.25 9 1.25H15C20.43 1.25 22.75 3.57 22.75 9V15C22.75 20.43 20.43 22.75 15 22.75ZM9 2.75C4.39 2.75 2.75 4.39 2.75 9V15C2.75 19.61 4.39 21.25 9 21.25H15C19.61 21.25 21.25 19.61 21.25 15V9C21.25 4.39 19.61 2.75 15 2.75H9Z" fill="white" fill-opacity="0.87"/>
                        <path d="M10 22.75C9.59 22.75 9.25 22.41 9.25 22V2C9.25 1.59 9.59 1.25 10 1.25C10.41 1.25 10.75 1.59 10.75 2V22C10.75 22.41 10.41 22.75 10 22.75Z" fill="white" fill-opacity="0.87"/>
                        <path d="M22 12.75H10C9.59 12.75 9.25 12.41 9.25 12C9.25 11.59 9.59 11.25 10 11.25H22C22.41 11.25 22.75 11.59 22.75 12C22.75 12.41 22.41 12.75 22 12.75Z" fill="white" fill-opacity="0.87"/>
                        </svg>
                        
                        
                        
                        Client Template
                </div>
                <div class="flex " style="justify-self: self-end;">
                </div>
        </div>
        <div class="card-body">
            <div class="grid lg:grid-cols-4 md:grid-cols-2 sm:grid-cols-2 gap-4 m-4 ">

                @foreach($menus as $menu)
                    <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                        <div class="max-w-sm shadow  dark:border-gray-700">
                            <a href="#" style="text-align: -webkit-center;">
                                <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="height:207px;margin-top: 18px;" src="{{asset($menu->preview?$menu->preview:'Dashboard/image/logo.png')}}" alt="" />
                            </a>
                            <div class="px-5">
                                <a href="{{route('dashboard.template.show',$menu->id)}}">
                                    <h5 class="mb-2 text-2x font-bold tracking-tight text-gray-900 dark:text-white">{{$menu->name}}</h5>
                                </a>
                                <p class="mb-3 font-normal text-gray-700 dark:text-gray-400" style="color:#9b9b9b!important;">Created in {{date("Y-m-d",strtotime($menu->created_at))}}.</p>
                            </div>
                            <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            </div>
                        </div>
                </div>

                @endforeach
            </div>
        </div>
       </div>
   </div>
   </section>
@endsection