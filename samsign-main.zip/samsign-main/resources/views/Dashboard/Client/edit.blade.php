@extends('Dashboard.layouts.master')
@section('title', 'Clients')
@section('main-content')
    <div class="grid grid-cols-2 gap-4 mb-4">
        <div class="title-page">
            <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
            <div class="mt-2">
                <span style="color: #9f9f9f;">Dashboard</span>
                <span style="color: #9f9f9f;"> > </span>
                <span style="color: #9f9f9f;">Client List</span>
                <span style="color: #9f9f9f;"> > </span>
                <span style="color: #dcd8d8;">Clients Details</span>
                <span style="color: #9f9f9f;"> > </span>
                <span style="color: #dcd8d8;">Clients Edit</span>
            </div>
        </div>
        <div class="flex Client-Head">
        </div>
    </div>
    <edit-component :data="{{$user}}"></edit-component>

@endsection
   
