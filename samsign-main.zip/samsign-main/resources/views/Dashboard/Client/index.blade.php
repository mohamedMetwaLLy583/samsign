@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div>
            <span style="color: #525252;">Dashboard</span>
         <span style="color: #525252;"> > </span>
         <span style="color: #dcd8d8;">Client List</span>
         </div>
      </div>
      <div class="flex Client-Head">
         <a type="button" href="{{route('dashboard.User.show.client')}}" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            @if($count > 0)
            <span  class="mr-2" style="    background-color: rgba(246, 65, 65, 1);
          
            border-radius: 20px;
            width: 24px;
            height: 23px;
            font-size: 16px;
            line-height: 20px;
            text-align: -webkit-center;
            text-align: center;
            font-weight: 700;">
            @else
            <span  class="mr-2" style="    background-color: rgb(128 124 124);
          
            border-radius: 20px;
            width: 24px;
            height: 23px;
            font-size: 16px;
            line-height: 20px;
            text-align: -webkit-center;
            text-align: center;
            font-weight: 700;">
            @endif
            {{$count}}
            </span>               
            Client Request
        </a>
         <a type="button" href="{{route('dashboard.User.create')}}" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            <svg class="h-3.5 w-3.5 mr-2" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            </svg>
            Add new Client
        </a>
      </div>
</div>
<user-component></user-component>
@endsection

@section("bottom-js")
    <script>
             
    </script>
@endsection