@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<div class="grid grid-cols-2 gap-4 mb-4 mt-4">
      <div class="title-page mb-4">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
        <div>
         <span class="mt-4" style="color: #525252;">Dashboard</span>
         <span class="mt-4" style="color: #525252;"> > </span>
         <span class="mt-4" style="color: #525252;">App</span>
         <span class="mt-4" style="color: #dcd8d8;"> > </span>
         <span class="mt-4" style="color: #dcd8d8;">Countries</span>
         </div>
      </div>
      <div class="flex Client-Head">
        <a type="button"  class="button-link" style="border: none!important">
           
        </a>
         <a type="button" data-modal-target="popup-modal" data-modal-toggle="popup-modal" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            <svg class="h-3.5 w-3.5 mr-2" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            </svg>
            Add Country
        </a>
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       <div class="border dark:border-gray-800 relative shadow-md sm:rounded-lg overflow-hidden">
           <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
            <div class="w-50 md:w-1/2">
                <form class="flex items-center">
                    <label for="simple-search" class="sr-only">Search</label>
                    <div class="relative w-full">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M11 20.75C5.62 20.75 1.25 16.38 1.25 11C1.25 5.62 5.62 1.25 11 1.25C16.38 1.25 20.75 5.62 20.75 11C20.75 16.38 16.38 20.75 11 20.75ZM11 2.75C6.45 2.75 2.75 6.45 2.75 11C2.75 15.55 6.45 19.25 11 19.25C15.55 19.25 19.25 15.55 19.25 11C19.25 6.45 15.55 2.75 11 2.75Z" fill="white" fill-opacity="0.6"/>
                              <path d="M20.1601 22.79C20.0801 22.79 20.0001 22.78 19.9301 22.77C19.4601 22.71 18.6101 22.39 18.1301 20.96C17.8801 20.21 17.9701 19.46 18.3801 18.89C18.7901 18.32 19.4801 18 20.2701 18C21.2901 18 22.0901 18.39 22.4501 19.08C22.8101 19.77 22.7101 20.65 22.1401 21.5C21.4301 22.57 20.6601 22.79 20.1601 22.79ZM19.5601 20.49C19.7301 21.01 19.9701 21.27 20.1301 21.29C20.2901 21.31 20.5901 21.12 20.9001 20.67C21.1901 20.24 21.2101 19.93 21.1401 19.79C21.0701 19.65 20.7901 19.5 20.2701 19.5C19.9601 19.5 19.7301 19.6 19.6001 19.77C19.4801 19.94 19.4601 20.2 19.5601 20.49Z" fill="white" fill-opacity="0.6"/>
                           </svg>
                        </div>
                        <input type="text" id="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Search" required="">
                    </div>
                </form>
            </div>
               <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                  
                
               </div>
           </div>
           <div class="overflow-x-auto">
               <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                   <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                       <tr>
                           <th scope="col" class="px-4 py-4">#</th>
                           <th scope="col" class="px-4 py-4">name</th>
                           <th scope="col" class="px-4 py-4">Code</th>
                           <th scope="col" class="px-4 py-4">Action</th>
                       </tr>
                   </thead>
                   <tbody>

                    @foreach ($users as $index=>$country)
                    <tr class="border-b dark:border-gray-700">
                        <!-- <th scope="row" class="flex items-center px-4 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                           <img src="{{asset($country->image?$country->image:"Dashboard/image/logo.png")}}" alt="{{$country->username}} Front Image" class="w-auto h-11 mr-3 border-gray-300 rounded">
                       </th> -->
                       <td> {{++$index}}</td>
                            <td> {{$country->name}}</td>
                           <td class="px-4 py-3">{{$country->code}}</td>
                            <td class="flex">
                                <button style="width: 42px;height: 38px;" data-modal-target="popup-modal-edit" data-modal-toggle="popup-modal-edit"  data-id="{{$country->id}}" class="edit-country button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-full text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.53999 19.5196C4.92999 19.5196 4.35999 19.3096 3.94999 18.9196C3.42999 18.4296 3.17999 17.6896 3.26999 16.8896L3.63999 13.6496C3.70999 13.0396 4.07999 12.2296 4.50999 11.7896L12.72 3.09956C14.77 0.929561 16.91 0.869561 19.08 2.91956C21.25 4.96956 21.31 7.10956 19.26 9.27956L11.05 17.9696C10.63 18.4196 9.84999 18.8396 9.23999 18.9396L6.01999 19.4896C5.84999 19.4996 5.69999 19.5196 5.53999 19.5196ZM15.93 2.90956C15.16 2.90956 14.49 3.38956 13.81 4.10956L5.59999 12.8096C5.39999 13.0196 5.16999 13.5196 5.12999 13.8096L4.75999 17.0496C4.71999 17.3796 4.79999 17.6496 4.97999 17.8196C5.15999 17.9896 5.42999 18.0496 5.75999 17.9996L8.97999 17.4496C9.26999 17.3996 9.74999 17.1396 9.94999 16.9296L18.16 8.23956C19.4 6.91956 19.85 5.69956 18.04 3.99956C17.24 3.22956 16.55 2.90956 15.93 2.90956Z" fill="white" fill-opacity="0.87"/>
                                        <path d="M17.34 10.9508C17.32 10.9508 17.29 10.9508 17.27 10.9508C14.15 10.6408 11.64 8.27083 11.16 5.17083C11.1 4.76083 11.38 4.38083 11.79 4.31083C12.2 4.25083 12.58 4.53083 12.65 4.94083C13.03 7.36083 14.99 9.22083 17.43 9.46083C17.84 9.50083 18.14 9.87083 18.1 10.2808C18.05 10.6608 17.72 10.9508 17.34 10.9508Z" fill="white" fill-opacity="0.87"/>
                                        <path d="M21 22.75H3C2.59 22.75 2.25 22.41 2.25 22C2.25 21.59 2.59 21.25 3 21.25H21C21.41 21.25 21.75 21.59 21.75 22C21.75 22.41 21.41 22.75 21 22.75Z" fill="white" fill-opacity="0.87"/>
                                        </svg>
                                        
                                </button>

                                <button style="width: 42px;height: 38px;" data-id="{{$country->id}}" class="delete-country button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-full text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M17.5 4.98307C14.725 4.70807 11.9333 4.56641 9.15 4.56641C7.5 4.56641 5.85 4.64974 4.2 4.81641L2.5 4.98307" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M7.08337 4.14199L7.26671 3.05033C7.40004 2.25866 7.50004 1.66699 8.90837 1.66699H11.0917C12.5 1.66699 12.6084 2.29199 12.7334 3.05866L12.9167 4.14199" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M15.7083 7.61621L15.1666 16.0079C15.075 17.3162 15 18.3329 12.675 18.3329H7.32496C4.99996 18.3329 4.92496 17.3162 4.83329 16.0079L4.29163 7.61621" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M8.60828 13.75H11.3833" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        <path d="M7.91663 10.417H12.0833" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>
                                </button>
                                    
                            </td>
                        </tr>
                    @endforeach
                   </tbody>
               </table>
           </div>
           {{ $users->links('pagination::tailwind') }}
       </div>
   </div>
   </section>


   <div id="popup-modal" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <form action="#" method="post" id="create_country">
        @csrf
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-dark rounded-2xl shadow" style="background-color: #121212;    padding: 30px 20px 15px 20px;
        width: 45vw;">
            <p class="text-center text-white" style="    font-size: 25px;
            border-bottom: 1px solid #c7c3c3a6;
            line-height: 57px;
            font-weight: 700;">New Country</p>
            <div style=""
                    class="items-center  mt-8 font-medium text-gray-900 grid grid-cols-2 whitespace-nowrap dark:text-white">
               
                                <div class="flex flex-col mr-4">
                                    <label class="font-semibold leading-none text-gray-300">name Arabic</label>
                                    <input required type="text" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded sm:rounded-full" placeholder="arabic" value="" name="name[ar]"/>
                                </div>
                           
                                <div class=" flex flex-col">
                                    <label class="font-semibold leading-none text-gray-300">name English</label>
                                    <input required type="text" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="sm:rounded-full   leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded" placeholder="English" value="" name="name[en]" />
                                </div>
                </div>

                <div style=""
                class="items-center  mt-8 font-medium text-gray-900 grid grid-cols-2 whitespace-nowrap dark:text-white">
           
                            <div class="flex flex-col mr-4" style="display:none;">
                                <label for="imageUpload" id="imagePreview" style="background-size: cover;background-repeat: no-repeat;background-position: center;background-color:#1b1b1b;margin-top:0px!important;" class="flex flex-col mt-0 items-center justify-center w-full h-40 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                                    <div class="flex flex-col items-center justify-center pt-5 pb-6" id="image-preview">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9 10.75C7.48 10.75 6.25 9.52 6.25 8C6.25 6.48 7.48 5.25 9 5.25C10.52 5.25 11.75 6.48 11.75 8C11.75 9.52 10.52 10.75 9 10.75ZM9 6.75C8.31 6.75 7.75 7.31 7.75 8C7.75 8.69 8.31 9.25 9 9.25C9.69 9.25 10.25 8.69 10.25 8C10.25 7.31 9.69 6.75 9 6.75Z" fill="white" fill-opacity="0.6"/>
                                            <path d="M15 22.75H9C3.57 22.75 1.25 20.43 1.25 15V9C1.25 3.57 3.57 1.25 9 1.25H13C13.41 1.25 13.75 1.59 13.75 2C13.75 2.41 13.41 2.75 13 2.75H9C4.39 2.75 2.75 4.39 2.75 9V15C2.75 19.61 4.39 21.25 9 21.25H15C19.61 21.25 21.25 19.61 21.25 15V10C21.25 9.59 21.59 9.25 22 9.25C22.41 9.25 22.75 9.59 22.75 10V15C22.75 20.43 20.43 22.75 15 22.75Z" fill="white" fill-opacity="0.6"/>
                                            <path d="M18 8.75C17.9 8.75 17.81 8.73 17.71 8.69C17.43 8.58 17.25 8.3 17.25 8V2C17.25 1.59 17.59 1.25 18 1.25C18.41 1.25 18.75 1.59 18.75 2V6.19L19.47 5.47C19.76 5.18 20.24 5.18 20.53 5.47C20.82 5.76 20.82 6.24 20.53 6.53L18.53 8.53C18.39 8.67 18.2 8.75 18 8.75Z" fill="white" fill-opacity="0.6"/>
                                            <path d="M17.9999 8.74945C17.8099 8.74945 17.6199 8.67945 17.4699 8.52945L15.4699 6.52945C15.1799 6.23945 15.1799 5.75945 15.4699 5.46945C15.7599 5.17945 16.2399 5.17945 16.5299 5.46945L18.5299 7.46945C18.8199 7.75945 18.8199 8.23945 18.5299 8.52945C18.3799 8.67945 18.1899 8.74945 17.9999 8.74945Z" fill="white" fill-opacity="0.6"/>
                                            <path d="M2.66977 19.7005C2.42977 19.7005 2.18977 19.5805 2.04977 19.3705C1.81977 19.0305 1.90977 18.5605 2.25977 18.3305L7.18977 15.0205C8.26977 14.2905 9.75977 14.3805 10.7398 15.2105L11.0698 15.5005C11.5698 15.9305 12.4198 15.9305 12.9098 15.5005L17.0698 11.9305C18.1298 11.0205 19.7998 11.0205 20.8698 11.9305L22.4998 13.3305C22.8098 13.6005 22.8498 14.0705 22.5798 14.3905C22.3098 14.7005 21.8398 14.7405 21.5198 14.4705L19.8898 13.0705C19.3898 12.6405 18.5398 12.6405 18.0398 13.0705L13.8798 16.6405C12.8198 17.5505 11.1498 17.5505 10.0798 16.6405L9.74977 16.3505C9.28977 15.9605 8.52977 15.9205 8.01977 16.2705L3.08977 19.5805C2.95977 19.6605 2.80977 19.7005 2.66977 19.7005Z" fill="white" fill-opacity="0.6"/>
                                            </svg>
                                            
                                        <p class="mb-2 text-sm text-gray-500 dark:text-gray-400"><span class="font-semibold">upload Business logo</p>
                                        <p class="text-xs text-gray-500 dark:text-gray-400">SVG, PNG, JPG or GIF</p>
                                    </div>
                                    <input  type="file"   class="hidden" id="imageUpload" accept=".png, .jpg, .jpeg"/>
                                    <input type="hidden" id="imageSend" name="image" />
                                </label> 
                            </div>
                       
                            <div class=" flex flex-col">
                                <label class="font-semibold leading-none text-gray-300">Code</label>
                                <input required type="number" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="sm:rounded-full   leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded" placeholder="Code" value="" name="code" />
                            </div>
            </div>



            <div class="p-6 text-right">
                <button data-modal-hide="popup-modal" style="display:inline-flex!important" type="button" class=" mr-4 button-link-model text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" class="mr-2" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.0003 18.3327C14.5837 18.3327 18.3337 14.5827 18.3337 9.99935C18.3337 5.41602 14.5837 1.66602 10.0003 1.66602C5.41699 1.66602 1.66699 5.41602 1.66699 9.99935C1.66699 14.5827 5.41699 18.3327 10.0003 18.3327Z" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M7.6416 12.3592L12.3583 7.64258" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12.3583 12.3592L7.6416 7.64258" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        
                    cancel
                </button>
  
                <button type="submit" style="background: linear-gradient(93.55deg, #E50914 1.09%, #FF6666 99.2%)!important;" class="button-link-model text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 10H15" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10 15V5" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                        
                        
                    Create
                </button>
            </div>
        </div>
    </form>
    </div>



    <div id="popup-modal-edit" tabindex="-2" class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <form action="#" method="post" id="edit_country">
            @csrf
        <div class="relative w-full max-w-md max-h-full">
            <div class="relative bg-dark rounded-2xl shadow" style="background-color: #121212;    padding: 30px 20px 15px 20px;
            width: 45vw;">
                <p class="text-center text-white" style="    font-size: 25px;
                border-bottom: 1px solid #c7c3c3a6;
                line-height: 57px;
                font-weight: 700;">New Country</p>
               
    
                <div id="edit-body">

                </div>
    
                <div class="p-6 text-right">
                    <button data-modal-hide="popup-modal-edit" style="display:inline-flex!important" type="button" class=" mr-4 button-link-model text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" class="mr-2" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.0003 18.3327C14.5837 18.3327 18.3337 14.5827 18.3337 9.99935C18.3337 5.41602 14.5837 1.66602 10.0003 1.66602C5.41699 1.66602 1.66699 5.41602 1.66699 9.99935C1.66699 14.5827 5.41699 18.3327 10.0003 18.3327Z" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M7.6416 12.3592L12.3583 7.64258" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12.3583 12.3592L7.6416 7.64258" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            
                        cancel
                    </button>
      
                    <button type="submit" style="background: linear-gradient(93.55deg, #E50914 1.09%, #FF6666 99.2%)!important;" class="button-link-model text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5 10H15" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M10 15V5" stroke="white" stroke-opacity="0.87" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            
                            
                        Create
                    </button>
                </div>
            </div>
        </form>
        </div>
@endsection
@section("bottom-js")
   <script>
            $(document).on("click",".edit-country",function(){
                var id = $(this).attr("data-id");
                $.get({
                    url:"{{url('Dashboard/Country/show')}}"+"/"+id,
                    }).then(function(data){
                        $("#edit-body").append(`
                        <div style=""
                        class="items-center  mt-8 font-medium text-gray-900 grid grid-cols-2 whitespace-nowrap dark:text-white">
                   
                                    <div class="flex flex-col mr-4">
                                        <label class="font-semibold leading-none text-gray-300">name Arabic</label>
                                        <input required type="text" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded sm:rounded-full" placeholder="arabic" value="${data.name}" name="name[ar]"/>
                                    </div>
                               
                                    <div class=" flex flex-col">
                                        <label class="font-semibold leading-none text-gray-300">name English</label>
                                        <input required type="text" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="sm:rounded-full   leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded" placeholder="English" value="${data.name}" name="name[en]" />
                                    </div>
                    </div>
    
                    <div style=""
                    class="items-center  mt-8 font-medium text-gray-900 grid grid-cols-2 whitespace-nowrap dark:text-white">
               
                                <div class="flex flex-col mr-4">
                                    <label for="imageUpload" id="imagePreview" style="background-image:url({{asset('${data.image}')}});background-size: cover;background-repeat: no-repeat;background-position: center;background-color:#1b1b1b;margin-top:0px!important;" class="flex flex-col mt-0 items-center justify-center w-full h-40 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                                        <div class="flex flex-col items-center justify-center pt-5 pb-6" id="image-preview">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9 10.75C7.48 10.75 6.25 9.52 6.25 8C6.25 6.48 7.48 5.25 9 5.25C10.52 5.25 11.75 6.48 11.75 8C11.75 9.52 10.52 10.75 9 10.75ZM9 6.75C8.31 6.75 7.75 7.31 7.75 8C7.75 8.69 8.31 9.25 9 9.25C9.69 9.25 10.25 8.69 10.25 8C10.25 7.31 9.69 6.75 9 6.75Z" fill="white" fill-opacity="0.6"/>
                                                <path d="M15 22.75H9C3.57 22.75 1.25 20.43 1.25 15V9C1.25 3.57 3.57 1.25 9 1.25H13C13.41 1.25 13.75 1.59 13.75 2C13.75 2.41 13.41 2.75 13 2.75H9C4.39 2.75 2.75 4.39 2.75 9V15C2.75 19.61 4.39 21.25 9 21.25H15C19.61 21.25 21.25 19.61 21.25 15V10C21.25 9.59 21.59 9.25 22 9.25C22.41 9.25 22.75 9.59 22.75 10V15C22.75 20.43 20.43 22.75 15 22.75Z" fill="white" fill-opacity="0.6"/>
                                                <path d="M18 8.75C17.9 8.75 17.81 8.73 17.71 8.69C17.43 8.58 17.25 8.3 17.25 8V2C17.25 1.59 17.59 1.25 18 1.25C18.41 1.25 18.75 1.59 18.75 2V6.19L19.47 5.47C19.76 5.18 20.24 5.18 20.53 5.47C20.82 5.76 20.82 6.24 20.53 6.53L18.53 8.53C18.39 8.67 18.2 8.75 18 8.75Z" fill="white" fill-opacity="0.6"/>
                                                <path d="M17.9999 8.74945C17.8099 8.74945 17.6199 8.67945 17.4699 8.52945L15.4699 6.52945C15.1799 6.23945 15.1799 5.75945 15.4699 5.46945C15.7599 5.17945 16.2399 5.17945 16.5299 5.46945L18.5299 7.46945C18.8199 7.75945 18.8199 8.23945 18.5299 8.52945C18.3799 8.67945 18.1899 8.74945 17.9999 8.74945Z" fill="white" fill-opacity="0.6"/>
                                                <path d="M2.66977 19.7005C2.42977 19.7005 2.18977 19.5805 2.04977 19.3705C1.81977 19.0305 1.90977 18.5605 2.25977 18.3305L7.18977 15.0205C8.26977 14.2905 9.75977 14.3805 10.7398 15.2105L11.0698 15.5005C11.5698 15.9305 12.4198 15.9305 12.9098 15.5005L17.0698 11.9305C18.1298 11.0205 19.7998 11.0205 20.8698 11.9305L22.4998 13.3305C22.8098 13.6005 22.8498 14.0705 22.5798 14.3905C22.3098 14.7005 21.8398 14.7405 21.5198 14.4705L19.8898 13.0705C19.3898 12.6405 18.5398 12.6405 18.0398 13.0705L13.8798 16.6405C12.8198 17.5505 11.1498 17.5505 10.0798 16.6405L9.74977 16.3505C9.28977 15.9605 8.52977 15.9205 8.01977 16.2705L3.08977 19.5805C2.95977 19.6605 2.80977 19.7005 2.66977 19.7005Z" fill="white" fill-opacity="0.6"/>
                                                </svg>
                                                
                                            <p class="mb-2 text-sm text-gray-500 dark:text-gray-400"><span class="font-semibold">upload Business logo</p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400">SVG, PNG, JPG or GIF</p>
                                        </div>
                                        <input  type="file"   class="hidden" id="imageUpload" accept=".png, .jpg, .jpeg"/>
                                        <input type="hidden" id="imageSend" name="image" />
                                    </label> 
                                </div>
                           
                                <div class=" flex flex-col">
                                    <label class="font-semibold leading-none text-gray-300">Code</label>
                                    <input required type="number" style="height: 37px;background-color: rgba(255, 255, 255, 0.05);" class="sm:rounded-full   leading-none text-gray-50 p-3 focus:outline-none focus:border-blue-700 mt-4 border-0 bg-gray-800 rounded" placeholder="Code" value="${data.code}" name="code" />
                                </div>
                </div>
                        `);
                    
                    }).catch(function(error){
                        if(error.status == 422){
                            Swal.fire('Changes are not amr', '', 'error')
                        }else{
                            Swal.fire('Changes are not done', '', 'error');
                        }
                        
                    });
                        
            });
                    $(document).on("click","#imagePreview",function(){
                        let browseFile = $('#imageUpload'); 
                        let resumable = new Resumable({
                        target:  "{{ url('/') }}" + "/Dashboard/Country/upload/image",
                        query:{_token:'{{ csrf_token() }}'},
                        fileType: ["jpg","png","jpeg"],
                        headers: {
                            'Accept' : 'application/json'
                        },
                        testChunks: false,
                        throttleProgressCallbacks: 1,
                    });

                    resumable.assignBrowse(browseFile[0])
                    resumable.on('fileAdded', function (file) { 
                        resumable.upload() 
                    });
                    resumable.on('fileSuccess', function (file, response) {
                       $("#imageSend").attr("value",JSON.parse(response).image);
                    }); 
        });
$(document).on("submit","#create_country",function(event){
            event.preventDefault();
            var form = $(this).serializeArray();
            $.post({
                url:"{{route('dashboard.country.store')}}",
                data:form,
            }).then(function(data){
                console.log(data);
                Swal.fire('Saved!', '', 'success');
                setInterval(function(){ 
                    location.reload();      
                }, 3000);
            }).catch(function(error){
                if(error.status == 422){
                    Swal.fire('Changes are not amr', '', 'error')
                }else{
                    Swal.fire('Changes are not done', '', 'error');
                }
                
            });
        });



        $(document).on("click",".delete-country",function(){
            Swal.fire({
              imageUrl: '{{asset('Dashboard/image/warning-2.png')}}',
              imageAlt: 'A tall image',
              text: 'Are you sure you want delete this Country ?',
              title: 'Delete Country',
                showDenyButton: false,
                showCancelButton: true,
                confirmButtonText: 'Delete',
              }).then((result) => {
                if (result.isConfirmed) {
                  $.post({
                    url:"{{route('dashboard.country.delete')}}",
                    "data":{
                      id:$(this).attr("data-id"),
                      "_token":$('meta[name="csrf-token"]').attr('content')
                    }
                  }).then((data)=>{
                    Swal.fire('Saved!', '', 'success');
                    const myTimeout = setTimeout(function(){
                  
                      location.reload();
                    }, 3000);
                    
                  }).catch((error)=>{
                    if(error.status == 422){
                      Swal.fire('Changes are not done', '', 'error')    
                    }
                  });
                } else if (result.isDenied) {
                  Swal.fire('Changes are not done', '', 'info')
                }
              })
          });
   </script>
@endsection
