@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">Client List</h1>
         <div>
            <span style="color: #525252;">Dashboard</span>
         <span style="color: #525252;"> > </span>
         <span style="color: #525252;">App</span>
         <span style="color: #dcd8d8;"> > </span>
         <span style="color: #dcd8d8;">Countries</span>
         </div>
      </div>
      <div class="flex Client-Head">
         <a type="button" href="{{route('dashboard.User.create')}}" class="button-link flex items-center justify-center text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-primary-600 dark:hover:bg-primary-700 focus:outline-none dark:focus:ring-primary-800">
            <svg class="h-3.5 w-3.5 mr-2" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path clip-rule="evenodd" fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" />
            </svg>
            Add Country
        </a>
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       <div class="border dark:border-gray-800 relative shadow-md sm:rounded-lg overflow-hidden">
           <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
            <div class="w-50 md:w-1/2">
                <form class="flex items-center">
                    <label for="simple-search" class="sr-only">Search</label>
                    <div class="relative w-full">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M11 20.75C5.62 20.75 1.25 16.38 1.25 11C1.25 5.62 5.62 1.25 11 1.25C16.38 1.25 20.75 5.62 20.75 11C20.75 16.38 16.38 20.75 11 20.75ZM11 2.75C6.45 2.75 2.75 6.45 2.75 11C2.75 15.55 6.45 19.25 11 19.25C15.55 19.25 19.25 15.55 19.25 11C19.25 6.45 15.55 2.75 11 2.75Z" fill="white" fill-opacity="0.6"/>
                              <path d="M20.1601 22.79C20.0801 22.79 20.0001 22.78 19.9301 22.77C19.4601 22.71 18.6101 22.39 18.1301 20.96C17.8801 20.21 17.9701 19.46 18.3801 18.89C18.7901 18.32 19.4801 18 20.2701 18C21.2901 18 22.0901 18.39 22.4501 19.08C22.8101 19.77 22.7101 20.65 22.1401 21.5C21.4301 22.57 20.6601 22.79 20.1601 22.79ZM19.5601 20.49C19.7301 21.01 19.9701 21.27 20.1301 21.29C20.2901 21.31 20.5901 21.12 20.9001 20.67C21.1901 20.24 21.2101 19.93 21.1401 19.79C21.0701 19.65 20.7901 19.5 20.2701 19.5C19.9601 19.5 19.7301 19.6 19.6001 19.77C19.4801 19.94 19.4601 20.2 19.5601 20.49Z" fill="white" fill-opacity="0.6"/>
                           </svg>
                        </div>
                        <input type="text" id="simple-search" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Search" required="">
                    </div>
                </form>
            </div>
               <div class="w-full md:w-auto flex flex-col md:flex-row space-y-2 md:space-y-0 items-stretch md:items-center justify-end md:space-x-3 flex-shrink-0">
                  
                   <div class="flex items-center space-x-3 w-full md:w-auto">
                       <button id="actionsDropdownButton" data-dropdown-toggle="actionsDropdown" class="w-full md:w-auto flex items-center justify-center py-2 px-4 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700" type="button">
                           <svg class="-ml-1 mr-1.5 w-5 h-5" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                               <path clip-rule="evenodd" fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                           </svg>
                           Actions
                       </button>
                       <div id="actionsDropdown" class="hidden z-10 w-44 bg-white rounded divide-y divide-gray-100 shadow dark:bg-gray-700 dark:divide-gray-600">
                           <ul class="py-1 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="actionsDropdownButton">
                               <li>
                                   <a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Mass Edit</a>
                               </li>
                           </ul>
                           <div class="py-1">
                               <a href="#" class="block py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Delete all</a>
                           </div>
                       </div>
                       
                   </div>
               </div>
           </div>
           <div class="overflow-x-auto">
               <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                   <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                       <tr>
                           <th scope="col" class="px-4 py-4">Icone</th>
                           <th scope="col" class="px-4 py-4">ar</th>
                           <th scope="col" class="px-4 py-4">en</th>
                           <th scope="col" class="px-4 py-4">Code</th>
                           <th scope="col" class="px-4 py-4">Action</th>
                          
                       </tr>
                   </thead>
                   <tbody>

                    @foreach ($countries as $country)
                    <tr class="border-b dark:border-gray-700">
                        <th scope="row" class="flex items-center px-4 py-2 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                           <img src="{{asset($user->image?$user->image:"Dashboard/image/logo.png")}}" alt="{{$user->username}} Front Image" class="w-auto h-11 mr-3 border-gray-300 rounded">
                          <a href="{{route('dashboard.client.show',$user->id)}}">
                           <p>
                           {{$user->business->name}}
                           <br />
                           <span style="color: #717171;font-size: 12px;">#{{$user->business->org_no}}</span>
                          </p>
                        </a>
                       </th>
                        <td class="px-4 py-3">
                            @if ($user->status == "1")
                                <button class="btn-status success" style="background:rgba(63, 174, 0, 1)!important;">Active</button>
                            @elseif ($user->status == "2")
                                <button class="btn-status stop" style="background:rgba(128, 128, 129, 1)!important;">stoped</button>
                            @else
                                <button class="btn-status refuased" style="background:rgba(246, 65, 65, 1)!important;">Refused</button>
                            @endif
                        </td>
                           <td class="px-4 py-3">{{$user->address?$user->address[0]->street_name:""}}</td>
                           <td class="px-4 py-3">{{$user->phone}}</td>
                           <td class="px-4 py-3">{{date('Y-m-d',strtotime($user->created_at))}}</td>
                       </tr>
                    @endforeach
                   </tbody>
               </table>
           </div>
           {{ $users->links('pagination::tailwind') }}
       </div>
   </div>
   </section>
@endsection