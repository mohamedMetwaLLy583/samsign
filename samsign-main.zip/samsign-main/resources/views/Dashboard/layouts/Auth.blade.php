<!DOCTYPE html>
<html lang="en" class="h-full dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/styles/metro/notify-metro.min.css" />
    <link rel="stylesheet" href="{{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.css')}}"  />
    <link rel="stylesheet" href="{{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.css')}}"  />
    <script src="{{asset('Dashboard/vendor/js/cdn.tailwindcss.com_3.3.3')}}"></script>
    <title>SAMSIGN-LOGIN</title>
    <script>
        tailwind.config = {
          theme: {
            container: {
                center: true,
                padding: {
                    DEFAULT: '1rem',
                    sm: '2rem',
                    lg: '4rem',
                    xl: '5rem',
                    '2xl': '6rem',
                },
                },
            plugins:[
                
            ],
            extend: {
              colors: {
                clifford: '#da373d',
              }
            }
          }
        }
      </script>
    <style type="text/tailwindcss">
        @layer utilities {
          .content-auto {
            content-visibility: auto;
          }
          .form-content form label {
            color:#fff!important;
          }

          .form-content form a{
            color: #FF4D4D!important;
          }
          .form-content{
            display: inline-flex;
            padding: 50px 40px 50px 40px;
            flex-direction: column;
            align-items: center;
            border-radius: 20px;
            background: var(--glass-1-fill-carey, linear-gradient(294deg, rgba(191, 191, 191, 0.06) 0%, rgba(0, 0, 0, 0.00) 100%), rgba(0, 0, 0, 0.14));
            box-shadow: -8px 4px 5px 0px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(26.5px);
            border: 1px solid #FFF;
          }

          .form-content form input{
            display: flex;
            width: 300px;
            height: 40px;
            padding: 14px 16px;
            align-items: center;
            gap: 10px;
            border-radius: 12px;
            border: 1px solid #FFF;
            border-radius: 20px;
            background: var(--glass-1-fill-carey, linear-gradient(294deg, rgba(191, 191, 191, 0.06) 0%, rgba(0, 0, 0, 0.00) 100%), rgba(0, 0, 0, 0.14));
            box-shadow: -8px 4px 5px 0px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(26.5px);
        }
        .form-content form input[type='checkbox']{
            height: 15px!important;
            width:  15px!important;
            margin-right:10px;
            border: 1px solid #FFF;
            border-radius: 20px;
            
            background-color: #E50914!important;
            box-shadow: -8px 4px 5px 0px rgba(0, 0, 0, 0.24);
            backdrop-filter: blur(26.5px);
        }
        .form-content form input{
            color:#fff!important;
        }
          .form-content form input,.form-content form button{
            display: flex;
            width: 300px;
            padding: 14px 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
          }
          .form-content form button{
            border-radius: 12px;
            background: linear-gradient(119deg, #E50914 0%, #FF4D4D 53.13%, #F66 100%);
          }
          .fi-circle{
            -webkit-transform-origin-y: top;
            position: absolute;
            width: 221px;
            height: 221px;
            transform: rotate(-28.5deg);
            flex-shrink: 0;
          }
          h1,h3{
            color: #FFF;
        font-family: Inter;
        font-size: 36px;
        font-style: normal;
        font-weight: 700;
        line-height: 120%;
          }
          h1{
            font-size: 53px;
          }

          input:focus {
    outline:0 none!important;
    border: transparent!important;

}
        }
        
        .swal2-popup{
  background-color: #121212;
    padding: 30px;
    width: 36vw;
    color:#fff!important;
}
.swal2-title{
  font-size: 1.125rem;
    line-height: 1.75rem;

}
      </style>
</head>
<body class="h-full bg-white dark:bg-black" style="overflow: hidden;background-color:#000!important">
    @yield("main-content")
    <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery_3.7.0_jquery.min.js')}}" ></script>
    <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.js')}}" ></script>
        <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.min.js')}}" ></script>

    <script>
              
        $(document).on("submit","#form-login",async function(e){
            e.preventDefault();
            var username = $("#username").val();
            var password = $("#password").val();
            var remmber = $("#remmber").val();
            await $.post({
                "url":"{{route('dashboard.auth.login')}}",
                "data":{
                    "username":username,
                    "password":password,
                    "remmber":remmber,
                    "_token":$('meta[name="csrf-token"]').attr('content')
                },
            }).then(function(data){
                console.log(data);
                if(data.status == 200 && data.message=="success"){
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: "Welcom "+data.data.name+" you can access panal now.",
                        showConfirmButton: false,
                        timer: 2500
                    });
                    setInterval(function(){ location.reload(); }, 3000);
                }
                console.log("data => "+data);
            }).catch(function(error){
                if(error.status == 422){
                    $("#errorText").text(error.responseJSON.message);
                    // $.toast({ 
                    //     text : error.responseJSON.message, 
                    //     showHideTransition : 'slide',  // It can be plain, fade or slide
                    //     bgColor : '#E50914',              // Background color for toast
                    //     textColor : '#fff',            // text color
                    //     allowToastClose : false,       // Show the close button or not
                    //     hideAfter : 5000,              // `false` to make it sticky or time in miliseconds to hide after
                    //     stack : 5,                     // `fakse` to show one stack at a time count showing the number of toasts that can be shown at once
                    //     textAlign : 'left',            // Alignment of text i.e. left, right, center
                    //     position : 'top-left'       // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values to position the toast on page
                    //     })
                }
            });
        });
    </script>
</body>
</html>