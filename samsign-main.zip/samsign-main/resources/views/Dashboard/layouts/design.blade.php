<!DOCTYPE html>
<html lang="en">

<head>
 @foreach(fontfamily() as $value)
      <style>
        @font-face {
            font-family: '{{$value->name}}';
            src: url('{{asset($value->file)}}');
        }
    </style>
    @endforeach 
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="icon" href=" {{asset('Dashboard/image/logo.png')}} " />
    <link rel="stylesheet"
        href="  {{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.css')}} " />
    <link rel="stylesheet" href="  {{asset('Dashboard/css/editor.css')}} " />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet"
        href="  {{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.css')}} " />
    <script src=" {{asset('Dashboard/vendor/js/cdn.tailwindcss.com_3.3.3')}} "></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
        integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="  {{asset('Dashboard/css/main.css')}}" />
    <link rel="stylesheet" href="  {{asset('Dashboard/css/editor.css')}}" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <script>
        tailwind.config = {
            theme: {
                container: {
                    center: true,
                    padding: {
                        DEFAULT: '1rem',
                        sm: '2rem',
                        lg: '4rem',
                        xl: '5rem',
                        '2xl': '6rem',
                    },
                },
                plugins: [


                ],
                extend: {
                    colors: {
                        primary: { "50": "#eff6ff", "100": "#dbeafe", "200": "#bfdbfe", "300": "#93c5fd", "400": "#60a5fa", "500": "#3b82f6", "600": "#2563eb", "700": "#1d4ed8", "800": "#1e40af", "900": "#1e3a8a", "950": "#172554" }
                    }
                },
                fontFamily: {
                    'body': [
                        'Inter',
                        'ui-sans-serif',
                        'system-ui',
                        '-apple-system',
                        'system-ui',
                        'Segoe UI',
                        'Roboto',
                        'Helvetica Neue',
                        'Arial',
                        'Noto Sans',
                        'sans-serif',
                        'Apple Color Emoji',
                        'Segoe UI Emoji',
                        'Segoe UI Symbol',
                        'Noto Color Emoji'
                    ],
                    'sans': [
                        'Inter',
                        'ui-sans-serif',
                        'system-ui',
                        '-apple-system',
                        'system-ui',
                        'Segoe UI',
                        'Roboto',
                        'Helvetica Neue',
                        'Arial',
                        'Noto Sans',
                        'sans-serif',
                        'Apple Color Emoji',
                        'Segoe UI Emoji',
                        'Segoe UI Symbol',
                        'Noto Color Emoji'
                    ]
                }
            }
        }
    </script>
        <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery_3.7.0_jquery.min.js')}}"></script>
        <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.min.js')}}"></script>
        <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.js')}}"></script>
        <script src="{{asset('Dashboard/vendor/js/flowbite.js')}}"></script>

        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script> -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/resumable.js/1.0.3/resumable.min.js"
            integrity="sha512-OmtdY/NUD+0FF4ebU+B5sszC7gAomj26TfyUUq6191kbbtBZx0RJNqcpGg5mouTvUh7NI0cbU9PStfRl8uE/rw=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src=" {{asset('Dashboard/vendor/js/code.jquery.com.js')}}"></script>


        <script src="https://unpkg.com/konva@9/konva.min.js"></script>
      
    <title>SAMSIGN</title>
    @vite(["resources/js/app.js"])
</head>
<body class="h-full bg-black  dark:bg-black">
 <div class="grid md:grid-cols-3 gap-4 grid-flow-col auto-cols-max"> 
 <div class="pt-0  col-end-1 col-start-11 col-span-2">

     
    <div class="" id="app">
   
        @yield("main-content")
    
  </div>
</div>
</div>
    @yield("bottom-js")
</body>
</html>