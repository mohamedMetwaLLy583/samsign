<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <link rel="icon" href="{{asset('Dashboard/image/logo.png')}}">

    <link rel="stylesheet" href="{{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.css')}}"  crossorigin="anonymous" referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="{{asset('Dashboard/vendor/css/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.css')}}"  crossorigin="anonymous" referrerpolicy="no-referrer" />


    <script src="{{asset('Dashboard/vendor/js/cdn.tailwindcss.com_3.3.3')}}"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <script>

      tailwind.config = {

    theme: {

      container: {

          center: true,

          padding: {

              DEFAULT: '1rem',

              sm: '2rem',

              lg: '4rem',

              xl: '5rem',

              '2xl': '6rem',

          },

          },

      plugins:[

        // require('tailwindcss-plugins/pagination'),

      ],

      extend: {

        colors: {

  primary: {"50":"#eff6ff","100":"#dbeafe","200":"#bfdbfe","300":"#93c5fd","400":"#60a5fa","500":"#3b82f6","600":"#2563eb","700":"#1d4ed8","800":"#1e40af","900":"#1e3a8a","950":"#172554"}

}

},

fontFamily: {

'body': [

'Inter', 

'ui-sans-serif', 

'system-ui', 

'-apple-system', 

'system-ui', 

'Segoe UI', 

'Roboto', 

'Helvetica Neue', 

'Arial', 

'Noto Sans', 

'sans-serif', 

'Apple Color Emoji', 

'Segoe UI Emoji', 

'Segoe UI Symbol', 

'Noto Color Emoji'

],

'sans': [

'Inter', 

'ui-sans-serif', 

'system-ui', 

'-apple-system', 

'system-ui', 

'Segoe UI', 

'Roboto', 

'Helvetica Neue', 

'Arial', 

'Noto Sans', 

'sans-serif', 

'Apple Color Emoji', 

'Segoe UI Emoji', 

'Segoe UI Symbol', 

'Noto Color Emoji'

]

}

      }

    }

  

    </script>

      <style type="text/tailwindcss">

        @layer utilities {

          *{

       

       font-style: normal;

       font-weight: 400;

       font-size: 14px;

   }

          nav{

            background-color: #000!important;

            border-bottom-right-radius:27px!important;

            border-bottom-left-radius:27px!important;

          }

          nav div{

            background-color: #121212!important;

            border-bottom-right-radius:27px!important;

            border-bottom-left-radius:27px!important;

          }

         

          thead ,#simple-search ,button ,section nav ul li a{

                --tw-bg-opacity: 1!important;

                /* background-color: #181818a3!important; */

                background: rgba(255, 255, 255, 0.07)!important;

            }

            .Client-Head{

              justify-content: end!important;



            }

            

             .button-link{

              margin-right:10px;

              width: 180px;

              height: 48px;

              border-radius: 8px;

            }

             .button-link:nth-child(2){

              background: linear-gradient(93.55deg, #E50914 1.09%, #FF6666 99.2%)!important; 

            }

           .button-link:nth-child(1){

              background-color:#000!important;

              border:1px solid #fff!important; 

            }

            .title-page{



font-style: normal;

font-weight: 700;

font-size: 14px;

line-height: 20px;

/* identical to box height, or 143% */

letter-spacing: 0.005em;



/* White/60 */

color: rgba(255, 255, 255, 0.6);



/* White/87% */

color: rgba(255, 255, 255, 0.87);

            }

            input[type=number]::-webkit-inner-spin-button, 

input[type=number]::-webkit-outer-spin-button { 

  -webkit-appearance: none;

}







            .btn-status{

              /* Label */

            justify-content: center;

            align-items: center;

            padding: 4px 24px;



            width: 104px;

            height: 32px;

            color: rgba(255, 255, 255, 0.87);

            /* Status/Active */

            background: #3FAE00;

            border-radius: 8px;

            }



            .active{

              background:rgba(63, 174, 0, 1)!important;

            }

            .stop{

              background:rgba(128, 128, 129, 1)!important;

            }



            .refuased{

              background:rgba(246, 65, 65, 1)!important;

            }

          aside{

            

            background-color: #121212!important;

            border-top-right-radius:27px!important;

            border-bottom-right-radius:27px!important;

          }



          aside div{

            border-top-right-radius:27px!important;

            border-bottom-right-radius:27px!important;

            background-color: #121212!important;

          } 

        }



        input[type="radio"]:checked+label{ 

          border-color:rgba(243, 142, 147, 1)!important;

          color:#727272!important;

         } 





        .search{

          flex-direction: column;

          justify-content: center;

          align-items: flex-start;

          padding: 10px 29px;

          margin: 0 auto;

          

          border-radius: 12px;

          display: flex;

          flex-direction: row;

          align-items: center;

         

          gap: 8px;

          width: 500px;

          height: 40px;

          font-family: 'Inter';

          font-style: normal;

          font-weight: 400;

          font-size: 14px;

          line-height: 120%;

          text-align: right;

          flex: none;

          order: 1;

          flex-grow: 0;



          

        }

        .search::placeholder{

          /* Search in dashboard */

            width: 50px;

            height: 17px;

            /* identical to box height, or 17px */

            text-align: right;

            /* Text/38% */

            color: rgba(255, 255, 255, 0.38);

            /* Inside auto layout */

            flex: none;

            order: 1;

            flex-grow: 0;



        }

        *{

          

          font-style: normal;

        }

        .main{

          /* Main */

        width: 190px;

        height: 24px;



        font-family: 'Inter';

        font-style: normal;

        font-weight: 500;

        font-size: 11px;

        line-height: 24px;

        /* identical to box height, or 218% */

        display: flex;

        align-items: center;

        letter-spacing: 0.4px;

        text-transform: uppercase;



        color: rgba(255, 255, 255, 0.32);





        /* Inside auto layout */

        flex: none;

        order: 0;

        flex-grow: 1;



        }



        .confirm-button-class {

  background-color: red !important;

  color: white !important;

  border: none !important;

}



.title-class {

  font-size: 15px !important;

}





.icon-class {

  font-size: 10px !important;

}

.swal2-popup{

  background-color: #121212;

    padding: 30px;

    width: 36vw;

    color:#fff!important;

}

.swal2-title{

  font-size: 1.125rem;

    line-height: 1.75rem;



}
input{
            background-color: #232323!important;
            color:#fff!important;
        }
        .status-account{
            background-color: #232323!important;
            border-color:#232323!important;
            color:#fff!important;
        }

.confirm-button-class .swal2-icon svg {

  width: 12px !important;

  height: 12px !important;

}



.swal2-actions .swal2-confirm {

  background: linear-gradient(93.55deg, #E50914 1.09%, #FF6666 99.2%)!important;

  color: white !important;

  border: none !important;

  box-shadow: none !important;

  border-radius: 0.5rem;

  width: 8vw!important;

    text-align: center;

}



.swal2-actions .swal2-cancel {

  border-color: #000 !important;

  box-shadow: none !important;

  border: 0.5px solid !important;

  border-color:rgb(107 114 128 / var(--tw-border-opacity)) !important;

  opacity: 1;

  color:#fff;

  border-radius: 0.5rem;

  width: 8vw!important;

    text-align: center;

}



.swal2-confirm:focus, .swal2-cancel:focus {

  box-shadow: none !important;

}



.swal2-actions button:hover {

 

}





button{

    

    color:white!important;

}

thead tr th, thead tr td{

    color:#fff!important;

}

     .search_text{

         color:#fff!important;

     }   

     

     

     .hover\:bg-gray-100:hover{

         color:#000!important;

     }

        </style>

    <title>SAMSIGN-@yield("title","Dashboard")</title>
    @vite(["resources/js/app.js"])

</head>

<body class="h-full bg-black  dark:bg-black">

  



 <div class="grid md:grid-cols-3 gap-4 grid-flow-col auto-cols-max">

    <div>

      <aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">

    <div class="h-full px-3 py-4 overflow-y-auto bg-gray-50 dark:bg-gray-800">

       <a href="{{route('dashboard.client.index')}}" class="flex items-center pl-2.5" style="margin-top:-39px;">

          <img src="{{asset('Dashboard/image/logo.png')}}" class="h-100" alt="Flowbite Logo" />

       </a>





       <ul class="space-y-2 font-medium" style="margin-top:-30px;">

           <p class="text-white main">main</p>

          <li>

             <a href="{{route('dashboard.client.index')}}" class="flex items-center p-2 text-gray-900 rounded-lg text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">

              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

                <path d="M17.9998 7.90977C17.9698 7.90977 17.9498 7.90977 17.9198 7.90977H17.8698C15.9798 7.84977 14.5698 6.38977 14.5698 4.58977C14.5698 2.74977 16.0698 1.25977 17.8998 1.25977C19.7298 1.25977 21.2298 2.75977 21.2298 4.58977C21.2198 6.39977 19.8098 7.85977 18.0098 7.91977C18.0098 7.90977 18.0098 7.90977 17.9998 7.90977ZM17.8998 2.74977C16.8898 2.74977 16.0698 3.56977 16.0698 4.57977C16.0698 5.56977 16.8398 6.36977 17.8298 6.40977C17.8398 6.39977 17.9198 6.39977 18.0098 6.40977C18.9798 6.35977 19.7298 5.55977 19.7398 4.57977C19.7398 3.56977 18.9198 2.74977 17.8998 2.74977Z" fill="white" fill-opacity="0.87"/>

                <path d="M18.01 15.2806C17.62 15.2806 17.23 15.2506 16.84 15.1806C16.43 15.1106 16.16 14.7206 16.23 14.3106C16.3 13.9006 16.69 13.6306 17.1 13.7006C18.33 13.9106 19.63 13.6806 20.5 13.1006C20.97 12.7906 21.22 12.4006 21.22 12.0106C21.22 11.6206 20.96 11.2406 20.5 10.9306C19.63 10.3506 18.31 10.1206 17.07 10.3406C16.66 10.4206 16.27 10.1406 16.2 9.73063C16.13 9.32063 16.4 8.93064 16.81 8.86064C18.44 8.57064 20.13 8.88063 21.33 9.68063C22.21 10.2706 22.72 11.1106 22.72 12.0106C22.72 12.9006 22.22 13.7506 21.33 14.3506C20.42 14.9506 19.24 15.2806 18.01 15.2806Z" fill="white" fill-opacity="0.87"/>

                <path d="M5.96998 7.91C5.95998 7.91 5.94998 7.91 5.94998 7.91C4.14998 7.85 2.73998 6.39 2.72998 4.59C2.72998 2.75 4.22998 1.25 6.05998 1.25C7.88998 1.25 9.38998 2.75 9.38998 4.58C9.38998 6.39 7.97998 7.85 6.17998 7.91L5.96998 7.16L6.03998 7.91C6.01998 7.91 5.98998 7.91 5.96998 7.91ZM6.06998 6.41C6.12998 6.41 6.17998 6.41 6.23998 6.42C7.12998 6.38 7.90998 5.58 7.90998 4.59C7.90998 3.58 7.08998 2.75999 6.07998 2.75999C5.06998 2.75999 4.24998 3.58 4.24998 4.59C4.24998 5.57 5.00998 6.36 5.97998 6.42C5.98998 6.41 6.02998 6.41 6.06998 6.41Z" fill="white" fill-opacity="0.87"/>

                <path d="M5.96 15.2806C4.73 15.2806 3.55 14.9506 2.64 14.3506C1.76 13.7606 1.25 12.9106 1.25 12.0106C1.25 11.1206 1.76 10.2706 2.64 9.68063C3.84 8.88063 5.53 8.57064 7.16 8.86064C7.57 8.93064 7.84 9.32063 7.77 9.73063C7.7 10.1406 7.31 10.4206 6.9 10.3406C5.66 10.1206 4.35 10.3506 3.47 10.9306C3 11.2406 2.75 11.6206 2.75 12.0106C2.75 12.4006 3.01 12.7906 3.47 13.1006C4.34 13.6806 5.64 13.9106 6.87 13.7006C7.28 13.6306 7.67 13.9106 7.74 14.3106C7.81 14.7206 7.54 15.1106 7.13 15.1806C6.74 15.2506 6.35 15.2806 5.96 15.2806Z" fill="white" fill-opacity="0.87"/>

                <path d="M11.9998 15.3805C11.9698 15.3805 11.9498 15.3805 11.9198 15.3805H11.8698C9.97982 15.3205 8.56982 13.8605 8.56982 12.0605C8.56982 10.2205 10.0698 8.73047 11.8998 8.73047C13.7298 8.73047 15.2298 10.2305 15.2298 12.0605C15.2198 13.8705 13.8098 15.3305 12.0098 15.3905C12.0098 15.3805 12.0098 15.3805 11.9998 15.3805ZM11.8998 10.2205C10.8898 10.2205 10.0698 11.0405 10.0698 12.0505C10.0698 13.0405 10.8398 13.8405 11.8298 13.8805C11.8398 13.8705 11.9198 13.8705 12.0098 13.8805C12.9798 13.8305 13.7298 13.0305 13.7398 12.0505C13.7398 11.0505 12.9198 10.2205 11.8998 10.2205Z" fill="white" fill-opacity="0.87"/>

                <path d="M11.9998 22.7607C10.7998 22.7607 9.59978 22.4507 8.66978 21.8207C7.78978 21.2307 7.27979 20.3907 7.27979 19.4907C7.27979 18.6007 7.77978 17.7407 8.66978 17.1507C10.5398 15.9107 13.4698 15.9107 15.3298 17.1507C16.2098 17.7407 16.7198 18.5807 16.7198 19.4807C16.7198 20.3707 16.2198 21.2307 15.3298 21.8207C14.3998 22.4407 13.1998 22.7607 11.9998 22.7607ZM9.49979 18.4107C9.02979 18.7207 8.77979 19.1107 8.77979 19.5007C8.77979 19.8907 9.03979 20.2707 9.49979 20.5807C10.8498 21.4907 13.1398 21.4907 14.4898 20.5807C14.9598 20.2707 15.2098 19.8807 15.2098 19.4907C15.2098 19.1007 14.9498 18.7207 14.4898 18.4107C13.1498 17.5007 10.8598 17.5107 9.49979 18.4107Z" fill="white" fill-opacity="0.87"/>

                </svg>

                

                <span class="ml-3">Clients</span>

             </a>

          </li>

          <li>

             <a href="{{route('dashboard.template.index')}}" class="flex items-center p-2 text-gray-900 rounded-lg text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">

              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

                <path d="M15 22.75H9C3.57 22.75 1.25 20.43 1.25 15V9C1.25 3.57 3.57 1.25 9 1.25H15C20.43 1.25 22.75 3.57 22.75 9V15C22.75 20.43 20.43 22.75 15 22.75ZM9 2.75C4.39 2.75 2.75 4.39 2.75 9V15C2.75 19.61 4.39 21.25 9 21.25H15C19.61 21.25 21.25 19.61 21.25 15V9C21.25 4.39 19.61 2.75 15 2.75H9Z" fill="white" fill-opacity="0.87"/>

                <path d="M10 22.75C9.59 22.75 9.25 22.41 9.25 22V2C9.25 1.59 9.59 1.25 10 1.25C10.41 1.25 10.75 1.59 10.75 2V22C10.75 22.41 10.41 22.75 10 22.75Z" fill="white" fill-opacity="0.87"/>

                <path d="M22 12.75H10C9.59 12.75 9.25 12.41 9.25 12C9.25 11.59 9.59 11.25 10 11.25H22C22.41 11.25 22.75 11.59 22.75 12C22.75 12.41 22.41 12.75 22 12.75Z" fill="white" fill-opacity="0.87"/>

                </svg>

                

                <span class="flex-1 ml-3 whitespace-nowrap">Templetes</span>

             </a>

          </li>

          

          

      <li style="position: absolute;top:78%;    width: 90%;">

           <a href="{{route('dashboard.setting.index')}}" class="flex items-center p-2 text-gray-900 rounded-lg text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">

              <svg class="flex-shrink-0 w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">

                 <path d="M5 5V.13a2.96 2.96 0 0 0-1.293.749L.879 3.707A2.96 2.96 0 0 0 .13 5H5Z"/>

                 <path d="M6.737 11.061a2.961 2.961 0 0 1 .81-1.515l6.117-6.116A4.839 4.839 0 0 1 16 2.141V2a1.97 1.97 0 0 0-1.933-2H7v5a2 2 0 0 1-2 2H0v11a1.969 1.969 0 0 0 1.933 2h12.134A1.97 1.97 0 0 0 16 18v-3.093l-1.546 1.546c-.413.413-.94.695-1.513.81l-3.4.679a2.947 2.947 0 0 1-1.85-.227 2.96 2.96 0 0 1-1.635-3.257l.681-3.397Z"/>

                 <path d="M8.961 16a.93.93 0 0 0 .189-.019l3.4-.679a.961.961 0 0 0 .49-.263l6.118-6.117a2.884 2.884 0 0 0-4.079-4.078l-6.117 6.117a.96.96 0 0 0-.263.491l-.679 3.4A.961.961 0 0 0 8.961 16Zm7.477-9.8a.958.958 0 0 1 .68-.281.961.961 0 0 1 .682 1.644l-.315.315-1.36-1.36.313-.318Zm-5.911 5.911 4.236-4.236 1.359 1.359-4.236 4.237-1.7.339.341-1.699Z"/>

              </svg>

              <span class="flex-1 ml-3 whitespace-logout">App</span>

           </a>

        </li> 



          <li style="position: absolute;top:85%;    width: 90%;">

             <a href="#" class="logout flex items-center p-2 text-gray-900 rounded-lg text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">

              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

                <path d="M15.24 22.2705H15.11C10.67 22.2705 8.53002 20.5205 8.16002 16.6005C8.12002 16.1905 8.42002 15.8205 8.84002 15.7805C9.24002 15.7405 9.62002 16.0505 9.66002 16.4605C9.95002 19.6005 11.43 20.7705 15.12 20.7705H15.25C19.32 20.7705 20.76 19.3305 20.76 15.2605V8.74047C20.76 4.67047 19.32 3.23047 15.25 3.23047H15.12C11.41 3.23047 9.93002 4.42047 9.66002 7.62047C9.61002 8.03047 9.26002 8.34047 8.84002 8.30047C8.42002 8.27047 8.12001 7.90047 8.15001 7.49047C8.49001 3.51047 10.64 1.73047 15.11 1.73047H15.24C20.15 1.73047 22.25 3.83047 22.25 8.74047V15.2605C22.25 20.1705 20.15 22.2705 15.24 22.2705Z" fill="white" fill-opacity="0.87"/>

                <path d="M15.0001 12.75H3.62012C3.21012 12.75 2.87012 12.41 2.87012 12C2.87012 11.59 3.21012 11.25 3.62012 11.25H15.0001C15.4101 11.25 15.7501 11.59 15.7501 12C15.7501 12.41 15.4101 12.75 15.0001 12.75Z" fill="white" fill-opacity="0.87"/>

                <path d="M5.84994 16.0998C5.65994 16.0998 5.46994 16.0298 5.31994 15.8798L1.96994 12.5298C1.67994 12.2398 1.67994 11.7598 1.96994 11.4698L5.31994 8.11984C5.60994 7.82984 6.08994 7.82984 6.37994 8.11984C6.66994 8.40984 6.66994 8.88984 6.37994 9.17984L3.55994 11.9998L6.37994 14.8198C6.66994 15.1098 6.66994 15.5898 6.37994 15.8798C6.23994 16.0298 6.03994 16.0998 5.84994 16.0998Z" fill="white" fill-opacity="0.87"/>

                </svg>

                

                <span class="flex-1 ml-3 whitespace-logout">Logout</span>

             </a>

          </li>

       </ul>

    </div>

 </aside>

        

    </div>

 

 <div class="p-4 pt-0 sm:ml-64 col-end-1 col-start-9 col-span-2">



   <nav class="grid grid-cols-1 mt-0 ">

       <div class="px-3 py-5 lg:px-6 lg:pl-3">

         <div class="flex items-center justify-between">

           <div class="flex items-center justify-start">

             <button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600">

                 <span class="sr-only">Open sidebar</span>

                 <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">

                    <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>

                 </svg>

              </button>

               <h2 class="h-6 mr-3 text-white" style="font-size: 20px;font-weight: 700;line-height: 1;">WELCOME BACK</h2>

           </div>

           <div class="flex items-center justify-start">

              <form class="flex items-center">

                    <label for="simple-search" class="sr-only">Search</label>

                    <div class="relative w-full">

                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none" style="background-color:#12121200!important;">

                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">

                              <path d="M11 20.75C5.62 20.75 1.25 16.38 1.25 11C1.25 5.62 5.62 1.25 11 1.25C16.38 1.25 20.75 5.62 20.75 11C20.75 16.38 16.38 20.75 11 20.75ZM11 2.75C6.45 2.75 2.75 6.45 2.75 11C2.75 15.55 6.45 19.25 11 19.25C15.55 19.25 19.25 15.55 19.25 11C19.25 6.45 15.55 2.75 11 2.75Z" fill="white" fill-opacity="0.6"/>

                              <path d="M20.1601 22.79C20.0801 22.79 20.0001 22.78 19.9301 22.77C19.4601 22.71 18.6101 22.39 18.1301 20.96C17.8801 20.21 17.9701 19.46 18.3801 18.89C18.7901 18.32 19.4801 18 20.2701 18C21.2901 18 22.0901 18.39 22.4501 19.08C22.8101 19.77 22.7101 20.65 22.1401 21.5C21.4301 22.57 20.6601 22.79 20.1601 22.79ZM19.5601 20.49C19.7301 21.01 19.9701 21.27 20.1301 21.29C20.2901 21.31 20.5901 21.12 20.9001 20.67C21.1901 20.24 21.2101 19.93 21.1401 19.79C21.0701 19.65 20.7901 19.5 20.2701 19.5C19.9601 19.5 19.7301 19.6 19.6001 19.77C19.4801 19.94 19.4601 20.2 19.5601 20.49Z" fill="white" fill-opacity="0.6"/>

                           </svg>

                        </div>

                        <input style="color: #fff!important;" type="text" id="simple-search" class="search search_text bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500" placeholder="Search" required="">

                    </div>

                </form>

               

           </div>

           <div class="flex items-center">

               <div class="flex items-center ml-3">

                 <div>

                   <button type="button" class="flex text-sm text-white" aria-expanded="false" style="background-color: #0000!important;">

                     <span class="sr-only">Open user menu</span>

                     <img class="w-8 h-8 rounded-full rounded-full bg-gray-800 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" src="{{asset('Dashboard/image/photo.png')}}" alt="user photo">

                       <div class="text-left ml-4">

                           <p style="/* Mohamed metwally */



                           width: 134px;

                           height: 17px;

                           

                           /* Base/Bold */

                           font-family: 'Inter';

                           font-style: normal;

                           font-weight: 700;

                           font-size: 14px;

                           line-height: 120%;

                           /* identical to box height, or 17px */

                           

                           /* Text/Primary */

                           color: rgba(255, 255, 255, 0.87);

                           

                           

                           /* Inside auto layout */

                           flex: none;

                           order: 0;

                           flex-grow: 0;

                           ">{{auth()->user()->username}}</p>

                           <span style="/* Maneger */



                           width: 51px;

                           height: 14px;

                           

                           /* Small/Regular */

                           font-family: 'Inter';

                           font-style: normal;

                           font-weight: 400;

                           font-size: 12px;

                           line-height: 120%;

                           /* or 14px */

                           

                           /* Text/Secondary */

                           color: rgba(255, 255, 255, 0.6);

                           

                           

                           /* Inside auto layout */

                           flex: none;

                           order: 1;

                           flex-grow: 0;

                           ">Manager</span>

                       </div>

                   </button>

                 </div>

                 <!--<div class="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded shadow dark:bg-gray-700 dark:divide-gray-600" id="dropdown-users">-->

                   <!--<div class="px-4 py-3" role="none">-->

                     <!--<p class="text-sm text-gray-900 text-white" role="none">-->

                     <!-- {{auth()->user()->username}}-->

                     <!--</p>-->

                     <!--<p class="text-sm font-medium text-gray-900 truncate text-white" role="none">-->

                     <!-- {{auth()->user()->email}}-->

                     <!--</p>-->

                   <!--</div>-->

                   <!--<ul class="py-1" role="none">-->

                     <!--<li>-->

                     <!--  <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-white" style="color: #f7f7f7!important;" role="menuitem">Settings</a>-->

                     <!--</li>-->

                     <!--<li>-->

                     <!--  <a href="#" class="logout block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-white" style="color: #f7f7f7!important;" role="menuitem">Log Out</a>-->

                     <!--</li>-->

                   <!--</ul>-->

                 <!--</div>-->

               </div>

             </div>



             

         </div>

       </div>

     </nav>

     

    <div class="p-4" id="app">

   

        @yield("main-content")

    

  </div>

</div>

 

     

     

</div>



 

 







    <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery_3.7.0_jquery.min.js')}}"  crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_jquery-toast-plugin_1.3.2_jquery.toast.min.js')}}"  crossorigin="anonymous" referrerpolicy="no-referrer"></script>    

    <script src="{{asset('Dashboard/vendor/js/cdnjs.cloudflare.com_ajax_libs_limonte-sweetalert2_11.7.27_sweetalert2.min.js')}}"  crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/resumable.js/1.0.3/resumable.min.js" integrity="sha512-OmtdY/NUD+0FF4ebU+B5sszC7gAomj26TfyUUq6191kbbtBZx0RJNqcpGg5mouTvUh7NI0cbU9PStfRl8uE/rw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    @yield("bottom-js")

    <script>

      $(document).ready(function(){

        document.addEventListener("DOMContentLoaded", function(event) {

                var status = document.getElementById('popup-modal').click(function(e){

                  console.log(e); 

                });

                console.log(event); 

            });



          $(document).on("click",".delete",function(){

            Swal.fire({

              imageUrl: '{{asset('Dashboard/image/warning-2.png')}}',

              imageAlt: 'A tall image',

              text: 'Are you sure you want delete this client ?',

              title: 'Delete client',

                showDenyButton: false,

                showCancelButton: true,

                confirmButtonText: 'Delete',

                denyButtonText: `Don't save`,

              }).then((result) => {

                if (result.isConfirmed) {

                  $.post({

                    url:"{{route('dashboard.client.delete')}}",

                    "data":{

                      id:$(this).attr("data-id"),

                      "_token":$('meta[name="csrf-token"]').attr('content')

                    }

                  }).then((data)=>{

                    Swal.fire('Saved!', '', 'success');

                    const myTimeout = setTimeout(function(){

                  

                      location.replace("{{route('dashboard.client.index')}}"); 

                    }, 2000);

                    

                  }).catch((error)=>{

                    if(error.status == 422){

                      Swal.fire('Changes are not done', '', 'error')    

                    }

                  });

                } else if (result.isDenied) {

                  Swal.fire('Changes are not done', '', 'info')

                }

              })

          });

          

          

           $(document).on("click",".logout",function(){

                $.post({

                    url:"{{route('dashboard.auth.logout')}}",

                    "data":{

                      "_token":$('meta[name="csrf-token"]').attr('content')

                    }

                  }).then((data)=>{

                    Swal.fire('Logout Success!', '', 'success');

                    const myTimeout = setTimeout(function(){

                      location.replace("{{route('dashboard.auth.index')}}"); 

                    }, 2000);

                    

                  }).catch((error)=>{

                    if(error.status == 422){

                      Swal.fire('Error 505 ', '', 'error')    

                    }

                  });

          });

          

          









          $(document).on("click",".delete-template",function(){

            

            Swal.fire({

              imageUrl: '{{asset('Dashboard/image/warning-2.png')}}',

              imageAlt: 'A tall image',

              text: 'Are you sure you want delete this Template ?',

              title: 'Delete client',

                showDenyButton: false,

                showCancelButton: true,

                confirmButtonText: 'Delete',

              }).then((result) => {

                if (result.isConfirmed) {

                  $.post({

                    url:"{{route('dashboard.template.delete')}}",

                    "data":{

                      id:$(this).attr("data-id"),

                      "_token":$('meta[name="csrf-token"]').attr('content')

                    }

                  }).then((data)=>{

                    Swal.fire('Saved!', '', 'success');

                    const myTimeout = setTimeout(function(){

                      location.replace("{{route('dashboard.template.index')}}");   

                    }, 2000);

                    

                  }).catch((error)=>{

                    if(error.status == 422){

                      Swal.fire('Changes are not done', '', 'error')    

                    }

                  });

                } else if (result.isDenied) {

                  Swal.fire('Changes are not done', '', 'info')

                }

              })

          });



      });

      // file upload input 

$('#file-upload-hide').on('change',function () {

  // console.log( $('#file-upload').val())

  $('#file-upload').val($(this).val().split('\\').pop()) 

})



$('#ans-upload-hide').on('change',function () {

  // console.log( $('#file-upload').val())

  $('#file-upload1').val($(this).val().split('\\').pop()) 

})



// upload image user profile 

function readURL(input) {

  if (input.files && input.files[0]) {

      var reader = new FileReader();

      reader.onload = function(e) {

          $('#imagePreview').css('background-image', 'url('+e.target.result +')');

          $('#imagePreview').hide();

          $('#image-preview').empty();

          $('#imagePreview').fadeIn(650);

      }

     

      reader.readAsDataURL(input.files[0]);

  }

}

$("#imageUpload").change(function() {

  readURL(this);

});







$(document).on("input",'input:radio[name="view"]',function(){
  var text1 = $('input:radio[name="view"][checked="checked"]').parent().children("label").children("div").text();
  $('input:radio[name="view"][checked="checked"]').parent().children("label").children("div").remove();
  $('input:radio[name="view"][checked="checked"]').parent().children("label").append(`
  <div class="flex">
                                                <svg width="20" class="mr-2" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g opacity="0.8">
                                                    <path d="M9.97493 18.3327C14.5773 18.3327 18.3083 14.6017 18.3083 9.99935C18.3083 5.39698 14.5773 1.66602 9.97493 1.66602C5.37256 1.66602 1.6416 5.39698 1.6416 9.99935C1.6416 14.6017 5.37256 18.3327 9.97493 18.3327Z" stroke="white" stroke-opacity="0.6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </g>
                                                    </svg>
                                                <div class="w-full">${text1}</div>
  `);
  $('input:radio[name="view"][checked="checked"]').removeAttr("checked");
    $(this).attr('checked',true);
    var text = $(this).parent().children("label").children("div").text();
    $(this).parent().children("label").children("div").remove();
    $(this).parent().children("label").append(`<div class="flex">
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.8">
<path d="M9.97506 18.3332C14.5774 18.3332 18.3084 14.6022 18.3084 9.99984C18.3084 5.39746 14.5774 1.6665 9.97506 1.6665C5.37268 1.6665 1.64172 5.39746 1.64172 9.99984C1.64172 14.6022 5.37268 18.3332 9.97506 18.3332Z" stroke="#F38E93" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9.99998 13.5251C11.9468 13.5251 13.525 11.9469 13.525 10.0001C13.525 8.05329 11.9468 6.4751 9.99998 6.4751C8.05317 6.4751 6.47498 8.05329 6.47498 10.0001C6.47498 11.9469 8.05317 13.5251 9.99998 13.5251Z" fill="#F38E93" stroke="#F38E93" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</g>
</svg>
<div class="w-full">${text}</div>
</div>
    `);
    

});


$(document).on("input",'input:radio[name="personal[status]"]',function(){
  var text1 = $('input:radio[name="personal[status]"][checked="checked"]').parent().children("label").children("div").text();
  $('input:radio[name="personal[status]"][checked="checked"]').parent().children("label").children("div").remove();
  $('input:radio[name="personal[status]"][checked="checked"]').parent().children("label").append(`
  <div class="flex">
                                                <svg width="20" class="mr-2" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g opacity="0.8">
                                                    <path d="M9.97493 18.3327C14.5773 18.3327 18.3083 14.6017 18.3083 9.99935C18.3083 5.39698 14.5773 1.66602 9.97493 1.66602C5.37256 1.66602 1.6416 5.39698 1.6416 9.99935C1.6416 14.6017 5.37256 18.3327 9.97493 18.3327Z" stroke="white" stroke-opacity="0.6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </g>
                                                    </svg>
                                                <div class="w-full">${text1}</div>
  `);
  $('input:radio[name="personal[status]"][checked="checked"]').removeAttr("checked");
    $(this).attr('checked',true);
    var text = $(this).parent().children("label").children("div").text();
    $(this).parent().children("label").children("div").remove();
    $(this).parent().children("label").append(`<div class="flex">
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.8">
<path d="M9.97506 18.3332C14.5774 18.3332 18.3084 14.6022 18.3084 9.99984C18.3084 5.39746 14.5774 1.6665 9.97506 1.6665C5.37268 1.6665 1.64172 5.39746 1.64172 9.99984C1.64172 14.6022 5.37268 18.3332 9.97506 18.3332Z" stroke="#F38E93" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9.99998 13.5251C11.9468 13.5251 13.525 11.9469 13.525 10.0001C13.525 8.05329 11.9468 6.4751 9.99998 6.4751C8.05317 6.4751 6.47498 8.05329 6.47498 10.0001C6.47498 11.9469 8.05317 13.5251 9.99998 13.5251Z" fill="#F38E93" stroke="#F38E93" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</g>
</svg>
<div class="w-full">${text}</div>
</div>
    `);
    

});





    </script>

</body>

</html>