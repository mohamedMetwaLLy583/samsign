@extends("Dashboard.layouts.master")
@section("title","Clients")
@section("main-content")  
<style>
    
    a h5{
        color:#fff!important;
    }
</style>
<div class="grid grid-cols-2 gap-4 mb-4">
      <div class="title-page">
         <h1 class="text-white" style="    font-size: 22px;">App</h1>
         <div>
            <!--<span style="color: #525252;">Templates</span>-->
         </div>
      </div>
      <div class="flex Client-Head">
         
      </div>
</div>
<section class="">
   <div class="">
       <!-- Start coding here -->
       <div class="relative shadow-md sm:rounded-lg overflow-hidden">
           <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
               <div class="w-50 md:w-1/2">
               </div>
           </div>
           <div class="overflow-x-auto">
            <div class="grid grid-cols-4 gap-4 mb-4">
                
                <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="width: 85%;margin-top: 18px;" src="{{asset('Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                             <a href="{{route('dashboard.country.index')}}">
                                 <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Country</h5>
                             </a>
                             <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Created in  ms.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            <div>
                                
                            </div>
                            <div>
                                
                            </div>
                        </div>
                     </div>
                </div>

                <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="width: 85%;margin-top: 18px;" src="{{asset('Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                             <a href="{{route('dashboard.city.index')}}">
                                 <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">City</h5>
                             </a>
                             <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Created in  ms.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            <div>
                                
                            </div>
                            <div>
                                
                            </div>
                        </div>
                     </div>
                </div>


                <!-- <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="width: 85%;margin-top: 18px;" src="{{asset('Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                             <a href="{{route('dashboard.notification.index')}}">
                                 <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Notification</h5>
                             </a>
                             <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Created in  ms.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            <div>
                                
                            </div>
                            <div>
                                
                            </div>
                        </div>
                     </div>
                </div> -->

                <!-- <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="width: 85%;margin-top: 18px;" src="{{asset('Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                             <a href="{{route('dashboard.language.index')}}">
                                 <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Language</h5>
                             </a>
                             <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Created in  ms.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            <div>
                                
                            </div>
                            <div>
                                
                            </div>
                        </div>
                     </div>
                </div> -->

                <!-- <div class="flex items-center justify-center" style="background-color: #2f2f2f7d;border-radius: 12px;">
                    <div class="max-w-sm shadow  dark:border-gray-700">
                         <a href="#" style="text-align: -webkit-center;">
                             <img class="border border-gray-200 rounded-lg rounded-t-lg h-50 w-full" style="width: 85%;margin-top: 18px;" src="{{asset('Dashboard/image/logo.png')}}" alt="" />
                         </a>
                         <div class="px-5">
                             <a href="#">
                                 <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">About</h5>
                             </a>
                             <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Created in  ms.</p>
                        </div>
                        <div class="grid grid-cols-2 gap-4 Client-Head mb-2" style="text-align: -webkit-center;">
                            <div>
                                
                            </div>
                            <div>
                                
                            </div>
                        </div>
                     </div>
                </div> -->
               
             </div>
           </div>
           
       </div>
   </div>
   </section>
@endsection

@section("bottom-js")
  
@endsection
