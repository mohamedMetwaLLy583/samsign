@extends("Dashboard.layouts.design")
@section("title","Editor")
@section("main-content")  
    <home-component :id="{{$data['template']->id}}" :width="{{$data['template']->width}}" :height="{{$data['template']->height}}" ></home-component>
@endsection
@section("bottom-js")

@endsection
