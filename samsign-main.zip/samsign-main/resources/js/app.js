/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */
import { createApp } from "vue";
import ElementPlus from "element-plus";
import * as ElementPlusIconsVue from "@element-plus/icons-vue";
import "element-plus/dist/index.css";
import { useNotification } from "@kyvg/vue3-notification";

import VueKonva from "vue3-konva";
import { TailwindPagination } from "laravel-vue-pagination";


const { notify } = useNotification()
const app = createApp({
    components: {
        TailwindPagination,
    }
});
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
};
app.use(VueKonva, { prefix: "kv" });
app.use(ElementPlus);
app.use(notify)

app.mount('#app');
