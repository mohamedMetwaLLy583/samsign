import ExampleComponent from './components/ExampleComponent.vue';
import Home from "./components/Home.vue";
export default
[
    { 
    path: '/',
    name:"Home",
    component: Home 
    },
    { path: '/about',
    name:"About", 
    component: ExampleComponent },
  ]