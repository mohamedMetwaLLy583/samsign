<template>
    <div>
        Home
        <router-link to="/about">About</router-link>
    </div>
</template>