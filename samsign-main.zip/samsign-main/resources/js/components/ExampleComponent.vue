<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{count()}}</div>

                    <div class="card-body">
                        <button @click="count">Count++</button>
                        <router-link to="/">Home</router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        },
        data(){
            return {
                count: function(data){
                    var i=0;
                    if(i > 2){
                        i++;
                        console.log(i);
                        return i;
                    }else{
                        i++;
                        console.log(i);
                        return i;
                    } 
                    
                } ,
            }
        }
    }
</script>
